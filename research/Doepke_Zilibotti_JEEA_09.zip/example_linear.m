% example_linear.m
%
% Example for linear version of model for EEA 2008 congress
% Effect of international labor standards on domestic political
% economy for child-labor legislation

% Note on how to choose parameters
% Adjusting the pi and p_hat moves the distribution of types
% Adjusting the p_l and p_h moves the calibrated z
% Adjusting A_E moves the fraction of labor used in each sector
% The latter is important to make sure that both sectors operate and the IS
% will be binding

clear all;
clear all;

close all;

% TECHNICAL PARAMETERS **********************
%********************************************
crit_max=0.00001;

% MODEL PARAMETERS **********************
%****************************************

% Technology
A_E=3.9;
A_D=1;      % Note: Unskilled wage therefore normalized to one
alph=0.5;

lam=0.2;

pi_1=0.3;
pi_0=0;

% Distribution of education cost
% Note: Changing this will affect the choice of z, but nothing else
p_U_l=0.1;
p_U_h=0.2;

p_S=0;

% Target for p_hat; two-thirds educate in LF
p_hat=.666*p_U_h+.334*p_U_l;


% COMPUTE LF EQUILIBRIUM, ENSURE RELEVANT CONDITIONS ARE MET ********
%********************************************************************

% Compute LF wages
w_U_LF=A_D;
w_S_LF=A_E*alph*(A_E*(1-alph)/A_D)^((1-alph)/alph);
w_C_LF=lam*w_U_LF;



% Now set z to make chosen p_hat optimal
z=0.7;
z_min=0;
z_max=1;

crit=1;
while crit>crit_max;
    
    % Compute fraction of unskilled educating
    mu_LF=(p_hat-p_U_l)/(p_U_h-p_U_l);

    % Compute utilities
    part1=mu_LF*(w_U_LF-(p_hat+p_U_l)/2+z*pi_1*(w_S_LF-p_S)/(1-z*pi_1));
    part2=(1-mu_LF)*(w_U_LF+w_C_LF+z*pi_0*(w_S_LF-p_S)/(1-z*pi_1));
    part3=1-z*(mu_LF*(1-pi_1)/(1-z*pi_1)+...
            (1-mu_LF)*(1-pi_0*(1-z)/(1-z*pi_1)));

    % Equilibrium values        
    E_V_U_LF=(part1+part2)/part3;
    V_S_LF=(w_S_LF-p_S)/(1-z*pi_1)+z*(1-pi_1)*E_V_U_LF/(1-z*pi_1);

    % Check the indifference condition
    p_hat_target=z*(pi_1-pi_0)*(V_S_LF-E_V_U_LF)-w_C_LF;
    
    if p_hat_target>p_hat;
        % lower z
        z_max=z;
        z=0.5*z_min+0.5*z;
    else;
        % increase z
        z_min=z;
        z=0.5*z_max+0.5*z;
    end;

    crit=abs(p_hat-p_hat_target);
    
end;

% Corresponding distribution of population
N_U_LF=(1-pi_1)/(1-(1-mu_LF)*(pi_1-pi_0));
N_S_LF=(pi_1-(1-mu_LF)*(pi_1-pi_0))/(1-(1-mu_LF)*(pi_1-pi_0));

% Amount of unskilled labor required in E sector
N_U_E_LF=((1-alph)*(A_E/A_D))^(1/alph)*N_S_LF;

% Compare the two relevant quantities for an "interesting" equilibrium
disp('Educating unskilled as fraction of adult population')
disp('should be one half or larger')
frac_e_u=mu_LF*N_U_LF

disp('The following should be ordered from smallest to largest')
N_U_LF
N_U_E_LF
N_U_LF_TOTAL=(1+lam*mu_LF)*N_U_LF

if (N_U_LF<N_U_E_LF) && (N_U_E_LF<N_U_LF_TOTAL);
    disp('ORDERING CONDITION IS SATISFIED');
else;
    disp('ORDERING CONDITION IS VIOLATED');
end;
    
pause;


% NEXT STEP: COMPUTE BAN TRANSITION PATH %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initial wages
w_S_LF_B=A_E*alph*(N_U_LF/N_S_LF)^(1-alph);
w_U_LF_B=A_E*(1-alph)*(N_S_LF/N_U_LF)^alph;
w_C_LF_B=0;


% Compute ban steady state
% Check whether everybody wants to educate

% Compute outcomes under that steady state
% Wages
w_U_B=A_E*(1-alph)*(pi_1/(1-pi_1))^alph;
w_S_B=A_E*alph*((1-pi_1)/pi_1)^(1-alph);

% Utilities
V_U_B=(w_U_B-(p_U_l+p_U_h)/2+z*pi_1*(w_S_B-p_S)/(1-z*pi_1))/((1-z)/(1-z*pi_1));
V_S_B=(w_S_B-p_S)/(1-z*pi_1)+z*(1-pi_1)*V_U_B/(1-z*pi_1);

% Now check that everybody wants to educate
p_hat_B=z*(pi_1-pi_0)*(V_S_B-V_U_B);

if p_hat_B>p_U_h;
    disp('CONDITION FOR EVERYBODY EDUCATING UNDER B IS SATISFIED');
else;
    disp('CONDITION FOR EVERYBODY EDUCATING UNDER B IS VIOLATED');
end;

pause;

% Now do the utility comparisons

% Utilities in transition for the three types
V_S_LF_B=w_S_LF_B-p_S+z*(pi_1*(w_S_LF_B-p_S)+(1-pi_1)*(w_U_LF_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

% Evaluate the unskilled utilities NET OF THE CURRENT EDUCATION COST
V_U_ed_LF_B=w_U_LF_B+z*(pi_1*(w_S_LF_B-p_S)+(1-pi_1)*(w_U_LF_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

V_U_no_ed_LF_B=w_U_LF_B+z*(pi_0*(w_S_LF_B-p_S)+(1-pi_0)*(w_U_LF_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

% The utility comparison
disp(' ');
disp('DIRECT INTRODUCTION OF A BAN FROM LF:');

if V_S_LF_B>V_S_LF;
    disp('- SKILLED ADULTS GAIN');
else;
    disp('- SKILLED ADULTS LOSE');
end;

if V_U_ed_LF_B>w_U_LF+z*(pi_1*V_S_LF+(1-pi_1)*E_V_U_LF);
    disp('- EDUCATING UNSKILLED ADULTS GAIN');
else;
    disp('- EDUCATING UNSKILLED ADULTS LOSE');
end;

if V_U_no_ed_LF_B>(1+lam)*w_U_LF+z*(pi_0*V_S_LF+(1-pi_0)*E_V_U_LF);
    disp('- NOT EDUCATING UNSKILLED ADULTS GAIN');
else;
    disp('- NOT EDUCATING UNSKILLED ADULTS LOSE');
end;

pause;

% FINAL STEP: COMPUTE TRANSITION PATH FROM IS %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First have to find new p_hat by bracketing
p_hat_IS=p_hat;
p_hat_IS_max=p_U_h;
p_hat_IS_min=p_U_l;


crit=1;
while crit>crit_max;

    % Compute fraction of unskilled educating
    mu_IS=(p_hat_IS-p_U_l)/(p_U_h-p_U_l);

    % Corresponding distribution of population
    N_U_IS=(1-pi_1)/(1-(1-mu_IS)*(pi_1-pi_0));
    N_S_IS=(pi_1-(1-mu_IS)*(pi_1-pi_0))/(1-(1-mu_IS)*(pi_1-pi_0));

    % Corresponding wages
    w_S_IS=A_E*alph*(N_U_IS/N_S_IS)^(1-alph);
    w_U_IS=A_E*(1-alph)*(N_S_IS/N_U_IS)^alph;
    w_C_IS=lam*A_D;
    
    % Compute steady-state utilities
    part1=mu_IS*(w_U_IS-(p_hat_IS+p_U_l)/2+z*pi_1*(w_S_IS-p_S)/(1-z*pi_1));
    part2=(1-mu_IS)*(w_U_IS+w_C_IS+z*pi_0*(w_S_IS-p_S)/(1-z*pi_1));
    part3=1-z*(mu_IS*(1-pi_1)/(1-z*pi_1)+...
            (1-mu_IS)*(1-pi_0*(1-z)/(1-z*pi_1)));

    % Equilibrium values        
    E_V_U_IS=(part1+part2)/part3;
    V_S_IS=(w_S_IS-p_S)/(1-z*pi_1)+z*(1-pi_1)*E_V_U_IS/(1-z*pi_1);

    % Check the indifference condition
    p_hat_target=z*(pi_1-pi_0)*(V_S_IS-E_V_U_IS)-w_C_LF;
    
    if p_hat_target>p_hat_IS;
        % increase p_hat_IS
        p_hat_IS_min=p_hat_IS;
        p_hat_IS=0.5*p_hat_IS_max+0.5*p_hat_IS;
    else;
        % decrease p_hat_IS
        p_hat_IS_max=p_hat_IS;
        p_hat_IS=0.5*p_hat_IS_min+0.5*p_hat_IS;
    end;

    crit=abs(p_hat_IS-p_hat_target);
    
end;

% Compute fraction of unskilled educating
mu_IS=(p_hat_IS-p_U_l)/(p_U_h-p_U_l);

% Corresponding distribution of population
N_U_IS=(1-pi_1)/(1-(1-mu_IS)*(pi_1-pi_0));
N_S_IS=(pi_1-(1-mu_IS)*(pi_1-pi_0))/(1-(1-mu_IS)*(pi_1-pi_0));

% Corresponding wages
w_S_IS=A_E*alph*(N_U_IS/N_S_IS)^(1-alph);
w_U_IS=A_E*(1-alph)*(N_S_IS/N_U_IS)^alph;
w_C_IS=lam*A_D;

% Compute steady-state utilities
part1=mu_IS*(w_U_IS-(p_hat_IS+p_U_l)/2+z*pi_1*(w_S_IS-p_S)/(1-z*pi_1));
part2=(1-mu_IS)*(w_U_IS+w_C_IS+z*pi_0*(w_S_IS-p_S)/(1-z*pi_1));
part3=1-z*(mu_IS*(1-pi_1)/(1-z*pi_1)+...
        (1-mu_IS)*(1-pi_0*(1-z)/(1-z*pi_1)));

% Equilibrium values        
E_V_U_IS=(part1+part2)/part3;
V_S_IS=(w_S_IS-p_S)/(1-z*pi_1)+z*(1-pi_1)*E_V_U_IS/(1-z*pi_1);

disp('MU_LF WAS:');
mu_LF

disp('MU_IS IS:');
mu_IS

disp('EDUCATING UNSKILLED AS FRACTION OF POPULATION:');
mu_IS*N_U_IS

pause;

% Now: Introduction of ban
% Initial wages
w_S_IS_B=A_E*alph*(N_U_IS/N_S_IS)^(1-alph);
w_U_IS_B=A_E*(1-alph)*(N_S_IS/N_U_IS)^alph;
w_C_IS_B=0;

% Now do the utility comparisons
% Utilities in transition for the three types
V_S_IS_B=w_S_IS_B-p_S+z*(pi_1*(w_S_IS_B-p_S)+(1-pi_1)*(w_U_IS_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

% Evaluate the unskilled utilities NET OF THE CURRENT EDUCATION COST
V_U_ed_IS_B=w_U_IS_B+z*(pi_1*(w_S_IS_B-p_S)+(1-pi_1)*(w_U_IS_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

V_U_no_ed_IS_B=w_U_IS_B+z*(pi_0*(w_S_IS_B-p_S)+(1-pi_0)*(w_U_IS_B-(p_U_l+p_U_h)/2))...
    +z^2*(pi_1*V_S_B+(1-pi_1)*V_U_B);

% The utility comparison
disp(' ');
disp('INTRODUCTION OF A BAN FROM IS:');

if V_S_IS_B>V_S_IS;
    disp('- SKILLED ADULTS GAIN');
else;
    disp('- SKILLED ADULTS LOSE');
end;

if V_U_ed_IS_B>w_U_IS+z*(pi_1*V_S_IS+(1-pi_1)*E_V_U_IS);
    disp('- EDUCATING UNSKILLED ADULTS GAIN');
else;
    disp('- EDUCATING UNSKILLED ADULTS LOSE');
end;

if V_U_no_ed_IS_B>w_U_IS+w_C_IS+z*(pi_0*V_S_IS+(1-pi_0)*E_V_U_IS);
    disp('- NOT EDUCATING UNSKILLED ADULTS GAIN');
else;
    disp('- NOT EDUCATING UNSKILLED ADULTS LOSE');
end;


