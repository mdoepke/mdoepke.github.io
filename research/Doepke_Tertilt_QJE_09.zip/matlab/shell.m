% shell.m
% Shell to call the various subprograms for computing the transition path
% with foresight and dynamic voting
close all;
clear all;
clear all;

% First, compute how far theta has to rise at a minimum to get empowerment
theta_crit;
pause;

% Based on the outcome, the theta path in param.m should be adjusted
% Then, compute the equilibrium switch to empowerment, conditional on being
% in the education regime
switch_time;
pause;

% So far, parameter B did not play any role. Now set B to determine time of
% switch to education
edu_switch_time;
pause;

% Based on everything above, compute the equilibrium
% transition path
transition;
pause;

% Finally, produce graphs
graphs;