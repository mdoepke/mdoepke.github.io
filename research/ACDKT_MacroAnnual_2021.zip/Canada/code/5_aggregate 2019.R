#################################################################
# Code to generate the aggregate average hours for a year after 2017
# 
# Kwok Yan Chiu

# Years to extract
start_time <- "2019-01-01"
end_time <- "2019-12-01"

### Load the aggregate data

source(file.path(work_code_address,"combine years.R"))

# Load the documentation
colnames_lfs_1720 <- get(load(file.path(work_clean_address,"read_prn_key_1720.RData")))
fl_lfs_1720 <- get(load(file.path(work_clean_address,"factorlevels_1720.RData")))

# Load the data
data <- combine_years_lfs(work_data_address,start_time,end_time,"lfs")
data <- as.data.table(data)

### Main code
# Restrict the age
data <- data[age_12 %in% c(2L,3L,4L,5L,6L,7L,8L),] # 15-54

# kids variable
data[,agyownk_0 := ifelse(is.na(agyownk),0L,agyownk)] # For NA, I consider it as having no kids
data[,have_kids := ifelse(agyownk_0 %in% c(1L,2L),1L,0L)]
data[, have_kids := factor(have_kids,
                           levels = c(0L, 1L),
                           labels = c("No kids","Have kids"))]

from_agyownk_0 <- c(0L,1L,2L,3L,4L)
to_child_grp <- c(0L,1L,2L,0L,0L)

data[,child_grp := to_child_grp[match(agyownk_0,from_agyownk_0)]]
data[,child_grp := factor(child_grp,levels = c(0L,1L,2L),labels = c("No kid","<6","6-12"))]

# Marital status
data[,with_partner := ifelse(marstat %in% c(1L,2L),1L,0L)]
data[,with_partner := factor(with_partner,levels = c(0L,1L),labels = c("Single","Couple"))]

# Mother variable
data[, sex := factor(sex,
                     levels = c(1L, 2L),
                     labels = c("Male", "Female"))]
data[,mother := have_kids == "Have kids" & sex == "Female"]
data[,father := have_kids == "Have kids" & sex == "Male"]

# Single mother variable
data[,single_mother := mother & with_partner == "Single"]


# Get the kids, mum and single mum
# data[, .(
#   with_kids_wgt = sum(finalwt[have_kids == "Have kids"]) / sum(finalwt),
#   mother_wgt = sum(finalwt[mother]) / sum(finalwt),
#   single_mother_wgt = sum(finalwt[single_mother]) / sum(finalwt)
# )]

## Demography

emp_family_summary <- data[lfsstat %in% c(1L, 2L), .(
  with_kids_wgt = sum(finalwt[have_kids == "Have kids"]) / sum(finalwt),
  mother_wgt = sum(finalwt[mother]) / sum(finalwt),
  single_mother_wgt = sum(finalwt[single_mother]) / sum(finalwt)
)]

emp_family_summary



## Hours
# Hours replacement
data[,hrs := ifelse(!is.na(yaway) & yaway == 3L,utothrs,atothrs) / 10]

# Assign 0 hours for the unemployed
data[,hrs := ifelse(lfsstat %in% c(3L,4L) & is.na(hrs),0,hrs)]

# Average hours for mother
mother_avghrs <- data[mother == TRUE & sex == "Female", .(avg_hours = sum(finalwt * hrs) / sum(finalwt)), by = .(with_partner, child_grp)]
nonmother_avghrs <- data[mother == FALSE & sex == "Female", .(avg_hours = sum(finalwt * hrs) / sum(finalwt))]

# Average hours for men
father_avghrs <- data[father == TRUE & sex == "Male",.(avg_hours = sum(finalwt * hrs) / sum(finalwt))]
nonfather_avghrs <- data[father == FALSE & sex == "Male",.(avg_hours = sum(finalwt * hrs) / sum(finalwt))]



## A table for all the result
write.csv(emp_family_summary,file.path(work_result_address, "Employed Individuals by type.csv"))
write.csv(mother_avghrs,file.path(work_result_address, "mother labour supply.csv"))
write.csv(nonmother_avghrs,file.path(work_result_address, "nonmother labour supply.csv"))

write.csv(father_avghrs,file.path(work_result_address, "father labour supply.csv"))
write.csv(nonfather_avghrs,file.path(work_result_address, "nonfather labour supply.csv"))

