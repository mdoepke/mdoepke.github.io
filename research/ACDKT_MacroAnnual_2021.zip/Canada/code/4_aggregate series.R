#################################################################
# Code to generate the aggregate series for time series analysis
# Kwok Yan Chiu


# Load the aggregate data
reloaddata <- TRUE

source(file.path(work_code_address,"combine years.R"))

if (reloaddata){
  # Read the factors definition
  colnames_lfs_1720 <- get(load(file.path(work_clean_address,"read_prn_key_1720.RData")))
  fl_lfs_1720 <- get(load(file.path(work_clean_address,"factorlevels_1720.RData")))
  
  colnames_lfs_7616 <- get(load(file.path(work_clean_address,"read_prn_key_7616.RData")))
  fl_lfs_7616 <- get(load(file.path(work_clean_address,"factorlevels_7616.RData")))
  
  
  # Get the data
  data_1720 <- combine_years_lfs(work_data_address,"2017-01-01","2020-11-01","lfs")
  data_7616 <- combine_years_lfs(work_data_address,"1998-01-01","2016-12-01","lfs")
  
  # Change it datatable for easier manipulation
  data_1720 <- as.data.table(data_1720)
  data_7616 <- as.data.table(data_7616)
  
  # We need hours, age, sex, employment stat, marital status, reason
  data_1720 <- data_1720[, c(
    "survyear",
    "survmnth",
    "age_12",
    "lfsstat",
    "atothrs",
    "utothrs",
    "yaway",
    "marstat",
    "sex",
    "finalwt"
  )]
  
  data_7616 <- data_7616[, c(
    "survyear",
    "survmnth",
    "age_12",
    "lfsstat",
    "atothrs",
    "utothrs",
    "yaway",
    "marstat",
    "sex",
    "fweight"
  )]
  
  # Check the group for age_12, lfsstat, yaway, marstat, sex
  # level_check <- c("age_12","lfsstat","yaway","marstat","sex")
  # lapply(1:length(level_check),function(x) unique(data_1720[[level_check[x]]]))
  # lapply(1:length(level_check),function(x) unique(data_7616[[level_check[x]]]))
  
  # Make date
  data_1720[,time := make_date(survyear,survmnth)]
  data_7616[,time := make_date(survyear,survmnth)]
  
  # Map the lfsstat to the same
  from_var <- c(1L,2L,3L,4L,5L,6L)
  to_var <- c(1L,2L,3L,3L,3L,4L)
  data_7616[,lfsstat := to_var[match(lfsstat,from_var)]]
  
  # Map the marstat
  from_var <- c(1L,2L,3L,4L,5L,6L)
  to_var <- c(1L,1L,3L,4L,4L,2L)
  data_7616[,marstat := ifelse(time >= make_date(1999,11),to_var[match(marstat,from_var)],marstat)]
  data_1720[,marstat := ifelse(time >= make_date(1999,11),to_var[match(marstat,from_var)],marstat)]
  
  # Rename the weight
  setnames(data_7616,"fweight","finalwt")
  
  # Combine the dataset
  data <- rbind(data_7616,data_1720)
  rm(list = c("data_1720","data_7616"))
  gc()
  
  # Save the dataset
  save(data,file = file.path(work_clean_address,"data aggregation.RData"))
} else {
  load(file.path(work_clean_address,"data aggregation.RData"))
}


######################################################################
# Make aggregate series

## Verify it with the aggregate data
# 
unemp_rate <-
  data[, .(
    unemp_rate = sum(finalwt[lfsstat == 3L]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L)]),
    nump = sum(finalwt[lfsstat == 3L]),
    nlf = sum(finalwt[lfsstat %in% c(1L, 2L, 3L)])
  ), by = .(time)]


View(unemp_rate[order(time),])

# It matches the unemployment rate unadjusted for seasonality.


# unemp_rate2_check <- data[, .(
#   unemp_rate = sum(finalwt[lfsstat == 3L]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L)]),
#   under_emp_rate = sum(finalwt[lfsstat == 2L]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L)]),
#   nump = sum(finalwt[lfsstat == 3L]),
#   nlf = sum(finalwt[lfsstat %in% c(1L, 2L, 3L)])
# ), by = .(time)]
# 
# View(unemp_rate2_check[order(time),])

# Transform the weight


## Main code
# Restrict the age
data <- data[age_12 %in% c(2L,3L,4L,5L,6L,7L,8L,9L,10L),]

# Hours replacement
data[,hrs := ifelse(!is.na(yaway) & yaway == 3L,utothrs,atothrs) / 10]

# Assign 0 hours for the unemployed
data[,hrs := ifelse(lfsstat %in% c(3L,4L) & is.na(hrs),0,hrs)]

# Make marital status
data[,married := ifelse(marstat == 1L,"married","unmarried")]

# Rename the sex into male and female
data[, sex := c("male", "female")[match(sex, c(1L, 2L))]]

# Annual series
annual_ump_rate <- data[, .(
  emp_rate = sum(finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L, 4L)]),
  avg_hrs = sum(hrs * finalwt) / sum(finalwt),
  tot_hrs = sum(hrs * finalwt)
), by = .(survyear)]

# By gender
annual_ump_rate_by_gender <- data[, .(
  emp_rate = sum(finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L, 4L)]),
  avg_hrs = sum(hrs * finalwt) / sum(finalwt),
  tot_hrs = sum(hrs * finalwt)
), by = .(survyear,sex)]

# By gender and marital status
annual_ump_rate_by_gender_and_mar <- data[, .(
  emp_rate = sum(finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L, 4L)]),
  avg_hrs = sum(hrs * finalwt) / sum(finalwt),
  tot_hrs = sum(hrs * finalwt)
), by = .(survyear,sex,married)]



# Spread the data set

# for gender
annual_ump_rate_by_gender <-
  melt(annual_ump_rate_by_gender, id.var = c(1, 2))

annual_ump_rate_by_gender[, col_combine := paste0(variable, "_", sex)]

annual_ump_rate_by_gender[, c("sex", "variable") := NULL]

annual_ump_rate_by_gender <-
  dcast(annual_ump_rate_by_gender, survyear ~ col_combine)

# for gender and marital status
annual_ump_rate_by_gender_and_mar <- melt(annual_ump_rate_by_gender_and_mar, id.var = c(1, 2, 3))

annual_ump_rate_by_gender_and_mar[, col_combine := paste0(variable, "_", married ,".", sex)]

annual_ump_rate_by_gender_and_mar[, c("sex", "married", "variable") := NULL]

annual_ump_rate_by_gender_and_mar <-
  dcast(annual_ump_rate_by_gender_and_mar, survyear ~ col_combine)

# Merge them
setkey(annual_ump_rate,"survyear")
setkey(annual_ump_rate_by_gender,"survyear")
setkey(annual_ump_rate_by_gender_and_mar,"survyear")

annual_agg <- merge(annual_ump_rate, annual_ump_rate_by_gender)
annual_agg <- merge(annual_agg, annual_ump_rate_by_gender_and_mar)

# Quarterly version
data[,quarter := ceiling(survmnth/3)]

# Make a quarter time
data[,quarter_time := paste0(survyear,"-Q",quarter)]

# Population
quarter_ump_rate <- data[, .(
  emp_rate = sum(finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L, 4L)]),
  avg_hrs = sum(hrs * finalwt) / sum(finalwt),
  avg_hrs_emp = sum(hrs[lfsstat %in% c(1L,2L)] * finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L,2L)])
), by = .(quarter_time)]

# By gender
quarter_ump_rate_by_gender <- data[, .(
  emp_rate = sum(finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L, 2L, 3L, 4L)]),
  avg_hrs = sum(hrs * finalwt) / sum(finalwt),
  avg_hrs_emp = sum(hrs[lfsstat %in% c(1L,2L)] * finalwt[lfsstat %in% c(1L,2L)]) / sum(finalwt[lfsstat %in% c(1L,2L)])
), by = .(quarter_time,sex)]

# Spread the dataset
quarter_ump_rate_by_gender <-
  melt(quarter_ump_rate_by_gender, id.var = c(1, 2))

quarter_ump_rate_by_gender[, col_combine := paste0(variable, "_", sex)]

quarter_ump_rate_by_gender[, c("sex", "variable") := NULL]

quarter_ump_rate_by_gender <-
  dcast(quarter_ump_rate_by_gender, quarter_time ~ col_combine)

# Merge them
setkey(quarter_ump_rate,"quarter_time")
setkey(quarter_ump_rate_by_gender,"quarter_time")

quarter_agg <- merge(quarter_ump_rate, quarter_ump_rate_by_gender)

# Output the file
save(annual_agg,file = file.path(work_result_address,"annual agg.RData"))
save(quarter_agg,file = file.path(work_result_address,"quarter agg.RData"))

write.csv(
  annual_agg,
  file = file.path(work_result_address, "CAN annual agg.csv"),
  row.names = FALSE
)
write.csv(
  quarter_agg,
  file = file.path(work_result_address, "CAN quarter agg.csv"),
  row.names = FALSE
)
