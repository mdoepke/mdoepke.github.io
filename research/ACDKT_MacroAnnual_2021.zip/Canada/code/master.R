################################
# Main code to generate the Canadian result in Alon, Coskun, Doepke, Koll and
# Tertilt (2021)
#
# Author: Kwok Yan Chiu
################################


rm(list = ls())

####### User input  #######

# Set the working directory
user_dir <- " xxx "

# Set the raw 
work_raw_address <- "raw"
work_clean_address <- "clean"
work_data_address <- "data"
work_code_address <- "code"
work_result_address <- "result"

####### User input  #######

# Set the directory
setwd(user_dir)

# load all the library required
library(reader)
library(stringr)
library(readxl)
library(dplyr)
library(lubridate)
library(data.table)
library(plm)
library(lfe)
library(lmtest)
library(sandwich)
library(jtools)
library(xlsx)

# Step 1: Read the data from prn format
source(file.path(work_code_address,"1_read lfs.R"))


# Step 2: Read the data from prn format
source(file.path(work_code_address,"2_clean lfs.R"))


# Step 3: Micro level regression
source(file.path(work_code_address,"3_regression analysis baseline.R"))


# Step 4: Generate Aggregate Series
source(file.path(work_code_address,"4_aggregate series.R"))


# Step 5: Aggregate for 2019
source(file.path(work_code_address,"5_aggregate 2019.R"))


# Step 6: Aggregate for 2019 to 2020Q3
source(file.path(work_code_address,"6_aggregate 2019Q12020Q3.R"))

