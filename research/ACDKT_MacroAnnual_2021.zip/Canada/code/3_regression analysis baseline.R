# Information ####
# Code to make the cross-sectional regressions for Canada
# Kwok Yan Chiu


# Data file name
data_file_name <- "lfs_data.RData"

# Read the data
load(file.path(work_clean_address,"lfs_data.RData"))
data <- as.data.table(data)

# Read the factors definition
colnames_lfs <- get(load(file.path(work_clean_address,"read_prn_key_1720.RData")))
fl_lfs <- get(load(file.path(work_clean_address,"factorlevels_1720.RData")))

# Population
data <- data[age_12 >= 3L & age_12 <= 8L,,] # 25 years old to 55 years old

# Drop the data after Q3 just to be coherent with the other results
time_start <- make_date(2019,1)
time_end <- make_date(2020,9)

# Pandemic time
covid_start <- "2020-03-01"

# Actual Code ####
# Create variables

# Month, year
setnames(data,"survyear","year")
setnames(data,"survmnth","month")

# set date
data[,time := make_date(year,month)]
data[,quarter := ceiling(month/3)]

# Covid time
data[,covid := ifelse(make_date(year,month) < covid_start,0L,1L)]

# Child groups
# Replace na in Age of youngest kid to 0 group
data[, agyownk := ifelse(is.na(agyownk), 0L,agyownk)]

from_agyownk <- c(0L,1L,2L,3L,4L)
to_child_grp <- c(0L,1L,2L,2L,0L)

data[,child_grp := to_child_grp[match(agyownk,from_agyownk)]]

# 18-24 years is considered to be no kid anymore
# Others follows the original code in agyownk
# 1: 1 - 5
# 2: 6 - 12
# 3: 13 - 17

# simple child group
data[, simp_child_grp := ifelse(agyownk %in% c(2L, 3L), 1L, 0L)]


# Broad Employment
data[, broad_emp := ifelse(lfsstat %in% c(1L,2L),1L,0L)] # Broad employment: Employed regardless of presence or absence from work

# Broad Hours
data[, raw_hours_lwk := ifelse(is.na(atothrs) & broad_emp == 0L,0,atothrs / 10)] # I am using the hours for all jobs
data[raw_hours_lwk > 24*7,.N] # Check if the hours are ridiculous

data[, hours_lwk := log(raw_hours_lwk + (1+raw_hours_lwk^2)^(1/2))]

data[, raw_hours_usual := ifelse(is.na(utothrs) & broad_emp == 0L,0,utothrs / 10)] # I am using the hours for all jobs
data[raw_hours_usual > 24*7,.N] # Check if the hours are ridiculous

data[, hours_usual := log(raw_hours_usual + (1+raw_hours_usual^2)^(1/2))]

# Marital Status
data[,married := ifelse(marstat %in% c(1L),1L,0L)] # Married = married in LFS + living in common law in LFS
data[,with_partner := ifelse(marstat %in% c(1L,2L),1L,0L)]

# Education
data[, simp_educ := c(1L,1L,2L,3L,3L,4L,4L)[match(educ,c(0L,1L,2L,3L,4L,5L,6L))]]

# college indictor
data[,college := ifelse(educ %in% c(5L,6L),1L,0L)]


# Simple Race
# No race data in lfs

# Immigrant status
data[, immigrant := ifelse(immig %in% c(1L, 2L), 1L, 0L)] # Immigrant regardless of landing time => immigrant

# Age groups
data[,age_grp := c(0L,1L,2L,3L,4L,5L,6L)[match(age_12,c(3L,4L,5L,6L,7L,8L))]]

# Occupation
noc40_levels <- fl_lfs[[match("noc_40",colnames_lfs$NAME)]] # Alternative would be noc10
data[,simp_occ := match(noc_40,noc40_levels$code)]
data[,simp_occ := ifelse(is.na(simp_occ) & lfsstat %in% c(3,4),99L,simp_occ)]

# Industry
naics_levels <- fl_lfs[[match("naics_21",colnames_lfs$NAME)]]
data[,simp_ind := match(naics_21,naics_levels$code)]
data[,simp_ind := ifelse(is.na(simp_ind) & lfsstat %in% c(3,4),99L,simp_ind)]

# As factor the many of these groups
data[, sex := factor(sex,
                     levels = c(1L, 2L),
                     labels = c("Male", "Female"))]
data[, child_grp := factor(
  child_grp,
  levels = c(0L, 1L, 2L),
  labels = c("No kid", "small kids", "middle and big kids")
)]
data[, simp_child_grp := factor(
  simp_child_grp,
  levels = c(0L, 1L),
  labels = c("No kid", "School Kids")
)]
data[, married := factor(
  married,
  levels = c(0L, 1L),
  labels = c("Not Married", "Married"),
  ordered = FALSE
)]
data[, with_partner := factor(
  with_partner,
  levels = c(0L, 1L),
  labels = c("Without Partner", "With Partner"),
  ordered = FALSE
)]
data[, age_grp := factor(age_grp)]
data[, simp_educ := factor(simp_educ)]
data[, simp_ind := factor(simp_ind)]
data[, simp_occ := factor(simp_occ)]
data[, month := factor(month)]
data[, year := factor(year)]
data[, quarter_f := factor(quarter)]
data[, college := factor(college)]
data[, immigrant := factor(
  immigrant,
  levels = c(0L, 1L),
  labels = c("non-immigrant", "immigrant")
)]

# Interaction group
# Education and chid grp
data[,college.simp_child_grp := interaction(college,simp_child_grp)]
data[,college.child_grp := interaction(college,child_grp)]

# immigrant and child grp
data[,immigrant.simp_child_grp := interaction(immigrant,simp_child_grp)]
data[,immigrant.child_grp := interaction(immigrant,child_grp)]

# Worktype
data[,work_type := interaction(simp_occ,simp_ind)]
data[,work_type_covid := interaction(simp_occ,simp_ind,covid)]
data[,month_sex := interaction(sex,month)]
data[,year_sex := interaction(sex,year)]
data[,work_type_month_sex := interaction(work_type,sex,month)]
data[,work_type_year_sex := interaction(work_type,sex,year)]

# Covid_month
data[,covid_month := as.factor(covid * as.integer(month))]
data[,month_2020 := as.factor(ifelse(year == "2020" & month != "1",month,0))]

# Summer Education Sector indicator
data[, sum_edu := ifelse(simp_ind == "16" &
                           as.numeric(month) <= 8 & as.numeric(month) >= 6,
                         1L,
                         0L)]

# Save the data
save(data,file = file.path(work_clean_address,"CAN_regression_data.RData"))


# DiD #############

# Restrict the time
# Drop years
data <- data[time >= time_start & time <= time_end,]

#### Table 8a: Overall hours decline ####

hrs1_agg <- felm(
  hours_lwk ~ 1 + covid |
    quarter_f + sum_edu,
  weights = data$finalwt,
  data = data
)

summary(hrs1_agg)

hrs2_agg <- felm(
  hours_lwk ~ 1 + covid |
    quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
  weights = data$finalwt,
  data = data
)

summary(hrs2_agg)

#### Table 7a: Overall employment decline ####

brdemp1_agg <- felm(
  broad_emp ~ 1 + covid |
    quarter_f + sum_edu,
  weights = data$finalwt,
  data = data
)

summary(brdemp1_agg)

brdemp2_agg <- felm(
  broad_emp ~ 1 + covid |
    quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
  weights = data$finalwt,
  data = data
)

summary(brdemp2_agg)


#### Table 7b: Basic gender gap ####
hrs1_bench <-
  felm(
    hours_lwk ~ 1 + covid + sex  + sex:covid + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_bench)

#### Table 7b: Basic gender gap w/ industry & occ controls ####
hrs1_occ <-
  felm(
    hours_lwk ~ 1 + covid + sex  + sex:covid + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_occ)

#### Table 7b: gender gap by child groups ####
hrs1_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + child_grp + sex:child_grp + covid:child_grp + sex:covid:child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_kid)

#### Table 7b: gender gap by child groups w/ industry & occ controls ####
hrs1_occ_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + child_grp + sex:child_grp + covid:child_grp + sex:covid:child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_occ_kid)


#### Table 8b: Basic gender gap ####
brdemp1_bench <-
  felm(
    broad_emp ~ 1 + covid + sex  + sex:covid + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_bench)

#### Table 8b: Basic gender gap w/ industry & occ controls ####
brdemp1_occ <-
  felm(
    broad_emp ~ 1 + covid + sex  + sex:covid + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_occ)

#### Table 8b: gender gap by child groups ####
brdemp1_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + child_grp + sex:child_grp + covid:child_grp + sex:covid:child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_kid)

#### Table 8b: gender gap by child groups w/ industry & occ controls ####
brdemp1_occ_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + child_grp + sex:child_grp + covid:child_grp + sex:covid:child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_occ_kid)


## Education and Race ######################

#### Table A4: without Occupation/Industry controls ####
hrs1_educ_bench <-
  felm(
    hours_lwk ~ 1 + covid + sex + college + sex:college + covid:college + sex:covid:college + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_educ_bench)

#### Table 10: with Occupation/Industry controls ####
hrs1_educ_occ <-
  felm(
    hours_lwk ~ 1 + covid + sex + college + sex:college + covid:college + sex:covid:college + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_educ_occ)

#### Table A4: without Occupation/Industry controls ####
hrs1_educ_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + college.child_grp + sex:college.child_grp + covid:college.child_grp + sex:covid:college.child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_educ_kid)

#### Table 10: with Occupation/Industry controls ####
hrs1_educ_occ_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + college.child_grp + sex:college.child_grp + covid:college.child_grp + sex:covid:college.child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_educ_occ_kid)

#### Table A3: without Occupation/Industry controls ####
brdemp1_educ_bench <-
  felm(
    broad_emp ~ 1 + covid + sex + college + sex:college + covid:college + sex:covid:college + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_educ_bench)

#### Table 11: with Occupation/Industry controls ####
brdemp1_educ_occ <-
  felm(
    broad_emp ~ 1 + covid + sex + college + sex:college + covid:college + sex:covid:college + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_educ_occ)

#### Table A3: without Occupation/Industry controls ####
brdemp1_educ_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + college.child_grp + sex:college.child_grp + covid:college.child_grp + sex:covid:college.child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_educ_kid)

#### Table 11: with Occupation/Industry controls ####
brdemp1_educ_occ_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + college.child_grp + sex:college.child_grp + covid:college.child_grp + sex:covid:college.child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + immigrant + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_educ_occ_kid)


## Race or Migration Background ######


#### Table A6: without Occupation/Industry Controls ####
hrs1_immig_bench <-
  felm(
    hours_lwk ~ 1 + covid + sex + immigrant + sex:immigrant + covid:immigrant + sex:covid:immigrant + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_immig_bench)

#### Table 14: with Occupation/Industry Controls ####
hrs1_immig_occ <-
  felm(
    hours_lwk ~ 1 + covid + sex + immigrant + sex:immigrant + covid:immigrant + sex:covid:immigrant + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_immig_occ)

#### Table A6: without Occupation/Industry Controls ####
hrs1_immig_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + immigrant.child_grp + sex:immigrant.child_grp + covid:immigrant.child_grp + sex:covid:immigrant.child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_immig_kid)

#### Table 14: with Occupation/Industry Controls ####
hrs1_immig_occ_kid <-
  felm(
    hours_lwk ~ 1 + covid + sex + immigrant.child_grp + sex:immigrant.child_grp + covid:immigrant.child_grp + sex:covid:immigrant.child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(hrs1_immig_occ_kid)




#### Table A5: without Occupation/Industry Controls ####
brdemp1_immig_bench <-
  felm(
    broad_emp ~ 1 + covid + sex + immigrant + sex:immigrant + covid:immigrant + sex:covid:immigrant + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_immig_bench)

#### Table 13: with Occupation/Industry Controls ####
brdemp1_immig_occ <-
  felm(
    broad_emp ~ 1 + covid + sex + immigrant + sex:immigrant + covid:immigrant + sex:covid:immigrant + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_immig_occ)

#### Table A5: without Occupation/Industry Controls ####
brdemp1_immig_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + immigrant.child_grp + sex:immigrant.child_grp + covid:immigrant.child_grp + sex:covid:immigrant.child_grp + time + time:sex |
      quarter_f + age_grp + simp_educ + married + sum_edu,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_immig_kid)

#### Table 13: with Occupation/Industry Controls ####
brdemp1_immig_occ_kid <-
  felm(
    broad_emp ~ 1 + covid + sex + immigrant.child_grp + sex:immigrant.child_grp + covid:immigrant.child_grp + sex:covid:immigrant.child_grp + time + time:sex  |
      quarter_f + age_grp + simp_educ + married + sum_edu + work_type_covid,
    weights = data$finalwt,
    data = data
  )
summary(brdemp1_immig_occ_kid)


### Single Mothers ########

# Restrict the sample to mothers

# Impact of marriage
data_mum <- data[child_grp %in% c("small kids","middle and big kids") & sex == "Female",]

# Reset the level of the married
data_mum <- data_mum[,with_partner := relevel(with_partner,ref = "With Partner")]

####  Table 15: hours gap without control #### 
hrs1_singlemum_bench <-
  felm(
    hours_lwk ~ 1 + covid + with_partner + covid:with_partner |
      quarter_f + age_grp + simp_educ + sum_edu,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(hrs1_singlemum_bench)

####  Table 15: hours gap with control #### 
hrs1_singlemum_occ <-
  felm(
    hours_lwk ~ 1 + covid + with_partner + covid:with_partner |
      quarter_f + age_grp + simp_educ + sum_edu + work_type_covid,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(hrs1_singlemum_occ)

####  Table 15: hours gap without control #### 
hrs1_singlemum_kid <-
  felm(
    hours_lwk ~ 1 + covid + with_partner + child_grp + covid:child_grp + with_partner:child_grp + covid:with_partner:child_grp |
      quarter_f + age_grp + simp_educ + sum_edu,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(hrs1_singlemum_kid)

####  Table 15: hours gap with control #### 
hrs1_singlemum_occ_kid <-
  felm(
    hours_lwk ~ 1 + covid + with_partner + child_grp + covid:child_grp + with_partner:child_grp + covid:with_partner:child_grp |
      quarter_f + age_grp + simp_educ + sum_edu + work_type_covid,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(hrs1_singlemum_occ_kid)


####  Table 15: employment gap without control #### 
brdemp1_singlemum_bench <-
  felm(
    broad_emp ~ 1 + covid + with_partner + covid:with_partner |
      quarter_f + age_grp + simp_educ + sum_edu,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(brdemp1_singlemum_bench)


####  Table 15: employment gap with control #### 
brdemp1_singlemum_occ <-
  felm(
    broad_emp ~ 1 + covid + with_partner + covid:with_partner |
      quarter_f + age_grp + simp_educ + sum_edu + work_type_covid,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(brdemp1_singlemum_occ)


####  Table 15: employment gap without control #### 
brdemp1_singlemum_kid <-
  felm(
    broad_emp ~ 1 + covid + with_partner + child_grp + covid:child_grp + with_partner:child_grp + covid:with_partner:child_grp |
      quarter_f + age_grp + simp_educ + sum_edu,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(brdemp1_singlemum_kid)


####  Table 15: employment gap with control #### 
brdemp1_singlemum_occ_kid <-
  felm(
    broad_emp ~ 1 + covid + with_partner + child_grp + covid:child_grp + with_partner:child_grp + covid:with_partner:child_grp |
      quarter_f + age_grp + simp_educ + sum_edu + work_type_covid,
    weights = data_mum$finalwt,
    data = data_mum
  )
summary(brdemp1_singlemum_occ_kid)


## Save the results in an excel file #################

# Aggregate
agg_hrs_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  agg_hrs = NA,
  agg_hrs_w_cont = NA,
  stringsAsFactors = FALSE
)

agg_hrs_table$agg_hrs <- summary(hrs1_agg)$coefficients["covid",c("Estimate","Std. Error","Pr(>|t|)")]
agg_hrs_table$agg_hrs_w_cont <- summary(hrs2_agg)$coefficients["covid",c("Estimate","Std. Error","Pr(>|t|)")]

names(agg_hrs_table) <-
  c(
    "Statistic:",
    "Overall Hrs_lwk (no cont)",
    "Overall Hrs_lwk (with cont)"
  )

# Aggregate
agg_brdemp_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  agg_brdemp = NA,
  agg_brdemp_w_cont = NA,
  stringsAsFactors = FALSE
)

agg_brdemp_table$agg_brdemp <- summary(brdemp1_agg)$coefficients["covid",c("Estimate","Std. Error","Pr(>|t|)")]
agg_brdemp_table$agg_brdemp_w_cont <- summary(brdemp2_agg)$coefficients["covid",c("Estimate","Std. Error","Pr(>|t|)")]

names(agg_brdemp_table) <-
  c(
    "Statistics",
    "Broad employment (no cont)",
    "Broad employment (with cont)"
  )

# Hrs
hrs_lwk_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop1 = NA,
  nokid1 = NA,
  smallkid1 = NA,
  schoolkid1 = NA,
  pop2 = NA,
  nokid2 = NA,
  smallkid2 = NA,
  schoolkid2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result

hrs_lwk_table$pop1 <-
  summary(hrs1_bench)$coefficients["covid:sexFemale", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$nokid1 <-
  summary(hrs1_kid)$coefficients["covid:sexFemale:child_grpNo kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$smallkid1 <-
  summary(hrs1_kid)$coefficients["covid:sexFemale:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$schoolkid1 <-
  summary(hrs1_kid)$coefficients["covid:sexFemale:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

hrs_lwk_table$pop2 <-
  summary(hrs1_occ)$coefficients["covid:sexFemale", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$nokid2 <-
  summary(hrs1_occ_kid)$coefficients["covid:sexFemale:child_grpNo kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$smallkid2 <-
  summary(hrs1_occ_kid)$coefficients["covid:sexFemale:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_lwk_table$schoolkid2 <-
  summary(hrs1_occ_kid)$coefficients["covid:sexFemale:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Rename
names(hrs_lwk_table) <-
  c(
    "Sample:",
    "Population (bench)",
    "No Kids (bench)",
    "Small Kids (bench)",
    "School Kids (bench)",
    "Population (work type)",
    "No Kids (work type)",
    "Small Kids (work type)",
    "School Kids (work type)"
  )

# Employment
brdemp_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop1 = NA,
  nokid1 = NA,
  smallkid1 = NA,
  schoolkid1 = NA,
  pop2 = NA,
  nokid2 = NA,
  smallkid2 = NA,
  schoolkid2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result

brdemp_table$pop1 <-
  summary(brdemp1_bench)$coefficients["covid:sexFemale", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$nokid1 <-
  summary(brdemp1_kid)$coefficients["covid:sexFemale:child_grpNo kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$smallkid1 <-
  summary(brdemp1_kid)$coefficients["covid:sexFemale:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$schoolkid1 <-
  summary(brdemp1_kid)$coefficients["covid:sexFemale:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

brdemp_table$pop2 <-
  summary(brdemp1_occ)$coefficients["covid:sexFemale", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$nokid2 <-
  summary(brdemp1_occ_kid)$coefficients["covid:sexFemale:child_grpNo kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$smallkid2 <-
  summary(brdemp1_occ_kid)$coefficients["covid:sexFemale:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_table$schoolkid2 <-
  summary(brdemp1_occ_kid)$coefficients["covid:sexFemale:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

names(brdemp_table) <-
  c(
    "Sample:",
    "Population (bench)",
    "No Kids (bench)",
    "Small Kids (bench)",
    "School Kids (bench)",
    "Population (work type)",
    "No Kids (work type)",
    "Small Kids (work type)",
    "School Kids (work type)"
  )


# Hours and education
hrs_educ_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop_low1 = NA,
  pop_high1 = NA,
  nokid_low1 = NA,
  nokid_high1 = NA,
  smallkid_low1 = NA,
  smallkid_high1 = NA,
  schoolkid_low1 = NA,
  schoolkid_high1 = NA,
  pop_low2 = NA,
  pop_high2 = NA,
  nokid_low2 = NA,
  nokid_high2 = NA,
  smallkid_low2 = NA,
  smallkid_high2 = NA,
  schoolkid_low2 = NA,
  schoolkid_high2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result
# Population
hrs_educ_table$pop_low1 <-
  summary(hrs1_educ_bench)$coefficients["covid:sexFemale:college0", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$pop_high1 <-
  summary(hrs1_educ_bench)$coefficients["covid:sexFemale:college1", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
hrs_educ_table$nokid_low1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$nokid_high1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
hrs_educ_table$smallkid_low1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$smallkid_high1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
hrs_educ_table$schoolkid_low1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$schoolkid_high1 <-
  summary(hrs1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Population
hrs_educ_table$pop_low2 <-
  summary(hrs1_educ_occ)$coefficients["covid:sexFemale:college0", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$pop_high2 <-
  summary(hrs1_educ_occ)$coefficients["covid:sexFemale:college1", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
hrs_educ_table$nokid_low2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$nokid_high2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
hrs_educ_table$smallkid_low2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$smallkid_high2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
hrs_educ_table$schoolkid_low2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_educ_table$schoolkid_high2 <-
  summary(hrs1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]


names(hrs_educ_table) <-
  c(
    "Sample:",
    "Pop Low Skill (bench)",
    "Pop High Skill (bench)",
    "No Kids Low Skill  (bench)",
    "No Kids High Skill  (bench)",
    "Small Kids Low Skill  (bench)",
    "Small Kids High Skill  (bench)",
    "School Kids Low Skill  (bench)",
    "School Kids High Skill (bench)",
    "Pop Low Skill (work type)",
    "Pop High Skill (work type)",
    "No Kids Low Skill  (work type)",
    "No Kids High Skill  (work type)",
    "Small Kids Low Skill  (work type)",
    "Small Kids High Skill  (work type)",
    "School Kids Low Skill  (work type)",
    "School Kids High Skill  (work type)"
  )

# Employment and education
brdemp_educ_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop_low1 = NA,
  pop_high1 = NA,
  nokid_low1 = NA,
  nokid_high1 = NA,
  smallkid_low1 = NA,
  smallkid_high1 = NA,
  schoolkid_low1 = NA,
  schoolkid_high1 = NA,
  pop_low2 = NA,
  pop_high2 = NA,
  nokid_low2 = NA,
  nokid_high2 = NA,
  smallkid_low2 = NA,
  smallkid_high2 = NA,
  schoolkid_low2 = NA,
  schoolkid_high2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result
# Population
brdemp_educ_table$pop_low1 <-
  summary(brdemp1_educ_bench)$coefficients["covid:sexFemale:college0", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$pop_high1 <-
  summary(brdemp1_educ_bench)$coefficients["covid:sexFemale:college1", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
brdemp_educ_table$nokid_low1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$nokid_high1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
brdemp_educ_table$smallkid_low1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$smallkid_high1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
brdemp_educ_table$schoolkid_low1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp0.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$schoolkid_high1 <-
  summary(brdemp1_educ_kid)$coefficients["covid:sexFemale:college.child_grp1.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Population
brdemp_educ_table$pop_low2 <-
  summary(brdemp1_educ_occ)$coefficients["covid:sexFemale:college0", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$pop_high2 <-
  summary(brdemp1_educ_occ)$coefficients["covid:sexFemale:college1", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
brdemp_educ_table$nokid_low2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$nokid_high2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
brdemp_educ_table$smallkid_low2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$smallkid_high2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
brdemp_educ_table$schoolkid_low2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp0.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_educ_table$schoolkid_high2 <-
  summary(brdemp1_educ_occ_kid)$coefficients["covid:sexFemale:college.child_grp1.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]


names(brdemp_educ_table) <-
  c(
    "Sample:",
    "Pop Low Skill (bench)",
    "Pop High Skill (bench)",
    "No Kids Low Skill  (bench)",
    "No Kids High Skill  (bench)",
    "Small Kids Low Skill  (bench)",
    "Small Kids High Skill  (bench)",
    "School Kids Low Skill  (bench)",
    "School Kids High Skill (bench)",
    "Pop Low Skill (work type)",
    "Pop High Skill (work type)",
    "No Kids Low Skill  (work type)",
    "No Kids High Skill  (work type)",
    "Small Kids Low Skill  (work type)",
    "Small Kids High Skill  (work type)",
    "School Kids Low Skill  (work type)",
    "School Kids High Skill  (work type)"
  )

# Hours and Immigration
hrs_immig_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop_nonimmig1 = NA,
  pop_immig1 = NA,
  nokid_nonimmig1 = NA,
  nokid_immig1 = NA,
  smallkid_nonimmig1 = NA,
  smallkid_immig1 = NA,
  schoolkid_nonimmig1 = NA,
  schoolkid_immig1 = NA,
  pop_nonimmig2 = NA,
  pop_immig2 = NA,
  nokid_nonimmig2 = NA,
  nokid_immig2 = NA,
  smallkid_nonimmig2 = NA,
  smallkid_immig2 = NA,
  schoolkid_nonimmig2 = NA,
  schoolkid_immig2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result
# Population
hrs_immig_table$pop_nonimmig1 <-
  summary(hrs1_immig_bench)$coefficients["covid:sexFemale:immigrantnon-immigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$pop_immig1 <-
  summary(hrs1_immig_bench)$coefficients["covid:sexFemale:immigrantimmigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
hrs_immig_table$nokid_nonimmig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$nokid_immig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
hrs_immig_table$smallkid_nonimmig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$smallkid_immig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
hrs_immig_table$schoolkid_nonimmig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$schoolkid_immig1 <-
  summary(hrs1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Population
hrs_immig_table$pop_nonimmig2 <-
  summary(hrs1_immig_occ)$coefficients["covid:sexFemale:immigrantnon-immigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$pop_immig2 <-
  summary(hrs1_immig_occ)$coefficients["covid:sexFemale:immigrantimmigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
hrs_immig_table$nokid_nonimmig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$nokid_immig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
hrs_immig_table$smallkid_nonimmig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$smallkid_immig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
hrs_immig_table$schoolkid_nonimmig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
hrs_immig_table$schoolkid_immig2 <-
  summary(hrs1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]


names(hrs_immig_table) <-
  c(
    "Sample:",
    "Pop White (bench)",
    "Pop Non-white (bench)",
    "No Kids White  (bench)",
    "No Kids Non-white  (bench)",
    "Small Kids White  (bench)",
    "Small Kids Non-white  (bench)",
    "School Kids White  (bench)",
    "School Kids Non-white  (bench)",
    "Pop White (work type)",
    "Pop Non-white (work type)",
    "No Kids White  (work type)",
    "No Kids Non-white  (work type)",
    "Small Kids White  (work type)",
    "Small Kids Non-white  (work type)",
    "School Kids White  (work type)",
    "School Kids Non-white  (work type)"
  )

# Employment and Immigration
brdemp_immig_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  pop_nonimmig1 = NA,
  pop_immig1 = NA,
  nokid_nonimmig1 = NA,
  nokid_immig1 = NA,
  smallkid_nonimmig1 = NA,
  smallkid_immig1 = NA,
  schoolkid_nonimmig1 = NA,
  schoolkid_immig1 = NA,
  pop_nonimmig2 = NA,
  pop_immig2 = NA,
  nokid_nonimmig2 = NA,
  nokid_immig2 = NA,
  smallkid_nonimmig2 = NA,
  smallkid_immig2 = NA,
  schoolkid_nonimmig2 = NA,
  schoolkid_immig2 = NA,
  stringsAsFactors = FALSE
)

# Paste the result
# Population
brdemp_immig_table$pop_nonimmig1 <-
  summary(brdemp1_immig_bench)$coefficients["covid:sexFemale:immigrantnon-immigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$pop_immig1 <-
  summary(brdemp1_immig_bench)$coefficients["covid:sexFemale:immigrantimmigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
brdemp_immig_table$nokid_nonimmig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$nokid_immig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
brdemp_immig_table$smallkid_nonimmig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$smallkid_immig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
brdemp_immig_table$schoolkid_nonimmig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$schoolkid_immig1 <-
  summary(brdemp1_immig_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Population
brdemp_immig_table$pop_nonimmig2 <-
  summary(brdemp1_immig_occ)$coefficients["covid:sexFemale:immigrantnon-immigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$pop_immig2 <-
  summary(brdemp1_immig_occ)$coefficients["covid:sexFemale:immigrantimmigrant", c("Estimate", "Std. Error", "Pr(>|t|)")]

# No kid
brdemp_immig_table$nokid_nonimmig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$nokid_immig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.No kid", c("Estimate", "Std. Error", "Pr(>|t|)")]

# small kid
brdemp_immig_table$smallkid_nonimmig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$smallkid_immig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.small kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# school kid
brdemp_immig_table$schoolkid_nonimmig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpnon-immigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]
brdemp_immig_table$schoolkid_immig2 <-
  summary(brdemp1_immig_occ_kid)$coefficients["covid:sexFemale:immigrant.child_grpimmigrant.middle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]


names(brdemp_immig_table) <-
  c(
    "Sample:",
    "Pop White (bench)",
    "Pop Non-white (bench)",
    "No Kids White  (bench)",
    "No Kids Non-white  (bench)",
    "Small Kids White  (bench)",
    "Small Kids Non-white  (bench)",
    "School Kids White  (bench)",
    "School Kids Non-white  (bench)",
    "Pop White (work type)",
    "Pop Non-white (work type)",
    "No Kids White  (work type)",
    "No Kids Non-white  (work type)",
    "Small Kids White  (work type)",
    "Small Kids Non-white  (work type)",
    "School Kids White  (work type)",
    "School Kids Non-white  (work type)"
  )

# Single Mum
singlemum_table <- data.frame(
  Statistic = c("Coefficient", "std error", "p-value"),
  smallkid_hrs1 = NA,
  schoolkid_hrs1 = NA,
  smallkid_hrs2 = NA,
  schoolkid_hrs2 = NA,
  smallkid_brdemp1 = NA,
  schoolkid_brdemp1 = NA,
  smallkid_brdemp2 = NA,
  schoolkid_brdemp2 = NA,
  stringsAsFactors = FALSE
)


# Without the work type control
singlemum_table$smallkid_hrs1 <-
  summary(hrs1_singlemum_kid)$coefficients["covid:with_partnerWithout Partner:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

singlemum_table$schoolkid_hrs1 <-
  summary(hrs1_singlemum_kid)$coefficients["covid:with_partnerWithout Partner:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# With the work type control
singlemum_table$smallkid_hrs2 <-
  summary(hrs1_singlemum_occ_kid)$coefficients["covid:with_partnerWithout Partner:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

singlemum_table$schoolkid_hrs2 <-
  summary(hrs1_singlemum_occ_kid)$coefficients["covid:with_partnerWithout Partner:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# Without the work type control

singlemum_table$smallkid_brdemp1 <-
  summary(brdemp1_singlemum_kid)$coefficients["covid:with_partnerWithout Partner:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

singlemum_table$schoolkid_brdemp1 <-
  summary(brdemp1_singlemum_kid)$coefficients["covid:with_partnerWithout Partner:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

# With the work type control

singlemum_table$smallkid_brdemp2 <-
  summary(brdemp1_singlemum_occ_kid)$coefficients["covid:with_partnerWithout Partner:child_grpsmall kids", c("Estimate", "Std. Error", "Pr(>|t|)")]

singlemum_table$schoolkid_brdemp2 <-
  summary(brdemp1_singlemum_occ_kid)$coefficients["covid:with_partnerWithout Partner:child_grpmiddle and big kids", c("Estimate", "Std. Error", "Pr(>|t|)")]



names(singlemum_table) <-
  c(
    "Sample:",
    "Hours Single Mom - Small Kids (bench)",
    "Hours Single Mom - School Kids (bench)",
    "Hours Single Mom - Small Kids (work type)",
    "Hours Single Mom - School Kids (work type)",
    "Employment Single Mom - Small Kids (bench)",
    "Employment Single Mom - School Kids (bench)",
    "Employment Single Mom - Small Kids (work type)",
    "Employment Single Mom - School Kids (work type)"
  )

# Save the result
write.xlsx(
  agg_hrs_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 8a",
  row.names = FALSE
)

write.xlsx(
  agg_brdemp_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 7a",
  row.names = FALSE,
  append = TRUE
)

write.xlsx(
  hrs_lwk_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 8b",
  row.names = FALSE,
  append = TRUE
)


write.xlsx(
  brdemp_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 7b",
  row.names = FALSE,
  append = TRUE
)


write.xlsx(
  hrs_educ_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 12",
  row.names = FALSE,
  append = TRUE
)

write.xlsx(
  brdemp_educ_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 11",
  row.names = FALSE,
  append = TRUE
)

write.xlsx(
  hrs_immig_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 14",
  row.names = FALSE,
  append = TRUE
)

write.xlsx(
  brdemp_immig_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 13",
  row.names = FALSE,
  append = TRUE
)

write.xlsx(
  singlemum_table,
  file = file.path(work_result_address, "Canada_DiD.xlsx"),
  sheetName = "Table 15",
  row.names = FALSE,
  append = TRUE
)