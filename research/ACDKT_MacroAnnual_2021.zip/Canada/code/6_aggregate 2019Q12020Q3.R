#################################################################
# Code to generate aggregate using the dataset for regression
# 
# Kwok Yan Chiu


# Load the data set used for regression
load(file.path(work_clean_address,"CAN_regression_data.RData"))

# Limit the time
time_start <- make_date(2019,1)
time_end <- make_date(2020,9)

data <- data[time >= time_start & time <= time_end,]

## Compute the aggregates
regdata_sum <- data[, .(
  female = sum(finalwt[sex == "Female"])/sum(finalwt),
  married = sum(finalwt[married == "Married"])/sum(finalwt),
  single_mum = sum(finalwt[sex == "Female" & with_partner == "Without Partner" & child_grp %in% c("small kids", "middle and big kids")])/sum(finalwt),
  preK_kid = sum(finalwt[child_grp == "small kids"])/sum(finalwt),
  sch_kid = sum(finalwt[child_grp == "middle and big kids"])/sum(finalwt),
  immigrant = sum(finalwt[immigrant == "immigrant"])/sum(finalwt),
  college = sum(finalwt[college == "1"])/sum(finalwt),
  hours_lwk = sum(raw_hours_lwk * finalwt)/sum(finalwt),
  broad_emp = sum(broad_emp * finalwt) / sum(finalwt),
  sample_size = .N
)]

# Save the data
write.xlsx(
  regdata_sum,
  file = file.path(work_result_address, "CAN regdata Aggregates.xlsx"),
  sheetName = "summary",
  row.names = FALSE
)