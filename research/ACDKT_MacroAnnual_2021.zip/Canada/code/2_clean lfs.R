# Code to combine the Canada LFS data
# Kwok Yan Chiu


date_range <- seq(from = as.Date("1998-01-01"),to = as.Date("2020-11-01"),by = "month")

source(file.path(work_code_address,"combine years.R"))

data <- combine_years_lfs(work_data_address,"2017-01-01","2020-11-01","lfs")

###
# Potentially more cleaning/merging here



###


# Save the data
save(data,file = file.path(work_clean_address,"lfs_data.RData"))
