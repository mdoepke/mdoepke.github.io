# Transform the documentation files to something readable
# Kwok Yan Chiu

# 4 outputs are saved
# For 1976-2016, a table for all the variables and a list of the levels of factors
# For 2017-2020, a table for all the variables and a list of the levels of factors

# Read the documentation before 2016
data_doc_7616 <-
  read_xls(
    file.path(work_raw_address, "Documentation", "Microc - layout 1976 - 2016.xls"),
    skip = 1,
    col_name = TRUE
  )

# Remove the row with no content
data_doc_7616 <- data_doc_7616[apply(data_doc_7616,1,function(x) any(!is.na(x))),]

# Convert the name to the lowercase
data_doc_7616[,"NAME"] <- tolower(data_doc_7616[["NAME"]])

# Extract the columns infor for reading the prn file
lfs_col_info_7616 <- data_doc_7616[,c("POS","LENGTH","START","NAME","ITEM LABEL")]

lfs_col_info_7616 <- lfs_col_info_7616 %>% filter(!is.na(POS))

# Extract the levels
lfs_level_info_7616 <- as.list(rep(NA,nrow(lfs_col_info_7616)))

for (i in 1:nrow(lfs_col_info_7616)){
  # Find the row number of the item i
  i_name <- lfs_col_info_7616$NAME[i]
  
  read_from <- match(i_name,data_doc_7616$NAME)
  if (i < nrow(lfs_col_info_7616)){
    next_i_name <- lfs_col_info_7616$NAME[i+1]
    
    read_until <- match(next_i_name,data_doc_7616$NAME) - 1
  } else {
    read_until <- nrow(data_doc_7616)
  }
  
  if (read_until > read_from){
    extracted_table <- data_doc_7616[read_from:read_until,c("ITEM LABEL","CODE")]
    
    extracted_table <- extracted_table %>% filter(!is.na(CODE))
    
    lfs_level_info_7616[[i]] <- list(code = as.integer(extracted_table$CODE),label = extracted_table$`ITEM LABEL`)
  }
}

# Read the documentation since 2017
data_doc_1720 <-
  read_xlsx(
    file.path(work_raw_address, "Documentation", "LFS PUMF Variable Listing 2017_final_revised 2019.xlsx"),
    col_name = TRUE
  )

# Remove the row with no content
data_doc_1720 <- data_doc_1720[apply(data_doc_1720,1,function(x) any(!is.na(x))),]

names(data_doc_1720)[1:6] <- c("POS","LENGTH","START","END","NAME","ITEM LABEL")

# Extract the columns infor for reading the prn file
lfs_col_info_1720 <- data_doc_1720[,c("POS","LENGTH","START","NAME","ITEM LABEL")]

lfs_col_info_1720 <- lfs_col_info_1720 %>% filter(!is.na(POS))

# Extract the levels
lfs_level_info_1720 <- as.list(rep(NA,nrow(lfs_col_info_1720)))

# Rename the data_doc_1720 to make it readable
names(data_doc_1720) <-
  c(
    "POS",
    "LENGTH",
    "START",
    "END",
    "NAME",
    "ITEM LABEL",
    "Variable Name F",
    "Note 1 E",
    "Note 1 F",
    "Note 2 E",
    "Note 2 F",
    "Code",
    "Label E",
    "Label F"
  )

for (i in 1:nrow(lfs_col_info_1720)){
  # Find the row number of the item i
  i_name <- lfs_col_info_1720$NAME[i]
  
  read_from <- match(i_name,data_doc_1720$NAME)
  
  if (i < nrow(lfs_col_info_1720)){
    next_i_name <- lfs_col_info_1720$NAME[i+1]
    
    read_until <- match(next_i_name,data_doc_1720$NAME) - 1
  } else {
    read_until <- nrow(data_doc_1720)
  }
  
  if (read_until > read_from){
    extracted_table <- data_doc_1720[read_from:read_until,c("Label E","Code")]
    
    extracted_table <- extracted_table %>% mutate(Code = as.integer(Code))
    
    extracted_table <- extracted_table %>% filter(!is.na(Code))
    
    lfs_level_info_1720[[i]] <- list(code = as.integer(extracted_table$Code),label = extracted_table$`Label E`)
  }
}

# Save the mapping
save(lfs_col_info_7616,file = file.path(work_clean_address,"read_prn_key_7616.RData"))
save(lfs_col_info_1720,file = file.path(work_clean_address,"read_prn_key_1720.RData"))

save(lfs_level_info_7616,file = file.path(work_clean_address,"factorlevels_7616.RData"))
save(lfs_level_info_1720,file = file.path(work_clean_address,"factorlevels_1720.RData"))