# Code to read the Canada LFS data

date_range <- seq(from = as.Date("1976-01-01"),to = as.Date("2020-11-01"),by = "month")


source(file.path(work_code_address,"move and unzip lfs.R"))

# Make the documentation
source(file.path(work_code_address,"read the documentation.R"))

# ======  Read all the .prn file ======  #

# A function to split the columns
read_prn <- function(prn,start_ind,col_len,var_name){
  # Use an empty dataframe to contain the information
  data <- data.frame(matrix(NA, nrow = length(prn),ncol = length(start_ind)))
  
  # Fill up the dataframe
  for (i in 1:length(start_ind)){
    # raw string for column i 
    str_temp <- str_sub(prn,start = start_ind[i],end = start_ind[i] + col_len[i] - 1)
    
    data[[i]] <- as.integer(str_temp)
  }
  
  # Set the name for the dataframe
  names(data) <- var_name
  
  # return the dataframe
  return(data)
}



# Read all the prn file and output an RData file to work with
date_abbre <- as.character(format(date_range,format = "%m%y"))
file_names <- paste0("pub",date_abbre,".prn")

# Read all the file name
all_files <- list.files(path = work_dir_data)
prn_files_name <- all_files[all_files %in% file_names]

# Read all the files up to 2016
date_abbre_7616 <- as.character(format(date_range[date_range <= "2016-12-01"],format = "%m%y"))
file_names_7616 <- paste0("pub",date_abbre_7616,".prn")

for (i in 1:length(file_names_7616)){
  # Read the file
  data <-
    read.table(
      file.path(work_data_address, file_names_7616[i]),
      header = F,
      sep = "|",
      stringsAsFactors = FALSE
    )
  
  # Only keep the vector version of the raw
  data <- data[[1]]
  
  data <- read_prn(
    data,
    lfs_col_info_7616$POS[1:81],
    lfs_col_info_7616$LENGTH[1:81],
    lfs_col_info_7616$NAME[1:81]
  )
  
  # Then save it
  save(data,file = file.path(work_data_address, paste0("lfs",date_abbre_7616[i],".RData")))
}

# Save the files up to 2020
date_abbre_1720 <- setdiff(date_abbre,date_abbre_7616)
file_names_1720 <- paste0("pub",date_abbre_1720,".prn")

for (i in 1:length(file_names_1720)){
  # Read the file
  data <-
    read.table(
      file.path(work_data_address, file_names_1720[i]),
      header = F,
      sep = "|",
      stringsAsFactors = FALSE
    )
  
  # Only keep the vector version of the raw
  data <- data[[1]]
  
  data <- read_prn(
    data,
    lfs_col_info_1720$POS,
    lfs_col_info_1720$LENGTH,
    lfs_col_info_1720$NAME
  )
  
  # Then save it
  save(data,file = file.path(work_data_address, paste0("lfs",date_abbre_1720[i],".RData")))
}