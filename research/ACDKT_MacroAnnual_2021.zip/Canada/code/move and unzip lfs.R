# Code to unzip and move all the .prn files into one folder
# Kwok Yan Chiu

# Unzip the raw file
unzip(file.path(raw_dir,"MICRO 2017_2019.zip"),exdir = file.path(work_raw_address,"1719"))
unzip(file.path(raw_dir,"MICRO_2015_2016.zip"),exdir = file.path(work_raw_address,"1516"))
unzip(file.path(raw_dir,"MICRO_2001_2014.zip"),exdir = file.path(work_raw_address,"0114"))
unzip(file.path(raw_dir,"MICRO_1976_2000.zip"),exdir = file.path(work_raw_address,"7600"))

# Move the 2020 file
dir.create(file.path(work_raw_address,"2020"))
file.copy(from = file.path(raw_dir,"MICRO 2020"),to = file.path(work_raw_address,"2020"), recursive=TRUE)

# Unzip the documentation
unzip(file.path(raw_dir,"Documentation.zip"),exdir = file.path(work_raw_address))

# Extract all the .prn file

# For 2017_2019
# Get names
file_dir <- file.path(work_raw_address,"1719")

fnames <- list.files(path = file_dir)
# Unzip all of them
for (fname in fnames){
  unzip(file.path(file_dir,fname),exdir = work_data_address)
}

# Somehow 2017 Dec was in a different folder
file.copy(from = file.path(work_data_address,"mic1217","pub1217.prn"),to = work_data_address)

# For 2015_2016
file_dir <- file.path(work_raw_address,"1516","MICRO_2015_2016")

fnames <- list.files(path = file_dir)
# Move all of them
for (fname in fnames){
  file.copy(from = file.path(file_dir,fnames),to = work_data_address)
}

# For 2001_2014
file_dir <- file.path(work_raw_address,"0114","MICRO_2001_2014_REV")

fnames <- list.files(path = file_dir)
# Move all of them
for (fname in fnames){
  file.copy(from = file.path(file_dir,fnames),to = work_data_address)
}

# For 2020
file_dir <- file.path(work_raw_address,"2020","MICRO 2020")

fnames <- list.files(path = file_dir)
# Unzip all of them
for (fname in fnames){
  unzip(file.path(file_dir,fname),exdir = work_data_address)
}

# For 1976-2000
file_dir <- file.path(work_raw_address,"7600","MICRO_1976_2000")

fnames <- list.files(path = file_dir)
# Move all of them
for (fname in fnames){
  file.copy(from = file.path(file_dir,fnames),to = work_data_address)
}