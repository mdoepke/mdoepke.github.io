# Combine multiple years of data
# Kwok Yan Chiu
#
# A function to read multiple years of lfs and combine them into a dataframe

# Note that I am assuming that the formats are the same. If the headings are
# different then this function will not work properly

combine_years_lfs <- function(dir_path,date_begin,date_end,file_prefix,header_selected = NULL){
  # Read the files within that range
  date_range <- seq(from = as.Date(date_begin),to = as.Date(date_end),by = "month")
  
  # Find the files for that time range
  date_abbre <- as.character(format(date_range,format = "%m%y"))
  file_names <- paste0(file_prefix,date_abbre,".RData")
  
  # List the available files
  all_files <- list.files(path = dir_path)
  
  files_to_read <- intersect(all_files,file_names)
  
  # Read all of those file and rbind
  if (is.null(header_selected)){
    all_files <- lapply(files_to_read,function(x) get(load(file.path(dir_path,x))))
  } else {
    all_files <- lapply(files_to_read,function(x) get(load(file.path(dir_path,x)))[,header_selected])
  }
  
  # Rbind
  data <- do.call(rbind,all_files)
  
  # Output
  return(data)
}