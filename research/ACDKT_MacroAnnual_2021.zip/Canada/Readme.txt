Steps to generate the Canadian result for Alon, Coskun, Doepke, Koll and Tertilt (2021):

1. Save the raw data in [raw]. They are NOT included in the replication.

2. Open Code/master.R, set the user path

user_dir <- "C:/[Your working folder]"

3. Run only the master.R. It generates the following files in result directory

Canada_DiD.xlsx : Regression result for Table 7a, 7b, 8a, 8b, 11, 12, 13, 14, 15

[not included in replication files] CAN annual agg.csv: aggregate annual unemployment series used for Figure 1, 3, 4, 5, 6. Table 1, 2, 3, 4, 5

[not included in replication files] CAN quarter agg.csv: aggregate quarterly unemployment series used for Figure 1, 3, 4, 5, 6. Table 1, 2, 3, 4, 5

Employed Individuals by type.csv : Table A1

mother labour supply.csv : Table A2

nonmother labour supply.csv : Table A2

father labour supply.csv : Table A2

nonfather labour supply.csv : Table A2

[not included in replication files] CAN regdata Aggregates.xlsx : Table C8
