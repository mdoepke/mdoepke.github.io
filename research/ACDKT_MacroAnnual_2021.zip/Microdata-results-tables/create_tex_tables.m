%% load data:
clear

%NOTE: always open excel file and klick somewhere and save it - otherwise matlab is somehow not able to execute xlsread - i.e. it cannot find the sheet names. 

% setting local working directory for data (for OS X and Windows)
global out_dir;
global input_dir;
global git_workdir;

% out_dir: location with DiD Excel sheet results of all countries
out_dir = '...//output//';
% input_dir: location with DiD Excel sheet results of all countries
input_dir = '...//regression_results//';
% git_workdir: location with matlab files
git_workdir = '...//matlab2latex//';        


addpath(genpath(git_workdir));


sheets = {'Table 8a';'Table 7a';'Table 8b';'Table 7b';...
     'Table 12';'Table 11';'Table 15';'Table 14';'Table 13';'Table 16'};


%% loop over sheets scenarios
for i = 1:length(sheets)

    sheet = sheets{i};

    vals_US = xlsread(strcat(input_dir,'USA_DiD.xlsx'),sheet);
    vals_UK = xlsread(strcat(input_dir,'UK_DiD.xlsx'),sheet);
    vals_NL = xlsread(strcat(input_dir,'NL_DiD.xlsx'),sheet);        

    % no results on telecommuting for Can, ESP, GER
    if ~any(strcmp(sheet,'Table 16'))
        vals_GER = xlsread(strcat(input_dir,'Germany_DiD.xlsx'),sheet);
        vals_ESP = xlsread(strcat(input_dir,'Spain_DiD.xlsx'),sheet);
        vals_CAN = xlsread(strcat(input_dir,'Canada_DiD.xlsx'),sheet);
    end


    % Overall employment and hours decline: 
    if any(strcmp(sheet,'Table 8a')) | any(strcmp(sheet,'Table 7a')) 

        % extract estimation coefficients and p-values:
        vals_out = [vals_US(1,1) vals_CAN(1,1) vals_GER(1,1) vals_NL(1,1) vals_ESP(1,1) vals_UK(1,1); ...
                    vals_US(3,1) vals_CAN(3,1) vals_GER(3,1) vals_NL(3,1) vals_ESP(3,1) vals_UK(3,1)];

        vals_out(1,:) = vals_out(1,:)*100;

        if any(strcmp(sheet,'Table 8a'))
            outpath = strcat(out_dir,'overall_hours.tex');
            rownames = {'Overall hours decline', ''};
        
        elseif any(strcmp(sheet,'Table 7a'))     
            outpath = strcat(out_dir,'overall_employment.tex');
            rownames = {'Overall employment decline', ''};
        end

        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out
    end


    % Main tables: Benchmark and w/ occ x industry controls
    if any(strcmp(sheet,'Table 8b')) | any(strcmp(sheet,'Table 7b'))

        % extract estimation coefficients and p-values:
        vals_out = [vals_US(1,1) vals_CAN(1,1) vals_GER(1,1) vals_NL(1,1) vals_ESP(1,1) vals_UK(1,1); ...
                    vals_US(3,1) vals_CAN(3,1) vals_GER(3,1) vals_NL(3,1) vals_ESP(3,1) vals_UK(3,1); ...
                    vals_US(1,3) vals_CAN(1,3) NaN vals_NL(1,3) vals_ESP(1,3) vals_UK(1,3); ...
                    vals_US(3,3) vals_CAN(3,3) NaN vals_NL(3,3) vals_ESP(3,3) vals_UK(3,3); ...
                    vals_US(1,4) vals_CAN(1,4) vals_GER(1,3) vals_NL(1,4) vals_ESP(1,4) vals_UK(1,4); ...
                    vals_US(3,4) vals_CAN(3,4) vals_GER(3,3) vals_NL(3,4) vals_ESP(3,4) vals_UK(3,4); ...
                    vals_US(1,2) vals_CAN(1,2) vals_GER(1,2) vals_NL(1,2) vals_ESP(1,2) vals_UK(1,2); ...
                    vals_US(3,2) vals_CAN(3,2) vals_GER(3,2) vals_NL(3,2) vals_ESP(3,2) vals_UK(3,2); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        if any(strcmp(sheet,'Table 8b')) 
            outpath = strcat(out_dir,'hours_main_bench.tex');
            rownames = {'Basic gender gap ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids  ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 7b'))
            outpath = strcat(out_dir,'emp_main_bench.tex');
            rownames = {'Basic gender gap ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids  ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};
        end
 
            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out

        % extract estimation coefficients and p-values:
        vals_out = [vals_US(1,5) vals_CAN(1,5) vals_GER(1,4) vals_NL(1,5) vals_ESP(1,5) vals_UK(1,5); ...
                    vals_US(3,5) vals_CAN(3,5) vals_GER(3,4) vals_NL(3,5) vals_ESP(3,5) vals_UK(3,5); ...
                    vals_US(1,7) vals_CAN(1,7) NaN vals_NL(1,7) vals_ESP(1,7) vals_UK(1,7); ...
                    vals_US(3,7) vals_CAN(3,7) NaN vals_NL(3,7) vals_ESP(3,7) vals_UK(3,7); ...
                    vals_US(1,8) vals_CAN(1,8) vals_GER(1,6) vals_NL(1,8) vals_ESP(1,8) vals_UK(1,8); ...
                    vals_US(3,8) vals_CAN(3,8) vals_GER(3,6) vals_NL(3,8) vals_ESP(3,8) vals_UK(3,8); ...
                    vals_US(1,6) vals_CAN(1,6) vals_GER(1,5) vals_NL(1,6) vals_ESP(1,6) vals_UK(1,6); ...
                    vals_US(3,6) vals_CAN(3,6) vals_GER(3,5) vals_NL(3,6) vals_ESP(3,6) vals_UK(3,6); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

 
        if any(strcmp(sheet,'Table 8b')) 
            outpath = strcat(out_dir,'hours_main_wIndOcc.tex');
            rownames = {'w/ industry \& occ controls ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids  ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 7b'))
            outpath = strcat(out_dir,'emp_main_wIndOcc.tex');
            rownames = {'w/ industry \& occ controls ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids  ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};
        end

            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out        
    end


    % Education: a) Benchmark (w/o occ x ind) for low and high education and b) w/ occ x ind for low and high education
    if any(strcmp(sheet,'Table 12')) | any(strcmp(sheet,'Table 11'))

        % extract estimation coefficients and p-values for HIGH educated in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,2) vals_CAN(1,2) vals_GER(1,2) vals_NL(1,2) vals_ESP(1,2) vals_UK(1,2); ...
                    vals_US(3,2) vals_CAN(3,2) vals_GER(3,2) vals_NL(3,2) vals_ESP(3,2) vals_UK(3,2); ...
                    vals_US(1,6) vals_CAN(1,6) NaN vals_NL(1,6) vals_ESP(1,6) vals_UK(1,6); ...
                    vals_US(3,6) vals_CAN(3,6) NaN vals_NL(3,6) vals_ESP(3,6) vals_UK(3,6); ...
                    vals_US(1,8) vals_CAN(1,8) vals_GER(1,6) vals_NL(1,8) vals_ESP(1,8) vals_UK(1,8); ...
                    vals_US(3,8) vals_CAN(3,8) vals_GER(3,6) vals_NL(3,8) vals_ESP(3,8) vals_UK(3,8); ...
                    vals_US(1,4) vals_CAN(1,4) vals_GER(1,4) vals_NL(1,4) vals_ESP(1,4) vals_UK(1,4); ...
                    vals_US(3,4) vals_CAN(3,4) vals_GER(3,4) vals_NL(3,4) vals_ESP(3,4) vals_UK(3,4); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        if any(strcmp(sheet,'Table 12')) 
            outpath = strcat(out_dir,'hours_highEduc_bench.tex');
            rownames = {'BA degree or higher ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 11'))
            outpath = strcat(out_dir,'emp_highEduc_bench.tex');
            rownames = {'BA degree or higher ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};
        end
 
            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % extract estimation coefficients and p-values for LOW educated in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,1) vals_CAN(1,1) vals_GER(1,1) vals_NL(1,1) vals_ESP(1,1) vals_UK(1,1); ...
                    vals_US(3,1) vals_CAN(3,1) vals_GER(3,1) vals_NL(3,1) vals_ESP(3,1) vals_UK(3,1); ...
                    vals_US(1,5) vals_CAN(1,5) NaN vals_NL(1,5) vals_ESP(1,5) vals_UK(1,5); ...
                    vals_US(3,5) vals_CAN(3,5) NaN vals_NL(3,5) vals_ESP(3,5) vals_UK(3,5); ...
                    vals_US(1,7) vals_CAN(1,7) vals_GER(1,5) vals_NL(1,7) vals_ESP(1,7) vals_UK(1,7); ...
                    vals_US(3,7) vals_CAN(3,7) vals_GER(3,5) vals_NL(3,7) vals_ESP(3,7) vals_UK(3,7); ...
                    vals_US(1,3) vals_CAN(1,3) vals_GER(1,3) vals_NL(1,3) vals_ESP(1,3) vals_UK(1,3); ...
                    vals_US(3,3) vals_CAN(3,3) vals_GER(3,3) vals_NL(3,3) vals_ESP(3,3) vals_UK(3,3); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;
 
        if any(strcmp(sheet,'Table 12')) 
            outpath = strcat(out_dir,'hours_lowEduc_bench.tex');
            rownames = {'Less than BA degree ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 11'))
            outpath = strcat(out_dir,'emp_lowEduc_bench.tex');
            rownames = {'Less than BA degree ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};
        end

            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out   



        % extract estimation coefficients and p-values for HIGH educated in w/ occ x ind setting
        vals_out = [vals_US(1,10) vals_CAN(1,10) vals_GER(1,8) vals_NL(1,10) vals_ESP(1,10) vals_UK(1,10); ...
                    vals_US(3,10) vals_CAN(3,10) vals_GER(3,8) vals_NL(3,10) vals_ESP(3,10) vals_UK(3,10); ...
                    vals_US(1,14) vals_CAN(1,14) NaN vals_NL(1,14) vals_ESP(1,14) vals_UK(1,14); ...
                    vals_US(3,14) vals_CAN(3,14) NaN vals_NL(3,14) vals_ESP(3,14) vals_UK(3,14); ...
                    vals_US(1,16) vals_CAN(1,16) vals_GER(1,12) vals_NL(1,16) vals_ESP(1,16) vals_UK(1,16); ...
                    vals_US(3,16) vals_CAN(3,16) vals_GER(3,12) vals_NL(3,16) vals_ESP(3,16) vals_UK(3,16); ...
                    vals_US(1,12) vals_CAN(1,12) vals_GER(1,10) vals_NL(1,12) vals_ESP(1,12) vals_UK(1,12); ...
                    vals_US(3,12) vals_CAN(3,12) vals_GER(3,10) vals_NL(3,12) vals_ESP(3,12) vals_UK(3,12); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        if any(strcmp(sheet,'Table 12')) 
            outpath = strcat(out_dir,'hours_highEduc_wIndOcc.tex');
            rownames = {'BA degree or higher ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 11'))
            outpath = strcat(out_dir,'emp_highEduc_wIndOcc.tex');
            rownames = {'BA degree or higher ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};
        end
 
            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % extract estimation coefficients and p-values for LOW educated in w/ occ x ind setting
         vals_out = [vals_US(1,9) vals_CAN(1,9) vals_GER(1,7) vals_NL(1,9) vals_ESP(1,9) vals_UK(1,9); ...
                    vals_US(3,9) vals_CAN(3,9) vals_GER(3,7) vals_NL(3,9) vals_ESP(3,9) vals_UK(3,9); ...
                    vals_US(1,13) vals_CAN(1,13) NaN vals_NL(1,13) vals_ESP(1,13) vals_UK(1,13); ...
                    vals_US(3,13) vals_CAN(3,13) NaN vals_NL(3,13) vals_ESP(3,13) vals_UK(3,13); ...
                    vals_US(1,15) vals_CAN(1,15) vals_GER(1,11) vals_NL(1,15) vals_ESP(1,15) vals_UK(1,15); ...
                    vals_US(3,15) vals_CAN(3,15) vals_GER(3,11) vals_NL(3,15) vals_ESP(3,15) vals_UK(3,15); ...
                    vals_US(1,11) vals_CAN(1,11) vals_GER(1,9) vals_NL(1,11) vals_ESP(1,11) vals_UK(1,11); ...
                    vals_US(3,11) vals_CAN(3,11) vals_GER(3,9) vals_NL(3,11) vals_ESP(3,11) vals_UK(3,11); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;
 
        if any(strcmp(sheet,'Table 12')) 
            outpath = strcat(out_dir,'hours_lowEduc_wIndOcc.tex');
            rownames = {'Less than BA degree ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 11'))
            outpath = strcat(out_dir,'emp_lowEduc_wIndOcc.tex');
            rownames = {'Less than BA degree ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};
        end

            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out   

    end




    % Race: a) Benchmark (w/o occ x ind) for low and high education and b) w/ occ x ind for low and high education
    % NOTE: Race not in Canada and table got rearranged: UK now in second position
    if any(strcmp(sheet,'Table 14')) | any(strcmp(sheet,'Table 13'))

        % extract estimation coefficients and p-values for non-white/migration in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,2) vals_UK(1,2) vals_CAN(1,2) vals_GER(1,2) vals_NL(1,2) vals_ESP(1,2); ...
                    vals_US(3,2) vals_UK(3,2) vals_CAN(3,2) vals_GER(3,2) vals_NL(3,2) vals_ESP(3,2); ...
                    vals_US(1,6) vals_UK(1,6) vals_CAN(1,6) NaN vals_NL(1,6) vals_ESP(1,6); ...
                    vals_US(3,6) vals_UK(3,6) vals_CAN(3,6) NaN vals_NL(3,6) vals_ESP(3,6); ...
                    vals_US(1,8) vals_UK(1,8) vals_CAN(1,8) vals_GER(1,6) vals_NL(1,8) vals_ESP(1,8); ...
                    vals_US(3,8) vals_UK(3,8) vals_CAN(3,8) vals_GER(3,6) vals_NL(3,8) vals_ESP(3,8); ...
                    vals_US(1,4) vals_UK(1,4) vals_CAN(1,4) vals_GER(1,4) vals_NL(1,4) vals_ESP(1,4); ...
                    vals_US(3,4) vals_UK(3,4) vals_CAN(3,4) vals_GER(3,4) vals_NL(3,4) vals_ESP(3,4); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        if any(strcmp(sheet,'Table 14')) 
            outpath = strcat(out_dir,'hours_nonwhite_bench.tex');
            rownames = {'Gender gap: non-whites / migration ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 13'))
            outpath = strcat(out_dir,'emp_nonwhite_bench.tex');
            rownames = {'Gender gap: non-whites / migration ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};
        end
 
            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % extract estimation coefficients and p-values for white/no migration in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,1) vals_UK(1,1) vals_CAN(1,1) vals_GER(1,1) vals_NL(1,1) vals_ESP(1,1); ...
                    vals_US(3,1) vals_UK(3,1) vals_CAN(3,1) vals_GER(3,1) vals_NL(3,1) vals_ESP(3,1); ...
                    vals_US(1,5) vals_UK(1,5) vals_CAN(1,5) NaN vals_NL(1,5) vals_ESP(1,5); ...
                    vals_US(3,5) vals_UK(3,5) vals_CAN(3,5) NaN vals_NL(3,5) vals_ESP(3,5); ...
                    vals_US(1,7) vals_UK(1,7) vals_CAN(1,7) vals_GER(1,5) vals_NL(1,7) vals_ESP(1,7); ...
                    vals_US(3,7) vals_UK(3,7) vals_CAN(3,7) vals_GER(3,5) vals_NL(3,7) vals_ESP(3,7); ...
                    vals_US(1,3) vals_UK(1,3) vals_CAN(1,3) vals_GER(1,3) vals_NL(1,3) vals_ESP(1,3); ...
                    vals_US(3,3) vals_UK(3,3) vals_CAN(3,3) vals_GER(3,3) vals_NL(3,3) vals_ESP(3,3); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;
 
        if any(strcmp(sheet,'Table 14')) 
            outpath = strcat(out_dir,'hours_white_bench.tex');
            rownames = {'Gender gap: whites / no migration ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 13'))
            outpath = strcat(out_dir,'emp_white_bench.tex');
            rownames = {'Gender gap: whites / no migration ($\beta_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$)', ''};
        end

            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out   



        % extract estimation coefficients and p-values for non-white/migration in w/ occ x ind setting
        vals_out = [vals_US(1,10) vals_UK(1,10) vals_CAN(1,10) vals_GER(1,8) vals_NL(1,10) vals_ESP(1,10); ...
                    vals_US(3,10) vals_UK(3,10) vals_CAN(3,10) vals_GER(3,8) vals_NL(3,10) vals_ESP(3,10); ...
                    vals_US(1,14) vals_UK(1,14) vals_CAN(1,14) NaN vals_NL(1,14) vals_ESP(1,14); ...
                    vals_US(3,14) vals_UK(3,14) vals_CAN(3,14) NaN vals_NL(3,14) vals_ESP(3,14); ...
                    vals_US(1,16) vals_UK(1,16) vals_CAN(1,16) vals_GER(1,12) vals_NL(1,16) vals_ESP(1,16); ...
                    vals_US(3,16) vals_UK(3,16) vals_CAN(3,16) vals_GER(3,12) vals_NL(3,16) vals_ESP(3,16); ...
                    vals_US(1,12) vals_UK(1,12) vals_CAN(1,12) vals_GER(1,10) vals_NL(1,12) vals_ESP(1,12); ...
                    vals_US(3,12) vals_UK(3,12) vals_CAN(3,12) vals_GER(3,10) vals_NL(3,12) vals_ESP(3,12); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        if any(strcmp(sheet,'Table 14')) 
            outpath = strcat(out_dir,'hours_nonwhite_wIndOcc.tex');
            rownames = {'Gender gap: non-whites / migration ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 13'))
            outpath = strcat(out_dir,'emp_nonwhite_wIndOcc.tex');
            rownames = {'Gender gap: non-whites / migration ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};
        end
 
            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % extract estimation coefficients and p-values for white/no migration in w/ occ x ind setting
         vals_out = [vals_US(1,9)  vals_UK(1,9) vals_CAN(1,9)  vals_GER(1,7)  vals_NL(1,9)  vals_ESP(1,9); ...
                     vals_US(3,9)  vals_UK(3,9) vals_CAN(3,9)  vals_GER(3,7)  vals_NL(3,9)  vals_ESP(3,9); ...
                     vals_US(1,13) vals_UK(1,13) vals_CAN(1,13) NaN vals_NL(1,13) vals_ESP(1,13); ...
                     vals_US(3,13) vals_UK(3,13) vals_CAN(3,13) NaN vals_NL(3,13) vals_ESP(3,13); ...
                     vals_US(1,15) vals_UK(1,15) vals_CAN(1,15) vals_GER(1,11) vals_NL(1,15) vals_ESP(1,15); ...
                     vals_US(3,15) vals_UK(3,15) vals_CAN(3,15) vals_GER(3,11) vals_NL(3,15) vals_ESP(3,15); ...
                     vals_US(1,11) vals_UK(1,11) vals_CAN(1,11) vals_GER(1,9)  vals_NL(1,11) vals_ESP(1,11); ...
                     vals_US(3,11) vals_UK(3,11) vals_CAN(3,11) vals_GER(3,9)  vals_NL(3,11) vals_ESP(3,11); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;
 
        if any(strcmp(sheet,'Table 14')) 
            outpath = strcat(out_dir,'hours_white_wIndOcc.tex');
            rownames = {'Gender gap: whites / no migration ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};

        elseif any(strcmp(sheet,'Table 13'))
            outpath = strcat(out_dir,'emp_white_wIndOcc.tex');
            rownames = {'Gender gap: whites / no migration ($\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\theta_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\theta_{3,\text{none}}$)', ''};
        end

            matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out   

    end




    % Single Mothers - hours and employment:
    if any(strcmp(sheet,'Table 15'))

        %%% Hours
        % Single mothers hours gap in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,1) vals_CAN(1,1) NaN vals_NL(1,1) vals_ESP(1,1) vals_UK(1,1); ...
                    vals_US(3,1) vals_CAN(3,1) NaN vals_NL(3,1) vals_ESP(3,1) vals_UK(3,1); ...
                    vals_US(1,2) vals_CAN(1,2) vals_GER(1,1) vals_NL(1,2) vals_ESP(1,2) vals_UK(1,2); ...
                    vals_US(3,2) vals_CAN(3,2) vals_GER(3,1) vals_NL(3,2) vals_ESP(3,2) vals_UK(3,2); ...
                    ];


        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;

        outpath = strcat(out_dir,'hours_singlemoms_bench.tex');
        rownames = {'\hspace{1cm} pre-K kids ($\kappa_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\kappa_{3,\text{school}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % Single mothers hours gap in in w/ occ x ind setting
        vals_out = [vals_US(1,3) vals_CAN(1,3) NaN vals_NL(1,3) vals_ESP(1,3) vals_UK(1,3); ...
                    vals_US(3,3) vals_CAN(3,3) NaN vals_NL(3,3) vals_ESP(3,3) vals_UK(3,3); ...
                    vals_US(1,4) vals_CAN(1,4) vals_GER(1,2) vals_NL(1,4) vals_ESP(1,4) vals_UK(1,4); ...
                    vals_US(3,4) vals_CAN(3,4) vals_GER(3,2) vals_NL(3,4) vals_ESP(3,4) vals_UK(3,4); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
 
        outpath = strcat(out_dir,'hours_singlemoms_wIndOcc.tex');
        rownames = {'\hspace{1cm} pre-K kids ($\lambda_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\lambda_{3,\text{school}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out 



        %%% Employment
        % Single mothers employment gap in BENCHMARK setting (w/o occ x ind)
        vals_out = [vals_US(1,5) vals_CAN(1,5) NaN vals_NL(1,5) vals_ESP(1,5) vals_UK(1,5); ...
                    vals_US(3,5) vals_CAN(3,5) NaN vals_NL(3,5) vals_ESP(3,5) vals_UK(3,5); ...
                    vals_US(1,6) vals_CAN(1,6) vals_GER(1,3) vals_NL(1,6) vals_ESP(1,6) vals_UK(1,6); ...
                    vals_US(3,6) vals_CAN(3,6) vals_GER(3,3) vals_NL(3,6) vals_ESP(3,6) vals_UK(3,6); ...
                    ];


        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;

        outpath = strcat(out_dir,'emp_singlemoms_bench.tex');
        rownames = {'\hspace{1cm} pre-K kids ($\kappa_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\kappa_{3,\text{school}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % Single mothers hours gap in in w/ occ x ind setting
        vals_out = [vals_US(1,7) vals_CAN(1,7) NaN vals_NL(1,7) vals_ESP(1,7) vals_UK(1,7); ...
                    vals_US(3,7) vals_CAN(3,7) NaN vals_NL(3,7) vals_ESP(3,7) vals_UK(3,7); ...
                    vals_US(1,8) vals_CAN(1,8) vals_GER(1,4) vals_NL(1,8) vals_ESP(1,8) vals_UK(1,8); ...
                    vals_US(3,8) vals_CAN(3,8) vals_GER(3,4) vals_NL(3,8) vals_ESP(3,8) vals_UK(3,8); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
 
        outpath = strcat(out_dir,'emp_singlemoms_wIndOcc.tex');
        rownames = {'\hspace{1cm} pre-K kids ($\lambda_{3,\text{pre-K}}$)', '', '\hspace{1cm} school age kids ($\lambda_{3,\text{school}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);
  
        clear vals_out 


    end



    % Telecommuting: for US and UK: a) Benchmark (w/o occ x ind) and b) w/ occ x ind 
    if any(strcmp(sheet,'Table 16'))

        % extract estimation coefficients and p-values for NO TELECOMMUTING in US, UK, and NL in benchmark and w/ occ x ind setting
        vals_out = [vals_US(1,1) vals_US(1,9) vals_UK(1,1) vals_UK(1,9) vals_NL(1,1) vals_NL(1,9); ...
                    vals_US(3,1) vals_US(3,9) vals_UK(3,1) vals_UK(3,9) vals_NL(3,1) vals_NL(3,9); ...
                    vals_US(1,5) vals_US(1,13) vals_UK(1,5) vals_UK(1,13) vals_NL(1,5) vals_NL(1,13); ...
                    vals_US(3,5) vals_US(3,13) vals_UK(3,5) vals_UK(3,13) vals_NL(3,5) vals_NL(3,13); ...
                    vals_US(1,7) vals_US(1,15) vals_UK(1,7) vals_UK(1,15) vals_NL(1,7) vals_NL(1,15); ...
                    vals_US(3,7) vals_US(3,15) vals_UK(3,7) vals_UK(3,15) vals_NL(3,7) vals_NL(3,15); ...
                    vals_US(1,3) vals_US(1,11) vals_UK(1,3) vals_UK(1,11) vals_NL(1,3) vals_NL(1,11); ...
                    vals_US(3,3) vals_US(3,11) vals_UK(3,3) vals_UK(3,11) vals_NL(3,3) vals_NL(3,11); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        outpath = strcat(out_dir,'hours_notelecom.tex');
        rownames = {'No telecommuting  ($\beta_3$/$\gamma_3$)', '', '\hspace{1cm} pre-K kids  ($\delta_{3,\text{pre-K}}$/$\theta_{3,\text{pre-K}}$)', '', ...
        '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$/$\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$/$\theta_{3,\text{none}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out


        % extract estimation coefficients and p-values for TELECOMMUTING in US, UK, and NL in benchmark and w/ occ x ind setting
        vals_out = [vals_US(1,2) vals_US(1,10) vals_UK(1,2) vals_UK(1,10) vals_NL(1,2) vals_NL(1,10); ...
                    vals_US(3,2) vals_US(3,10) vals_UK(3,2) vals_UK(3,10) vals_NL(3,2) vals_NL(3,10); ...
                    vals_US(1,6) vals_US(1,14) vals_UK(1,6) vals_UK(1,14) vals_NL(1,6) vals_NL(1,14); ...
                    vals_US(3,6) vals_US(3,14) vals_UK(3,6) vals_UK(3,14) vals_NL(3,6) vals_NL(3,14); ...
                    vals_US(1,8) vals_US(1,16) vals_UK(1,8) vals_UK(1,16) vals_NL(1,8) vals_NL(1,16); ...
                    vals_US(3,8) vals_US(3,16) vals_UK(3,8) vals_UK(3,16) vals_NL(3,8) vals_NL(3,16); ...
                    vals_US(1,4) vals_US(1,12) vals_UK(1,4) vals_UK(1,12) vals_NL(1,4) vals_NL(1,12); ...
                    vals_US(3,4) vals_US(3,12) vals_UK(3,4) vals_UK(3,12) vals_NL(3,4) vals_NL(3,12); ...
                    ];

        vals_out(1,:) = vals_out(1,:)*100;
        vals_out(3,:) = vals_out(3,:)*100;
        vals_out(5,:) = vals_out(5,:)*100;
        vals_out(7,:) = vals_out(7,:)*100;

        outpath = strcat(out_dir,'hours_telecom.tex');
        rownames = {'Telecommuting ($\beta_3$/$\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$/$\theta_{3,\text{pre-K}}$)', '',...
        '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$/$\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids  ($\delta_{3,\text{none}}$/$\theta_{3,\text{none}}$)', ''};
        matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

        clear vals_out

    end

end




% Telecommuting x education only for UK: a) Benchmark (w/o occ x ind) and b) w/ occ x ind 
sheet = 'Table 18';

vals_UK = xlsread(strcat(input_dir,'UK_DiD.xlsx'),sheet);

if any(strcmp(sheet,'Table 18'))

    % extract estimation coefficients and p-values for NO TELECOMMUTING in UK in benchmark and w/ occ x ind setting
    vals_out = [vals_UK(1,1) vals_UK(1,2) vals_UK(1,17) vals_UK(1,18); ...
                vals_UK(3,1) vals_UK(3,2) vals_UK(3,17) vals_UK(3,18); ...
                vals_UK(1,9) vals_UK(1,10) vals_UK(1,25) vals_UK(1,26); ...
                vals_UK(3,9) vals_UK(3,10) vals_UK(3,25) vals_UK(3,26); ...
                vals_UK(1,13) vals_UK(1,14) vals_UK(1,29) vals_UK(1,30); ...
                vals_UK(3,13) vals_UK(3,14) vals_UK(3,29) vals_UK(3,30); ...
                vals_UK(1,5) vals_UK(1,6) vals_UK(1,21) vals_UK(1,22); ...
                vals_UK(3,5) vals_UK(3,6) vals_UK(3,21) vals_UK(3,22); ...
                ];

    vals_out(1,:) = vals_out(1,:)*100;
    vals_out(3,:) = vals_out(3,:)*100;
    vals_out(5,:) = vals_out(5,:)*100;
    vals_out(7,:) = vals_out(7,:)*100;

    outpath = strcat(out_dir,'hours_notelecom_educUK.tex');
    rownames = {'No telecommuting  ($\beta_3$/$\gamma_3$)', '', '\hspace{1cm} pre-K kids  ($\delta_{3,\text{pre-K}}$/$\theta_{3,\text{pre-K}}$)', '', ...
     '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$/$\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids ($\delta_{3,\text{none}}$/$\theta_{3,\text{none}}$)', ''};
    matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

    clear vals_out


    i = 2;
    % extract estimation coefficients and p-values for TELECOMMUTING in UK in benchmark and w/ occ x ind setting
    vals_out = [vals_UK(1,1+i) vals_UK(1,2+i) vals_UK(1,17+i) vals_UK(1,18+i); ...
                vals_UK(3,1+i) vals_UK(3,2+i) vals_UK(3,17+i) vals_UK(3,18+i); ...
                vals_UK(1,9+i) vals_UK(1,10+i) vals_UK(1,25+i) vals_UK(1,26+i); ...
                vals_UK(3,9+i) vals_UK(3,10+i) vals_UK(3,25+i) vals_UK(3,26+i); ...
                vals_UK(1,13+i) vals_UK(1,14+i) vals_UK(1,29+i) vals_UK(1,30+i); ...
                vals_UK(3,13+i) vals_UK(3,14+i) vals_UK(3,29+i) vals_UK(3,30+i); ...
                vals_UK(1,5+i) vals_UK(1,6+i) vals_UK(1,21+i) vals_UK(1,22+i); ...
                vals_UK(3,5+i) vals_UK(3,6+i) vals_UK(3,21+i) vals_UK(3,22+i); ...
                ];

    vals_out(1,:) = vals_out(1,:)*100;
    vals_out(3,:) = vals_out(3,:)*100;
    vals_out(5,:) = vals_out(5,:)*100;
    vals_out(7,:) = vals_out(7,:)*100;

    outpath = strcat(out_dir,'hours_telecom_educUK.tex');
    rownames = {'Telecommuting ($\beta_3$/$\gamma_3$)', '', '\hspace{1cm} pre-K kids ($\delta_{3,\text{pre-K}}$/$\theta_{3,\text{pre-K}}$)', '',...
     '\hspace{1cm} school age kids ($\delta_{3,\text{school}}$/$\theta_{3,\text{school}}$)', '', '\hspace{1cm} no kids  ($\delta_{3,\text{none}}$/$\theta_{3,\text{none}}$)', ''};
    matlab_to_latex(vals_out,rownames,'%.2f',1,0,outpath);

    clear vals_out

end








