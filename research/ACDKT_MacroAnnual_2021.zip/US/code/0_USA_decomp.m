



clear all
close all
clc


% Preliminaries 
cd(' .../USA/decompositions/') 
out_file = 'decomposition_results.xlsx'; %  output saved


%%%%%%%%%%%%%%%%
% READ IN DATA %
%%%%%%%%%%%%%%%%

% Kid Weights
[kid_raw,kid_lab] = xlsread('USA_decomp.xlsx','kid shares');
kid_raw  = kid_raw(:,2:end);  %  drop labels column

% Work Weights
[work_raw,work_lab] = xlsread('USA_decomp.xlsx','work shares');

% Coefficients
[coef_hrs,coef_lab_hrs] = xlsread('USA_decomp.xlsx','hours');
[coef_emp,coef_lab_emp] = xlsread('USA_decomp.xlsx','employment');




%%%%%%%%%%%%%%%
% SAMPLE SETS %
%%%%%%%%%%%%%%%

set_num = 4;
% All samples include "the employed"
%  row 1: pre-pandemic, Dt=0
%  row 2: all of 2019
%  row 3: 2019 Q2-Q3, y-on-y sample  
%  row 4: 2020 Q1, eve of pandemic

% Initialize  storage
results_hrs = nan(set_num,3);
results_emp = nan(set_num,3);
components_hrs = nan(set_num,4);
components_emp = nan(set_num,4);

for j = 1:set_num;


men_kid_shares = kid_raw(2:3,2*j-1); % remove normalized group, not employed
wom_kid_shares = kid_raw(2:3,2*j);

men_work_shares = work_raw(1:(end-1),2*j-1); % remove normalized group, not employed
wom_work_shares = work_raw(1:(end-1),2*j);

for k = 1:2;  %  hours and employment
    
    if k==1
        coef_raw = coef_hrs;
    elseif k==2
        coef_raw = coef_emp;
    end

%%%%%%%%%%%%%%%%%%%%
% CREATE VARIABLES %
%%%%%%%%%%%%%%%%%%%%

% Create  Variables
% Dt         = coef_raw(1,2); 
Dt_Fem     = coef_raw(1,17);

Dt_Kid    = nan(2,1);
Dt_Kid(1) = coef_raw(1,10);
Dt_Kid(2) = coef_raw(1,11);

Dt_Kid_Fem    = nan(2,1);
Dt_Kid_Fem(1) = coef_raw(1,33);
Dt_Kid_Fem(2) = coef_raw(1,35);

Dt_Work = coef_raw(1,826:(826+size(men_work_shares,1)-1))';
i_Work  = coef_raw(1,36:(36+size(men_work_shares,1)-1))'; % pre-pandemic levels, of reallocation effects

% Sanity Checks
assert(length(Dt_Work) == size(men_work_shares,1),"Work Type Dimensions Dont Match")
assert(length(Dt_Kid)  == size(men_kid_shares,1) ,"Kid Group Dimensions Dont Match")


%%%%%%%%%%%%%%%%%%
% DECOMPOSITIONS %
%%%%%%%%%%%%%%%%%%


% (i) childcare channel
cc_cohab   = sum((wom_kid_shares-men_kid_shares).*Dt_Kid,'omitnan');
cc_microGG = sum(wom_kid_shares.*Dt_Kid_Fem);

childcare_channel = cc_cohab+cc_microGG;

% (ii) labor demand channel
%Pval_Dt_Work = coef_raw(4,826:(826+size(men_work_shares,1)-1))'<0.05;
%Pval_i_Work  = coef_raw(4,36:(36+size(men_work_shares,1)-1))'<0.05; % pre-pandemic levels, of reallocation effects

labor_channel        = sum((wom_work_shares-men_work_shares).*Dt_Work,'omitnan');  % we dont have realllocaiton anymore in new decomp

% (iii) residual
residual = Dt_Fem;


%%%%%%%%%%%%%%%%
% OUTPUT TABLE %
%%%%%%%%%%%%%%%%
D_GG = childcare_channel+labor_channel+residual;

% Results - percent contributions
if k==1
    results_hrs(j,:) = [childcare_channel labor_channel residual]./D_GG;
elseif k==2
    results_emp(j,:) = [childcare_channel labor_channel residual]./D_GG;
end

% Components - levels
if k==1
    components_hrs(j,:) = [cc_cohab cc_microGG labor_channel residual];
elseif k==2
    components_emp(j,:) = [cc_cohab cc_microGG labor_channel residual];
end



end
end


%%%%%%%%%%%%%%%%
% SAVE RESULTS %
%%%%%%%%%%%%%%%%

%labels
col_labs = {'Sample','Childcare','Labor  Demand','Residual'}; % decomp labs
comp_col_labs = {'Sample','Cohab','Gender Gap','Labor  Demand','Residual'}; %component labs
row_labs = {'Dt=0','2019 Q1-Q4','2019 Q2-Q3','2020 Q1'}';

table_hrs = table([col_labs;row_labs,num2cell(results_hrs)]);
table_emp = table([col_labs;row_labs,num2cell(results_emp)]);

table_hrs_comp = table([comp_col_labs;row_labs,num2cell(components_hrs)]);
table_emp_comp = table([comp_col_labs;row_labs,num2cell(components_emp)]);

%results
writetable(table_hrs,out_file,'Sheet','hours','WriteVariableNames',0)
writetable(table_emp,out_file,'Sheet','emp','WriteVariableNames',0)

%components
writetable(table_hrs_comp,out_file,'Sheet','hours components','WriteVariableNames',0)
writetable(table_emp_comp,out_file,'Sheet','emp components','WriteVariableNames',0)

