Readme file on data sources

sigi.txt - Retrieved from http://www.genderindex.org/ranking/ on 10/2/17
	Contains the 2014 results of SIGI
	
dhs_statcompiler.xlsx - Retrieved from http://www.statcompiler.com/en/ on 10/2/17
	Contains the following indicators:
		Total fertility rate 15-49
		Mean ideal number of children for all women
		Mean ideal number of children for currently married women
		Mean ideal number of children for all men
		Mean ideal number of children for all currently married men
		Mean ideal number of children for all men 15-54(59)
		Mean ideal number of children for currently married men 15-54(59)
		Current marital status [Men]: married or living in union
		Number of wives: One wife
		Number of wives: Two or more wives
	Used most recently available survey
	Added a row (Row 4) with variable names for easier importing into Stata
	Added a worksheet that contains the detailed information for the indicators from the DHS Statcompiler (provided at the bottom of the first worksheet originally)

gdp_orig - Retrieved from World Development Indicators - https://data.worldbank.org/indicator/NY.GDP.PCAP.PP.KD
	Contains original csv file for GDP per capita,PPP (constant 2011 international $)
	as well as any metadata included with the download
gdp.csv is just a copy of the data file within the original download folder gdp_orig

