DHS datasets downloaded from dhsprogram.com and imported into Stata on 11/13/2017
Ethiopia and Burkina Faso are both DHS-VI
Ethiopia: Standard DHS, 2011
	et_couples.dta - Couples' Recode

Burkina Faso: Standard DHS, 2010
	bf_couples.dta - Couples' Recode

Both datasets are created by using the DHS-provided Stata code. 

