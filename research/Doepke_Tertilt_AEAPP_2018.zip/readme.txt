Replication files for "Women’s Empowerment, the Gender Gap in Desired Fertility, and Fertility Outcomes in Developing Countries" by Matthias Doepke and Michele Tertilt

The relevant Stata code are contained in "dofiles" folder. 

1. importdata.do imports raw data file from the "rawdata" folder and construct the datasets that are needed to create the figures in the main text, as well as all figures and tables included in the Online Appendix. The cleaned datasets are saved under the "cleandata" folder.

2. main.do uses the cleaned datasets saved in the "cleandata" folder and creates Figure 1 and Figure 2 in the main text. The figures are saved in the "outfigs" folder. 

3. appendix.do uses the cleaned datasets saved in the "cleandata" folder and creates all the figures and tables included in the Online Appendix. Figures are saved in "outfigs" folder and tables are saved in "outtabs" folder. 


Last updated 1/6/2018