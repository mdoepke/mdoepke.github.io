transb;
transk;
transe;