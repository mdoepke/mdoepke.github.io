function f=vus(ns)
% The value function for unskilled people having skilled children
% Matthias Doepke 
% 
% March 29, 1999

global EPS SIGMA BETA E EC ES F WS WU VS VU;

f=-( (WU-(E*WU+ES*WS+F)*ns)^SIGMA + ...
	BETA * (ns)^(1-EPS) * VS );