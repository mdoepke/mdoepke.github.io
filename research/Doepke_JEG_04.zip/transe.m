% trans.m
% Computes the transition path from agriculture to industry
% Landowning class in the background
% Amount of land normalized to one
% Child labor and public education
% Policy switch during transition
% Matthias Doepke 
% 
% March 29, 1999

clear all;

% Declaring global variables that are needed in the routines
% global variables are upper case

global EPS SIGMA BETA E EC ES F WS WU VS VU;

% *********************************************************************
%                          SETUP SECTION        
% *********************************************************************

% Setting technical parameters                                 
wageit=10;					% Iterations for computation of wages

nl=15;						% Updating periods for lambda
pow=2;						% Power in criterion function

wen=.5;						% Updating weight for ns,nu,nss,nuu,nus
wev=.2;						% Updating weight for vs, vu
wel=.4;						% Updating weight for lambda	
wet=.4;						% Updating weight for tax

critmin=.001;				% Convergence criterion
maxiter=300;				% Maximum number of iterations

onlyagr=0;					% Indicator for agriculture-only version

% Setting model parameters.    
SIGMA=.5; 					% Consumption elasticity
EPS=.5; 					% Elasticity of discount factor
BETA=.132; 					% discount factor

% Technology agriculture:
alphas=.1;					% Exponent for skilled workers
alphau=.5;					% Exponent for unskilled workers
exl=1-alphas-alphau;		% Implied exponent on land
pogr=1; 					% Desired Malthusian population growth
ga=(1+pogr)^exl-1;			% Implied agricultural productivity growth

% Technology industry:
alpha=.22;					% Exponent for unskilled workers
gi=.64;						% Productivity growth

% Education cost:
E=.155;	 					% Basic time cost
F=.001;						% Fixed cost in terms of goods

ec=.07;						% Child labor
es=.04;						% Schooling cost for skilled children

ec2=.00;					% Child labor after reform
es2=.02; 					% Schooling cost after reform

tr=6;						% Time of reform


% Setting starting values:
aistart=.75;  				% Industrial TFP
aastart=1;  				% Agricultural TFP

nsstart=.052189;				% # skilled workers
nustart=1.12;					% # number of unskilled workers
lamstart=.11815;				% initital lambda

tsim=14;					% Number of periods to be simulated

% Setting plotting parameters:
t0=1750;					% Starting period
ngr=7;						% Number of periods to be printed
tT=t0+25*(ngr-1);			% Last period
xaxis=linspace(t0,tT,ngr);	% X-Axis	


% *********************************************************************
%          END OF SETUP SECTION. NO CHANGES NEEDED BELOW        
% *********************************************************************


% Initialize all functions
ns=nsstart*ones(1,tsim+1);
nu=nustart*ones(1,tsim+1);

vs=.1*ones(1,tsim+1);
vu=.1*ones(1,tsim+1);

nss=.1*ones(1,tsim);
nuu=.1*ones(1,tsim);
nus=.1*ones(1,tsim);

lamus=lamstart*ones(1,tsim);

tax=zeros(1,tsim);

% Productivity series
ai(1,1)=aistart;
i=2;
while i<=tsim;
	ai(1,i)=(1+gi)*ai(1,i-1);
	i=i+1;
end;

%ai=4*ai/ai(5);
% Set initial elements to zero to 
% simulate jump
%ai(1:5)=zeros(1,5);

aa(1,1)=aastart;
i=2;
while i<=tsim;
	aa(1,i)=(1+ga)*aa(1,i-1);
	i=i+1;
end;


% *********************************************************************
%                           START OF ITERATIONS
% *********************************************************************


% Start iterations
count=1;
crit=1;
critl=1;
while (crit>critmin)&(count<maxiter);

	% Population in the initial period does not change
	nsnew(1)=ns(1);
	nunew(1)=nu(1);
	
	ES=es;
	EC=ec;
	i=1;
	while i<=tsim;
		if i>=tr;
			% Teacher is paid in before-tax dollars
			ES=es2/(1-tax(i));
			EC=ec2;
		end;
		
		% Compute wages and interest
		% Use es instead of ES because that is the time required
		ls(i)=ns(i)*(1-(E+es)*nss(i))-lamus(i)*nu(i)*es*nus(i);
		lu(i)=nu(i)*(1-E*lamus(i)*nus(i)-(E-EC)*(1-lamus(i))*nuu(i));	
			
		% Allocate labor so as to equalize wages
		% Outer loop is for unskilled
		frui(i)=.5;
		frul=0;
		fruh=1;
		wucount=1;
		while wucount<wageit;

			% The inner loop equalizes wage for skilled people
			frsi(i)=.5;
			frsl=0;
			frsh=1;
			wscount=1;
			while wscount<=wageit;
				wsi=ai(i)*(1-alpha)*((frui(i)*lu(i))/(frsi(i)*ls(i)))^alpha;
				wsa=aa(i)*alphas*((1-frsi(i))*ls(i))^(alphas-1)*...
					((1-frui(i))*lu(i))^alphau;

				if wsi<wsa;
					frsh=frsi(i);
					frsi(i)=.5*frsi(i)+.5*frsl;
				else;
					frsl=frsi(i);
					frsi(i)=.5*frsi(i)+.5*frsh;
				end;
				wscount=wscount+1;

			end;
			wui=ai(i)*alpha*((frsi(i)*ls(i))/(frui(i)*lu(i)))^(1-alpha);
			wua=aa(i)*alphau*((1-frsi(i))*ls(i))^alphas*...
				((1-frui(i))*lu(i))^(alphau-1);

			if wui<wua;
				fruh=frui(i);
				frui(i)=.5*frui(i)+.5*frul;
			else;
				frul=frui(i);
				frui(i)=.5*frui(i)+.5*fruh;
			end;

			wucount=wucount+1;
		end;

		% Fraction of output produced in agriculture
		outagr=aa(i)*((1-frsi(i))*ls(i))^alphas*...
				((1-frui(i))*lu(i))^alphau;
				
		outind=ai(i)*(frsi(i)*ls(i))^(1-alpha)*(frui(i)*lu(i))^alpha;
				
		fragr(i)=outagr/(outagr+outind);
		
		ws(i)=max([wsi wsa]);
		wu(i)=max([wui wua]);
		WS=(1-tax(i))*ws(i);
		WU=(1-tax(i))*wu(i);
		
		% Future values
		VS=vs(i+1);
		VU=vu(i+1);		

		% Compute skilled decisions
		nssnew(i)=fmin('vss',0,WS/((E+ES)*WS+F));
		nssnew(i)=real(nssnew(i));
		vsnew(i)=real(-vss(nssnew(i)));
		
		% The decision of the unskilled people
		nuunew(i)=fmin('vuu',0,WU/((E-EC)*WU+F));
		nuunew(i)=real(nuunew(i));	
		vu1(i)=real(-vuu(nuunew(i)));
		
		nusnew(i)=fmin('vus',0,WU/(E*WU+ES*WS+F));
		nusnew(i)=real(nusnew(i));
		vu2(i)=real(-vus(nusnew(i)));
	
		% Compute average value
		vunew(i)=(1-lamus(i))*vu1(i)+lamus(i)*vu2(i);
		
		% Compute next period state
		nsnew(i+1)=nsnew(i)*nssnew(i)+lamus(i)*nunew(i)*nusnew(i);
		nunew(i+1)=nunew(i)*(1-lamus(i))*nuunew(i);
		
		% Compute required tax
		taxnew(i)=(es-es2)*(nssnew(i)*ns(i)+...
			lamus(i)*nusnew(i)*nu(i))*ws(i)/...
			((1-E*nssnew(i))*ns(i)*ws(i)+lu(i)*wu(i));

		% Compute Gini
		yu(i)=(1-(E-EC)*nuunew(i))*WU;
		ys(i)=(1-E*nssnew(i))*WS;
		ymean(i)=(yu(i)*nu(i)+ys(i)*ns(i))/(ns(i)+nu(i));
		giniold(i)=1-(yu(i)*nu(i)^2/...
			(ymean(i)*(ns(i)+nu(i))^2)+ns(i)/(ns(i)+nu(i)) );
	
		gini(i)=1-(yu(i)*nu(i)^2+ys(i)*ns(i)^2+2*yu(i)*nu(i)*ns(i))/...
			((ns(i)+nu(i))^2*ymean(i));

		gini=real(gini);

		% Compute GDP
		gdp(i)=(yu(i)*nu(i)+ys(i)*ns(i))/(nu(i)+ns(i));
		gdp=real(gdp);
			
		if rem(count,nl)==0;
			if vu1(i)>vu2(i);
				% Adjust down
				lamusnew(i)=(vu2(i)/vu1(i))^pow*lamus(i);
				critl=max(abs(lamus-lamusnew));
			else;
				% Adjust up
				lamusnew(i)=(vu1(i)/vu2(i))^pow*lamus(i)...
					+1-(vu1(i)/vu2(i))^pow;
				critl=max(abs(lamus-lamusnew));
			end;
			
		else;
			lamusnew(i)=lamus(i);
		end;
		
		i=i+1;
	end;
	
	% Update tsim+1 (needed for decisision in tsim)
	vsnew(tsim+1)=(1+gi)^SIGMA*vsnew(tsim);
	vunew(tsim+1)=(1+gi)^SIGMA*vunew(tsim);
	
	if onlyagr==1;
		vsnew(tsim+1)=vsnew(tsim);
		vunew(tsim+1)=vunew(tsim);
	end;

	% Compute criterion
	crit=max(abs([vsnew-vs ns-nsnew nss-nssnew]))+critl;
	
	% Update all functions
	
	ns=wen*ns+(1-wen)*nsnew;
	nu=wen*nu+(1-wen)*nunew;

	vs=wev*vs+(1-wev)*vsnew;
	vu=wev*vu+(1-wev)*vunew;

	nss=wen*nss+(1-wen)*nssnew;
	nuu=wen*nuu+(1-wen)*nuunew;
	nus=wen*nus+(1-wen)*nusnew;	
	
	tax=wet*tax+(1-wet)*taxnew;

	if count>100;
		wel=.4;
	end;
	if count>200;
		wel=.6;
	end;
	lamus=wel*lamus+(1-wel)*lamusnew;

	% Force lamus to be increasing
	%i=2;
	%while i<=tsim;
	%	if lamus(i)<lamus(i-1);
	%	lamus(i)=lamus(i-1);
	% i=i+1;	
	%end;

	% Compute population growth
	ntotal=nu+ns;
	ninc=ntotal(2:tsim+1)-ntotal(1:tsim);
	pgr=100*ninc./ntotal(1:tsim);

	% Compute TFR
	tfru=2*(lamus.*nus+(1-lamus).*nuu);
	tfrs=2*nss;
	tfr=(nu(1:tsim).*tfru+ns(1:tsim).*tfrs)./ntotal(1:tsim);	

	% Print some output from time to time
	if rem(count,nl)==0;
		(vu2-vu1)./vu1
	end;	

	if rem(count,5)==0;
		[count crit]
	end;

	count=count+1;

end;


% *********************************************************************
%                           PLOT RESULTS
% *********************************************************************


% Print Fraction in Industry
subplot(2,2,1);
plot(xaxis,frsi(1:ngr),'-');
hold on;
plot(xaxis,frui(1:ngr),'--');
axis([t0 tT 0 1]);
yl=ylabel('Fraction in industry');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% GDP Fraction of unskilled parents having skilled children
subplot(2,2,2);
plot(xaxis,lamus(1:ngr),'-');
hold on;
axis([t0 tT 0 1]);
yl=ylabel('lambda U -> S');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;


% Number of skilled and unskilled agents
subplot(2,2,3);
plot(xaxis,ns(1:ngr),'-');
hold on;
plot(xaxis,nu(1:ngr),'--');
axis([t0 tT 0 ceil(max(ns(1:ngr)))]);
yl=ylabel('Number of people');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% Print TFR for each group
subplot(2,2,4);
plot(xaxis,tfrs(1:ngr),'-');
hold on;
plot(xaxis,tfru(1:ngr),'--');
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([t0 tT 0 ceil(max(tfr(1:ngr)))]);
yl=ylabel('TFR');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% print -deps2 graphs/england2.eps;



% Print TFR
subplot(2,1,1);
plot(xaxis,tfr(1:ngr),'-');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([t0 tT 0 ceil(max(tfr(1:ngr)))]);
yl=ylabel('TFR');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% Print Gini
subplot(2,1,2);
plot(xaxis,gini(1:ngr),'-');
hold on;
axis([t0 tT 0 .7]);
yl=ylabel('Gini');
xl=xlabel('Year');
tl=title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% print -deps2 graphs/england.eps;

% Print GDP per capita
subplot(1,1,1);
plot(xaxis,gdp(1:ngr),'-');
hold on;
axis([t0 tT 0 max(gdp(1:ngr))]);
yl=ylabel('Real GDP per capita');
xl=xlabel('Year');
title('');
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',16);
hold off;

% print -deps2 graphs/enggdp.eps;

% Print GDP per capita
subplot(3,1,1);
gr=plot(xaxis,gdp(1:ngr),'-');
hold on;
axis([1800 tT 0 max(gdp(1:ngr))]);
yl=ylabel('Real GDP');
xl=xlabel('');
title('');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',18);
hold off;

% Print TFR
subplot(3,1,2);
gr=plot(xaxis,tfr(1:ngr),'-');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([1800 tT 0 ceil(max(tfr(1:ngr)))]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',18);
hold off;

% Print Gini
subplot(3,1,3);
gr=plot(xaxis,gini(1:ngr),'-');
hold on;
axis([1800 tT 0 .7]);
yl=ylabel('Gini');
xl=xlabel('Year');
tl=title('');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',20);
set(xl,'Fontname','Times');
set(xl,'Fontsize',20);
set(tl,'Fontname','Times');
set(tl,'Fontsize',20);
set(gca,'Fontname','Times');
set(gca,'Fontsize',18);
hold off;

print -deps2 graphs/e4.eps;

enggdp=gdp(1:ngr);
engtfr=tfr(1:ngr);

exaxis=xaxis;
egini=gini;
etfrs=tfrs;
etfru=tfru;

save england enggdp engtfr egini etfrs etfru exaxis;


% *********************************************************************
%                           END OF PROGRAM 
% *********************************************************************