function f=vuu(nu)
% The value function for unskilled people having unskilled children
% Matthias Doepke 
% 
% March 29, 1999

global EPS SIGMA BETA E EC ES F WS WU VS VU;

f=-( (WU-((E-EC)*WU+F)*nu)^SIGMA + ...
	BETA * (nu)^(1-EPS) * VU );