% testgra.m
% Does some graphs for fertility paper
% October 6, 1999

clear all;

load brazil;
load korea;
load england;

kortfr(6)=1.95;
kortfrs(6)=1.9;

% Print GDP per capita
subplot(3,2,1);
gr=plot(xaxis,bragdp,'-');
hold on;
axis([min(xaxis) max(xaxis) 0 8.5]);
yl=ylabel('GDP/Capita');
xl=xlabel('');
tl=title('No Reform - "Brazil"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR
subplot(3,2,2);
gr=plot(xaxis,bratfr,'-');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([min(xaxis) max(xaxis) 1.5 4.8]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('No Reform - "Brazil"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print GDP per capita
subplot(3,2,5);
gr=plot(exaxis,enggdp,'-');
hold on;
plot(exaxis,bragdp,'--');
axis([min(exaxis) max(exaxis) 0 8.5]);
yl=ylabel('GDP/Capita');
xl=xlabel('');
tl=title('Delayed Reform - "England"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR
subplot(3,2,6);
gr=plot(exaxis,engtfr,'-');
hold on;
plot(exaxis,bratfr,'--');
plot([min(exaxis) max(exaxis)],[2 2], ':');
axis([min(exaxis) max(exaxis) 1.5 4.8]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Delayed Reform - "England"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print GDP per capita
subplot(3,2,3);
gr=plot(xaxis,korgdp,'-');
hold on;
plot(xaxis,bragdp,'--');
axis([min(xaxis) max(xaxis) 0 8.5]);
yl=ylabel('GDP/Capita');
xl=xlabel('');
tl=title('Immediate Reform - "Korea"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR
subplot(3,2,4);
gr=plot(xaxis,kortfr,'-');
hold on;
plot(xaxis,bratfr,'--');
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([min(xaxis) max(xaxis)  1.5 4.8]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Immediate Reform - "Korea"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

print -deps2 graphs/sim1.eps;

% Print Gini
subplot(3,2,1);
gr=plot(xaxis,bragini,'-');
hold on;
axis([min(xaxis) max(xaxis) 0 .7]);
yl=ylabel('Gini');
xl=xlabel('');
tl=title('No Reform - "Brazil"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print Gini
subplot(3,2,5);
gr=plot(exaxis,egini(1:7),'-');
hold on;
axis([min(exaxis) max(exaxis) 0 .7]);
yl=ylabel('Gini');
xl=xlabel('');
tl=title('Delayed Reform - "England"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print Gini
subplot(3,2,3);
gr=plot(xaxis,korgini,'-');
hold on;
axis([min(xaxis) max(xaxis)  0 .7]);
yl=ylabel('Gini');
xl=xlabel('');
tl=title('Immediate Reform - "Korea"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR for each group
subplot(3,2,2);
gr=plot(xaxis,bratfrs,'-',xaxis,bratfru,'--');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([1900 2050 0 4.5]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('No Reform - "Brazil"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;
legend('Skilled','Unskilled',4);

subplot(3,2,4);
gr=plot(xaxis,kortfrs,'-',xaxis,kortfru,'--');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([1900 2050 0 4.5]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Immediate Reform - "Korea"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;
legend('Skilled','Unskilled',4);

subplot(3,2,6);
gr=plot(exaxis,etfrs(1:7),'-',exaxis,etfru(1:7),'--');
hold on;
plot([min(exaxis) max(exaxis)],[2 2], ':');
axis([1750 1900 0 4.5]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Delayed Reform - "England"');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;
legend('Skilled','Unskilled',4);

print -deps2 graphs/ginfdiff.eps;