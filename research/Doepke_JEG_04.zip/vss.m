function f=vss(ns)
% The value function for skilled people having skilled children
% Matthias Doepke 
% 
% March 29, 1999

global EPS SIGMA BETA E EC ES F WS WU VS VU;

f=-( (WS-((E+ES)*WS+F)*ns)^SIGMA + ...
	BETA * (ns)^(1-EPS) * VS );