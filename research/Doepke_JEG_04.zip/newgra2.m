% newgra2.m
% More graphs for fertility paper
% July 2001

clear all;

load brazil;
load korea;
load england;

load edu;
load clr;

edutfr(6)=3.8;

% Print GDP per capita
subplot(3,2,3);
gr=plot(xaxis,clgdp,'-');
hold on;
axis([min(xaxis) max(xaxis) 0 8.5]);
yl=ylabel('GDP/Capita');
xl=xlabel('');
tl=title('Child-Labor Restriction Only');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR
subplot(3,2,4);
gr=plot(xaxis,cltfr,'-');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([min(xaxis) max(xaxis)  1.5 4.8]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Child-Labor Restriction Only');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print GDP per capita
subplot(3,2,5);
gr=plot(xaxis,edugdp,'-');
hold on;
axis([min(xaxis) max(xaxis) 0 8.5]);
yl=ylabel('GDP/Capita');
xl=xlabel('');
tl=title('Education Subsidy Only');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

% Print TFR
subplot(3,2,6);
gr=plot(xaxis,edutfr,'-');
hold on;
plot([min(xaxis) max(xaxis)],[2 2], ':');
axis([min(xaxis) max(xaxis) 1.5 4.8]);
yl=ylabel('TFR');
xl=xlabel('');
tl=title('Education Subsidy Only');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',12);
set(xl,'Fontname','Times');
set(xl,'Fontsize',12);
set(tl,'Fontname','Times');
set(tl,'Fontsize',12);
set(gca,'Fontname','Times');
set(gca,'Fontsize',10);
hold off;

print -deps2 graphs/sim2.eps;

