

%% loads zero coupon yields into arrays zeroyieldsqm, zeroyields
%%    is called by factors code





%%%%%%%%%%%%%%%% for 1952-1990, use McCulloch-Kwan dataset 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% MacCulloch zero yield curve comes from two excel files
% zeroyld1 has data 1946:12 - 1985:8, monthly, with initial useless line
% zeroyld2 has data 1985:8 - 1991:2
% the data are in packs of 8 lines and 9 columns
% lines 1 and 8 are useless, the rest has the different maturities
% introline per pack,
%   the mcculloch data has 44 full years (47-90); we start in 52 so use only 39
mcobs=39;
yrone=1952;

zeroyields = zeros(obs,30);
threemonth = zeros(obs,1);
zeroyieldsqm = zeros(obsq, 40*12+1);

mcc = xlsread('zeroyld1.xls');
mcc2 = xlsread('zeroyld2.xls');

mcc=[zeros(1,size(mcc,2));mcc];
mcc2=[zeros(1,size(mcc2,2));mcc2];

mcc = [mcc(1:end-8,:); mcc2(9:end,:)]; % concatenate, taking 85:8from second data sample



for year = 1952:1990;


% read and fill data for annual array with maturities by year
   packrow1 = (year - 1947)*8*12 + 8*11 + 16;
   threemonth(year-yrone+1) = mcc(packrow1+1,4);
   zeroyields(year - yrone+1,:) = [ mcc(packrow1+2,4) mcc(packrow1+3,3) mcc(packrow1+3,[5:9]),...
                                     mcc(packrow1+5,:) mcc(packrow1+6,:) mcc(packrow1+7,[1:5])];

   % missing values have code -88.888; make term structure flat at end if missing data
   i=10; done=0;
   while done==0 & i<31;
      now = zeroyields(year-yrone+1,i);
      if now <0;
          done=1;
      else;
          last = zeroyields(year-yrone+1,i);
      end;
      i=i+1;
   end;
   zeroyields(year-yrone+1,[i-1:30])=last*ones(1,32-i);


% read and fill data for quarterly array with maturities by month
   for quarter = 1:4;

    packrowm = (year-1947)*8*12 + (quarter*3-1)*8 + 16;

    nowat = (year-yrone)*4+quarter;  % location in zeroyieldsm array


    % first load all the maturities that are available
    zeroyieldsqm(nowat,1:18) = [ mcc(packrowm+2,:) mcc(packrowm+3,:)]; % fedfunds and first 17 months
    zeroyieldsqm(nowat,[19:6:31]) = mcc(packrowm+4,[1 3 4]);  % 1.5 - 2.5 years
    zeroyieldsqm(nowat,37:12:(35*12+1)) = [ mcc(packrowm+4,5:end) mcc(packrowm+5,:) mcc(packrowm+6,:)...
                                            mcc(packrowm+7,:) mcc(packrowm+8,1)]; % 3-35 yrs
    zeroyieldsqm(nowat,end) = mcc(packrowm+8,2); % 40 years

    % first yearend where no data available
    notavail = min(find(zeroyieldsqm(nowat,:)<0));
    % fill with last available yield, thus making term structure flat at end
    zeroyieldsqm(nowat,notavail-11:40*12+1) = zeroyieldsqm(nowat,notavail-12) * ones(1, 40*12+1 - (notavail-12));

    % now lineraly interpolate for intermediate months
    % first the range 1.5-3 years
    for i = 1:5;
    zeroyieldsqm(nowat,[19:6:31]+i) = zeroyieldsqm(nowat,[19:6:31])*(1-i/6) + zeroyieldsqm(nowat,[25:6:37])*(i/6);
    end;
    % now the range 3-35 years
    for i = 1:11;
    zeroyieldsqm(nowat,[37:12:(34*12+1)]+i) = zeroyieldsqm(nowat,[37:12:(34*12+1)])*(1-i/12)...
                   + zeroyieldsqm(nowat,[49:12:(35*12+1)])*i/12;
    end;
    % make flat after 35 years
    zeroyieldsqm(nowat,(35*12+2):end) = zeroyieldsqm(nowat,(35*12+1))*ones(1,5*12);

  end;


end;


%% load Fed's zero yield curve
%% this is created by makemonthly and is now monthly from 1988:1
%% first two columns are monmth, year, then come maturities .25, .5, .75, 1:30
load fedyields;


% as with mcculloch need to select & interpolate to arrive at quarterly frequency, monthly maturities
stuff = zeros((endyr-1990)*4,40*12+1);

% fill full year maturities 1-30

range = [(1990-1987)*12+3:3:((endyr-1987)*12)]';  % select rows for quarterly obs
rangea = [(1991-1987)*12 :12: (endyr-1987)*12]'; % select rows for annual obs

stuff(:,13:12:(30*12+1)) = fedyields(range,6:end);

% for annual maturities array, directly use the 1:30 yr values
zeroyields(1991-yrone+1:end,:) = fedyields(rangea,6:end);


% for monthly:
% (i) flatten at end
stuff(:,30*12+2:40*12+1) = stuff(:,30*12+1)*ones(1,10*12);
% (ii) interpolate within years
for i = 1:11;
    stuff(:,[13:12:(39*12+1)]+i) = stuff(:,[13:12:(39*12+1)])*(1-i/12)...
                   + stuff(:,[25:12:(40*12+1)])*i/12;
end;
% (iii) interpolate within first year
stuff(:,1:4) = fedyields(range,3)*ones(1,4);     % here no fedfunds rate; but not really needed!!
stuff(:,7) = fedyields(range,4);
stuff(:,10) = fedyields(range,7);
for i = 1:2;
    %stuff(:,[4:3:10]+i) = stuff(:,[4:3:10])*(1-i/12) + stuff(:,[7:3:13])*i/12;
    stuff(:,[4:3:10]+i) = stuff(:,[4:3:10])*(1-i/3) + stuff(:,[7:3:13])*i/3;
end;

% record result
zeroyieldsqm((1991-yrone)*4+1:end,:) =  stuff;



% make decimal
zeroyieldsqm = zeroyieldsqm /100;
zeroyields = zeroyields/100;

% form zero coupon bond prices

% monthly discounting
% periodsq = [0 [1:maxmatqm-1]];
% periods = [0 [1:maxmat]];
% discountFactorsMonthlyQM = (1./(1+zeroyieldsqm)).^(1/12);
% discountFactorsMonthly = (1./(zeroyields)).^(1/12);
% pricesqm = discountFactorsMonthlyQM.^(ones(obsq,1)*periodsq);
% prices = discountFactorsMonthly.^(ones(obs,1)*periods(1,1:size(periods,2)-1));
%aaa=pricesqm;

% continuous discounting
pricesqm = exp( - zeroyieldsqm .* (ones(obsq,1)*[.5 [1:1:maxmatqm-1]]/12) );
prices = exp( - zeroyields .* (ones(obs,1)*[1:1:maxmat]) );

% plot monthly v cont disc. prices
%n=55
%plot(1:479,aaa(n,3:size(pricesqm,2)),1:479,pricesqm(n,3:size(pricesqm,2)));
