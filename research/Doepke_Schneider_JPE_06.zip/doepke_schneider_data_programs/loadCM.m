
% derive quarterly and annual copies of constant maturity Treasury yields; yearly maturities
% call these yields



% yieldsq is quarterly 1952:1 - endyear:4
yieldsq = zeros((endyr-1951)*4,30);
obsyq = size(yieldsq,1);


% load constant maturity Treasury yields

getnow = [dirInterest 'tcm1y.txt'];
[cm1,dates1] = loadRawCM(getnow,endDate);
getnow = [dirInterest 'tcm3y.txt'];
[cm3,dates3] = loadRawCM(getnow,endDate);
getnow = [dirInterest 'tcm5y.txt'];
[cm5,dates5] = loadRawCM(getnow,endDate);
getnow = [dirInterest 'tcm10y.txt'];
[cm10,dates10] = loadRawCM(getnow,endDate);
getnow = [dirInterest 'tcm20y.txt'];
[cm20,dates20] = loadRawCM(getnow,endDate);
% 30 year bond only available 1977:1 - 2001:4
getnow = [dirInterest 'tcm30y.txt'];
[cm30,dates30] = loadRawCM(getnow,200112);

%note that this is now quarterly
baseyieldsq = [cm1 cm3 cm5 cm10 cm20];


% yields only available from 1953:2; fill in earlier values
yieldsq(6:end,[1 3 5 10 20]) = baseyieldsq;
yieldsq(1:5,[1 3 5 10 20]) = ones(5,1)*baseyieldsq(1,:);

% fill in 30yr yield before 1977 and after 2001 with 20yr yield
yieldsq(:,30) = [baseyieldsq(1:((1976-1951)*4),5); cm30;baseyieldsq(end-(2004-2001)*4+1:end,5)]; 

% interpolate missing data for 20yr yield for 1987:1-1993:3
range = [(1986-1951)*4+1:(1993-1951)*4-1];
yieldsq(range,20) = (yieldsq(range,10) + yieldsq(range,30))/2;  

%yields = [ones(15,1)*yields(1,:);yields]; % fill 1953 numbers for years 1938-1952
%% now we have an array with size intobs !!!


%finally, interpolate all intermediate yeilds (linearly)
yieldsq(:,2) = (yieldsq(:,1) + yieldsq(:,3))/2;
yieldsq(:,4) = (yieldsq(:,3) + yieldsq(:,5))/2;
ylow = yieldsq(:,5)*ones(1,4);
yhi = yieldsq(:,10)*ones(1,4);
wei = ones(obsyq,1)*[.2 .4 .6 .8]; 
yieldsq(:,[6 7 8 9]) = (1-wei).*ylow + wei.*yhi;
ylow = yieldsq(:,10)*ones(1,9);
yhi = yieldsq(:,20)*ones(1,9);
wei = ones(obsyq,1)*[.1:.1:.9]; 
yieldsq(:,[11:19]) = (1-wei).*ylow + wei.*yhi;
ylow = yieldsq(:,20)*ones(1,9);
yhi = yieldsq(:,30)*ones(1,9);
wei = ones(obsyq,1)*[.1:.1:.9]; 
yieldsq(:,[21:29]) = (1-wei).*ylow + wei.*yhi;



% old yields matrix for mortgage calculations

range = [4:4:obsyq]';
yields = yieldsq(range,:);



yields = yields/100;
yieldsq = yieldsq/100;