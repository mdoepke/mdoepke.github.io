function [cleanedSeries] = extrapMissing(series);
% Function: extrapMissing.m
% Purpose:  takes a series with missing data and extrapolates
%           from surrounding variables
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Nov 9, 2005
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first, check if the series consists of all missing values 
% or all data. in either case there is nothing to extrapolate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if or(sum(series==0)==0,sum(series~=0)==0)
    cleanedSeries = series;
    return
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% replace all leading or trailing zeros, for the time being,
% with '-1'. at the end we change them back to '0'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% leading zeros
foundData = 0; %=1 when non-zero entry found
rowCount = 0;
while ~foundData
    rowCount = rowCount + 1;
    if isequal(0,series(rowCount,1));
        series(rowCount,1)=-1;
    else
        foundData=1;
    end
end

% trailing zeros
series2 = fliplr(series')';
foundData = 0; %=1 when non-zero entry found
rowCount = 0;
while ~foundData
    rowCount = rowCount + 1;
    if isequal(0,series2(rowCount,1));
        series2(rowCount,1)=-1;
    else
        foundData=1;
    end
end
series = fliplr(series2')'; %flip it back



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% look for strings of zeros in the middle of the series 
% sounded by data. if there are any, extrapolate the zeros linearly 
% using the surrounding two data points
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while 1  % break when no more missings between two data points
    
    % check if no more missing values between two data points
    if sum(series==0)==0
        break
    end
    
    % if not, there are missing values remaining for this series
   
    lowValue=0; %first value with data before zeros
    highValue=0; %second value with data after zeros
    numZeros=0; %number of zeros between values
    rowCount=0; %counter of row number
    
    % find the first value before a zero 
    while isequal(lowValue,0)
        rowCount = rowCount + 1;
        if isequal(series(rowCount,1),0)
            lowValue = series(rowCount-1,1);
            rowCount = rowCount - 1;
        end
    end
    
    % find the number of zeros until the 'high value'
    % and the high value itself
    while isequal(highValue,0);
        rowCount = rowCount + 1;
        if isequal(series(rowCount,1),0)
            numZeros = numZeros + 1;
        else
            highValue = series(rowCount,1);
        end
    end
    
    % fill in the missing data
    series(rowCount-numZeros-1:rowCount,1) = linspace(lowValue,highValue,numZeros+2)';
end

% put zeros back in instead of '-1' for leading and trailing zeros 
cleanedSeries = series.*(series>0);
