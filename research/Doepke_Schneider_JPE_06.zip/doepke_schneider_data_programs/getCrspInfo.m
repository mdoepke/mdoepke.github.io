function [maturityYear,maturityMonth,maturityDay,issueType,couponRate,unique] = getCrspInfo(CRSPID);
% Function: getCrspInfo.m
% Purpose:  takes a CRSPID and records the various information contained in
%           the name, such as Coupon Rate and date
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Oct 13, 2005
% Input:    CRSPID - the 15-digit (string) treasury identifier
% Output:   maturityDate - the YYYYMM format date of maturity
%           maturityDay - the DD format day of maturity
%           couponRate - the coupon rate in percent, e.g. 4.25
%           issueType - the one-digit CRSP issue type (ITYPE)
%           unique - the one-digit CRSP uniquess identifier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

maturityYear = str2num(CRSPID(1,1:4));
maturityMonth = str2num(CRSPID(1,5:6));
maturityDay = str2num(CRSPID(1,7:8));
issueType = str2num(CRSPID(1,10));
couponRate = str2num(CRSPID(1,11:14))/100;
unique = str2num(CRSPID(1,15));