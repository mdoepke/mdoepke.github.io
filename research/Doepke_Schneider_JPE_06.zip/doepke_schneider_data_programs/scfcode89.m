
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program: scfcode89.m
% Purpose: This code does all household group calculations using the 1989 SCF
%          It produces all 1989 tables in the paper. 
%
% Uses:    [note: all files are read by the subcode prepare89all6.m; see there 
%           for a more detailed description of the loaded SCF extract series]
%          SCFTabling1989.xls    - SCF 1989 public extract file  
%          files with extracts from full SCF:
%            earningsnohead.txt    - details on income from 1989 SCF 
%            addition89.txt    - details on business holdings and retirement
%              assets
%            housescf.mat  - details on mortgages
%          assdet.xls   - a subset of the public extract file with asset data
%
% Output:  None
% Note:    Users may wish to sort households by different criteria than those 
%          in the paper. The variables rich1, critvar1, rich2 and critvar2 can  
%          be used to sort using using different variables and quantile
%          thresholds. See line 100ff.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

% combine scf and ffa and print tables for comparison
prepare89all6;

clear all;

load SCFstuff89all;
%load SCFstuff01all;   

%%%% structure of this code:
%% (1) define net worth in terms of current market value
%% (2) calculate positions for all assets separately using
%% the assdetails matrix
%% (3) only after cohort averages are determined,
%% apply factors to get positions with new term structure



%%%%%%% define net worth at market value
% recall that real is nw (at par),nonfin,debt
assets = real(:,1) + real(:,3);
real(:,2) = real(:,2) - bus;  % real(:,2) is now durables only
% also remember that bus is assdetails(:,9) now 
othfin = assets - real(:,2) - assdetails * ones(10,1); 

 
networth = real(:,2)... 
           + othfin...   
           + assdetails * scfassfactors(1,:)'...
           - mortgmv(:,1) ...
           - othdebt .* scfassfactors(1,1);    




%%%%%%%%%%%%%%%%%%%%%%%%%%%% EMPLOYMENT STATUS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% look at employment status
% retired household = head retired or disabled and spouse retired, disabled or homemaker
retired = ((statush==50 | statush==52) & (statuss==50 | statuss==52 | statuss==0 | statuss==80));
% working = at least one person is working
working = ((statush<30 & statush>0) | (statuss <30 & statuss>0)); 
% entrep = work for at least some private business by one member 
entrep = (abush + abuss >0);
% note: could have business but not working for it !
havespouse = (statuss > 0);
workingreally = working.*(ahoursh+ahourss>0); % positive hours
workers = find(workingreally==1);

% include TOTAL earnings in stuff for overal avg measure
earnings1 = asalh + asals;
earnings2 = laby+busy1;




% define index set for the zeroth implicate
imp0 = [0:5:all-5]';

%%%%%%% DEFINE COHORTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set age groups
numco=6;
N=numco-1;
cohorts = zeros(all,numco);
cohorts(:,1) = (age<=35);
cohorts(:,2) = (age>35).*(age<=45);
cohorts(:,3) = (age>45).*(age<=55);
cohorts(:,4) = (age>55).*(age<=65);
cohorts(:,5) = (age>65).*(age<=75);
cohorts(:,6) = (age>75);

popp = sum(weight);
cohortsizes = sum(cohorts.*(weight*(ones(1,numco))))/popp;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DEFINE COHORTS
% two successive sorts, possibly by different variables

%%%% set the criteria and cutoffs
rich1 = .1; % top rich1 in the variable critvar1 are rich
critvar1 = networth;
rich2 = .78; % out of rest, top rich2 in the variable critvar2 are middle class
critvar2 = income;%income;

quantiles = [rich1 rich1+rich2*(1-rich1)]; % collects cumulative sizes of castes within a cohort (rich, mid)


%%%% define the rich group for every cohort 
% want to compute quantiles separately for each implicate and then average  
richval = zeros(1,numco);
for coh = 1:numco;   
richvalhelp = zeros(numco,1);
for i=1:5;   
   % help matrix contains: ALL hh sorted by NW in col 1, then their weights, set to zero of not in current cohort  
help1 = sortrows([critvar1(imp0+i) weight(imp0+i).*cohorts(imp0+i,coh)],1);
   % now help contains in col 2 the cumulative weights, normalized by cohort size
help1(:,2) = cumsum(help1(:,2))/((popp/5)*cohortsizes(coh));    % now have values and quantiles
   % now pick number for nw just below cohort specific cutoff; this should be close enough !
richvalhelp(i) = help1( sum(help1(:,2)<1-rich1) , 1);
end;
richval(coh) = sum(richvalhelp)/5;
end;

  % this is now an allx5 matrix, which picks out the rich of the cohort in the respective column
richie=cohorts.*(critvar1*ones(1,numco) > ones(all,1)*richval);
  % this is rest
notrichie = cohorts.*(critvar1*ones(1,numco) <= ones(all,1)*richval);

%%%% define the middle and poor groups for every cohort
midval = zeros(2,numco);
for coh = 1:numco;   
midvalhelp = zeros(numco,2); % critvar2 and critvar1 cutoffs, the latter to break ties
for i=1:5;   
   % help matrix contains: ALL hh sorted by NW in col 1, then their weights, set to zero if rich or not in current cohort  
help2 = sortrows([critvar2(imp0+i) critvar1(imp0+i) weight(imp0+i).*cohorts(imp0+i,coh).*notrichie(imp0+i,coh)],[1 2]);
   % now help contains in col 2 the cumulative weights, normalized by cohort size
help2(:,3) = cumsum(help2(:,3))/((popp/5)*((1-rich1)*cohortsizes(coh)));    % now have values and quantiles
   % now pick number for nw just below cohort specific cutoff; this should be close enough !
midvalhelp(i,:) = help2( sum(help2(:,3)<1-rich2) , [1 2]);
end;
midval(:,coh) = sum(midvalhelp)'/5;

end;

 % this is now an allx5 matrix, which picks out the middle of the cohort in the respective column
middie = notrichie.*cohorts.*(critvar2*ones(1,numco) > ones(all,1)*midval(1,:));
  % this is rest
poorie = notrichie.*cohorts.*(critvar2*ones(1,numco) <= ones(all,1)*midval(1,:));

for coh = 1:numco;
   if midval(1,coh)==0;
       poorie(:,coh) = notrichie(:,coh).*cohorts(:,coh).*((critvar2 < midval(1,coh))...
                         + (critvar2 == midval(1,coh)) .* (critvar1 < midval(2,coh)));
       middie(:,coh) = (~poorie(:,coh)).*notrichie(:,coh).*cohorts(:,coh);
   end;
end;
     

cohsizpoor = sum( (weight*ones(1,numco)) .* poorie )/popp;
cohsizrich = sum( (weight*ones(1,numco)) .* richie )/popp;
cohsizmid = sum( (weight*ones(1,numco)) .* middie )/popp; 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% balance sheet means

% recall that bus is assdetails(:,10) !
stuff = [real income earnings1 earnings2 assdetails mortgmv othdebt networth];
vars=22;


stuffpoor = zeros(numco,vars); % #gen x # variables
stuffrich = zeros(numco,vars);
stuffmean = zeros(numco,vars);
stuffmid = zeros(numco,vars);
stuffrichperc=stuffmean;
for i = 1:numco; 
    stuffpoor(i,:)  = sum( stuff .* ((weight.*poorie(:,i))*ones(1,vars)) ) / (cohsizpoor(i)*popp);
    stuffrich(i,:) = sum( stuff .* ((weight.*richie(:,i))*ones(1,vars)) ) / (cohsizrich(i)*popp);
    stuffmid(i,:) = sum( stuff .* ((weight.*middie(:,i))*ones(1,vars)) ) / (cohsizmid(i)*popp);
    stuffmean(i,:) = sum( stuff .* ((weight.*cohorts(:,i))*ones(1,vars)) ) / (cohortsizes(i)*popp);
    stuffrichperc(i,:) = sum( stuff .* ((weight.*richie(:,i))*ones(1,vars)) ) ...
                                        ./ sum( stuff .* ((weight.*cohorts(:,i))*ones(1,vars)) );
end;


%%%%%%%%%%%%%%% cohort positions: we want all multiasset arrays to be #assets x 5 
%%% and for single asset vectors row vectors
%%% for mortgages, it is  numval x 5 (this will be in line with market value arrays below)
realpoor = stuffpoor(:,1:3)';
realrich = stuffrich(:,1:3)';
realmid = stuffmid(:,1:3)';
realmean = stuffmean(:,1:3)';
incomepoor = stuffpoor(:,4)';
incomerich = stuffrich(:,4)';
incomemid = stuffmid(:,4)';
incomemean = stuffmean(:,4)';
earnings1poor = stuffpoor(:,5)';
earnings1rich = stuffrich(:,5)';
earnings1mid = stuffmid(:,5)';
earnings1mean = stuffmean(:,5)';
earnings2poor = stuffpoor(:,6)';
earnings2rich = stuffrich(:,6)';
earnings2mid = stuffmid(:,6)';
earnings2mean = stuffmean(:,6)';

assdetailspoor = stuffpoor(:,7:16)';
assdetailsrich = stuffrich(:,7:16)';
assdetailsmid = stuffmid(:,7:16)';
assdetailsmean = stuffmean(:,7:16)';
mortgmvpoor = stuffpoor(:,17:20)';
mortgmvrich = stuffrich(:,17:20)';
mortgmvmid = stuffmid(:,17:20)';
mortgmvmean = stuffmean(:,17:20)';
othdebtpoor = stuffpoor(:,21)';
othdebtrich = stuffrich(:,21)';
othdebtmid = stuffmid(:,21)';
othdebtmean = stuffmean(:,21)';

networthpoor = stuffpoor(:,22)'; % recall that this is only variable already at market value here  
networthrich = stuffrich(:,22)';
networthmid = stuffmid(:,22)';
networthmean = stuffmean(:,22)';

othfinmean = realmean(1,:) + realmean(3,:) - realmean(2,:) - ones(1,10)*assdetailsmean;
othfinpoor = realpoor(1,:) + realpoor(3,:) - realpoor(2,:) - ones(1,10)*assdetailspoor;
othfinrich = realrich(1,:) + realrich(3,:) - realrich(2,:) - ones(1,10)*assdetailsrich;
othfinmid = realmid(1,:) + realmid(3,:) - realmid(2,:) - ones(1,10)*assdetailsmid;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  subpopulation tables
    % GENERAL RECIPE for doing subpopulation tables
    %    (i) create general dummy variable (e.g. working)
    %    (ii) create percentages for mean, poor, rich by feeding this dummy in as `stuff'
    %    (ii) create new subcohort sizes (as a fraction of total popp) by multiplying by cohort sizes
    %           (for total, rich, poor, respectively)
    %    (iii) create new table by feeding variables of interest into `stuff', but using new 
    %             subcohort sizes to calculate the averages

% not necessary in this version where we have already screened out !!!!!!!!!!!!!!!!!
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% constructing the wage for the poor
 % we need working subpopulations to get at the wage for the poor

%% calculate fractions of working, retired and couples AS % of RESPECTIVE POOR COHORT 
varsnow = 3;
stuffnow = [workingreally retired havespouse];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((weight.*poorie(:,i))*ones(1,varsnow)) ) / (cohsizpoor(i)*popp);
end;
percwpoor = stuffnowpoor';
%% for every cohort, translate to working poor population as % of ALL popp
cohsizpoorwr = stuffnowpoor(:,1)' .* cohsizpoor;
wage=zeros(all,1);
%% earnings is LABOR income from scf income questionnaire only 
ear = laby; hou = ahoursh + ahourss;
wage(workers) = ear(workers) ./ hou(workers);
%% now calculate average wage, where we average just over poor workers
varsnow=1;
stuffnow = wage;
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((weight.*workingreally.*poorie(:,i))*ones(1,varsnow)) ) / (cohsizpoorwr(i)*popp);
end;
wagepoor = stuffnowpoor';


%%%%%%%%%%%%%%%%%%%%%%%%%%% now calculate earnings statistics for everybody
varsnow = 10;
spousefrac = zeros(all,1);
%earners = find(ear>0);    % this busfrac concept not sensible with negative bus income !!!!!!!!!
%busfrac(earners) = busy(earners) ./ ear(earners); % drops about 100 non-earners(but workers) 
spousefrac(workers) = ahourss(workers) ./ hou(workers);
stuffnow = [laby (ahoursh+ahourss) busy busy2 spousefrac bus entrep busy1 retacc nomretacc];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((weight.*poorie(:,i))*ones(1,varsnow)) ) / (cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((weight.*richie(:,i))*ones(1,varsnow)) ) / (cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((weight.*middie(:,i))*ones(1,varsnow)) ) / (cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((weight.*cohorts(:,i))*ones(1,varsnow)) ) / (cohortsizes(i)*popp);
end;

% REMEMBER THAT THIS NAME IS MISLEADING - this is reallly about earnings2w !!!
% ALSO NOTE IT IS BEING TRANSPOSED... this is different from realmean
earningswmean = stuffnowmean';
earningswpoor = stuffnowpoor';
earningswrich = stuffnowrich';
earningswmid = stuffnowmid';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INTRODUCING MARKET VALUE and computing netfin, netnom

% for the assets and debt positions we now setup arrays 
% those are numval x #assets x 5(cohorts); here numval = 4 !! 
% for single asset arrays, make it just numval x 5
assdetailsmvmean = zeros(numval,10,numco);
assdetailsmvpoor = zeros(numval,10,numco);
assdetailsmvrich = zeros(numval,10,numco);
assdetailsmvmid = zeros(numval,10,numco);
othdebtmvmean = zeros(numval,numco);
othdebtmvpoor = zeros(numval,numco);
othdebtmvmid = zeros(numval,numco);
othdebtmvrich = zeros(numval,numco);
netfinmean = zeros(numval,numco);
netfinpoor = zeros(numval,numco);
netfinrich = zeros(numval,numco);
netfinmid = zeros(numval,numco);
netnommean = zeros(numval,numco);
netnompoor = zeros(numval,numco);
netnomrich = zeros(numval,numco);
netnommid = zeros(numval,numco);
nnp0rich=zeros(numval,numco);
nnp0poor=zeros(numval,numco);
nnp0mean=zeros(numval,numco);
nnp0mid=zeros(numval,numco);


%% also define position arrays for the full scf!
assdetailsmv = zeros(all,10,numval);
netfinmv = zeros(all,numval);
netnom=zeros(all,numval);
othdebtmv=zeros(all,numval);

for val=1:numval;
assdetailsmvmean(val,:,:) = assdetailsmean .* (scfassfactors(val,:)' * ones(1,numco));  %recall that factors are numval x #assets
assdetailsmvpoor(val,:,:) = assdetailspoor .* (scfassfactors(val,:)' * ones(1,numco));  
assdetailsmvrich(val,:,:) = assdetailsrich .* (scfassfactors(val,:)' * ones(1,numco));  
assdetailsmvmid(val,:,:) = assdetailsmid .* (scfassfactors(val,:)' * ones(1,numco)); 

assdetailsmv(:,:,val) = assdetails .* (ones(all,1)*scfassfactors(val,:));  

othdebtmvmean(val,:) = othdebtmean .* (scfassfactors(val,1) * ones(1,numco));  %recall that factors are numval x #assets
othdebtmvpoor(val,:) = othdebtpoor .* (scfassfactors(val,1) * ones(1,numco));  
othdebtmvrich(val,:) = othdebtrich .* (scfassfactors(val,1) * ones(1,numco));  
othdebtmvmid(val,:) = othdebtmid .* (scfassfactors(val,1) * ones(1,numco));  

othdebtmv(:,val) = othdebt * scfassfactors(val,1);  

netfinmean(val,:) =  ones(1,10) * squeeze(assdetailsmvmean(val,:,:)) - mortgmvmean(val,:) - othdebtmvmean(val,:); 
netfinpoor(val,:) =  ones(1,10) * squeeze(assdetailsmvpoor(val,:,:)) - mortgmvpoor(val,:) - othdebtmvpoor(val,:); 
netfinrich(val,:) =  ones(1,10) * squeeze(assdetailsmvrich(val,:,:)) - mortgmvrich(val,:) - othdebtmvrich(val,:); 
netfinmid(val,:) =  ones(1,10) * squeeze(assdetailsmvmid(val,:,:)) - mortgmvmid(val,:) - othdebtmvmid(val,:); 

netfin(:,val) =   squeeze(assdetailsmv(:,:,val)) * ones(10,1) - mortgmv(:,val) - othdebtmv(:,val); 

bondnnp0mean(val,:) =  ones(1,6) * squeeze(assdetailsmvmean(val,[2 3 4 5 6 7],:)); 
bondnnp0poor(val,:) =  ones(1,6) * squeeze(assdetailsmvpoor(val,[2 3 4 5 6 7],:)); 
bondnnp0rich(val,:) =  ones(1,6) * squeeze(assdetailsmvrich(val,[2 3 4 5 6 7],:)); 
bondnnp0mid(val,:) =  ones(1,6) * squeeze(assdetailsmvmid(val,[2 3 4 6 5 7],:)); 
shortnnp0mean(val,:) =  ones(1,2) * squeeze(assdetailsmvmean(val,[1 10],:)) - othdebtmvmean(val,:); 
shortnnp0poor(val,:) =  ones(1,2) * squeeze(assdetailsmvpoor(val,[1 10],:)) - othdebtmvpoor(val,:); 
shortnnp0rich(val,:) =  ones(1,2) * squeeze(assdetailsmvrich(val,[1 10],:)) - othdebtmvrich(val,:); 
shortnnp0mid(val,:) =  ones(1,2) * squeeze(assdetailsmvmid(val,[1 10],:)) - othdebtmvmid(val,:); 

 %% importantly, for netnom we need lambda itself, because we need to 
 %% separate real and nominal component of equity, not just multiply
 %% all of equity with a factor as in netfin !!
 %% of course, the correct lambda and holdings to get real component are those at current mv

netnommean(val,:) =  netfinmean(val,:) - (extrafactor+lambdahhscf(1)) * (squeeze(assdetailsmvmean(1,8,:))'...
                                                  +  squeeze(assdetailsmvmean(1,9,:))'); 
netnompoor(val,:) =  netfinpoor(val,:) - (extrafactor+lambdahhscf(1)) * (squeeze(assdetailsmvpoor(1,8,:))'...
                                                  + squeeze(assdetailsmvpoor(1,9,:))'); 
netnomrich(val,:) =  netfinrich(val,:) - (extrafactor+lambdahhscf(1)) * (squeeze(assdetailsmvrich(1,8,:))'...
                                                  + squeeze(assdetailsmvrich(1,9,:))'); 
netnommid(val,:) =  netfinmid(val,:) - (extrafactor+lambdahhscf(1)) * (squeeze(assdetailsmvmid(1,8,:))'...
                                                  + squeeze(assdetailsmvmid(1,9,:))'); 

netnom(:,val) =  netfin(:,val) - (extrafactor+lambdahhscf(1)) * (squeeze(assdetailsmv(:,8,1))...
                                                  + squeeze(assdetailsmv(:,9,1))); 

nnp0mean(val,:) =  netnommean(val,:) + lambdahhscf(val) * (squeeze(assdetailsmvmean(1,8,:))'...
                                                  +  squeeze(assdetailsmvmean(1,9,:))'); 
nnp0poor(val,:) =  netnompoor(val,:) + lambdahhscf(val) * (squeeze(assdetailsmvpoor(1,8,:))'...
                                                  + squeeze(assdetailsmvpoor(1,9,:))'); 
nnp0rich(val,:) =  netnomrich(val,:) + lambdahhscf(val) * (squeeze(assdetailsmvrich(1,8,:))'...
                                                  + squeeze(assdetailsmvrich(1,9,:))'); 
nnp0mid(val,:) =  netnommid(val,:) + lambdahhscf(val) * (squeeze(assdetailsmvmid(1,8,:))'...
                                                  + squeeze(assdetailsmvmid(1,9,:))'); 
                                              
nnp0(:,val) =  netnom(:,val) + lambdahhscf(:,val) * (squeeze(assdetailsmv(:,8,1))...
                                                  + squeeze(assdetailsmv(:,9,1))); 

equitynnpmean(val,:) =  - lambdahhscf(val) * (squeeze(assdetailsmvmean(1,8,:))'...
                                                  +  squeeze(assdetailsmvmean(1,9,:))'); 
equitynnppoor(val,:) =  - lambdahhscf(val) * (squeeze(assdetailsmvpoor(1,8,:))'...
                                                  + squeeze(assdetailsmvpoor(1,9,:))'); 
equitynnprich(val,:) =  - lambdahhscf(val) * (squeeze(assdetailsmvrich(1,8,:))'...
                                                  + squeeze(assdetailsmvrich(1,9,:))'); 
equitynnpmid(val,:) =  - lambdahhscf(val) * (squeeze(assdetailsmvmid(1,8,:))'...
                                                  + squeeze(assdetailsmvmid(1,9,:))'); 

                                                                                            
end;


stuff = [(netnom(:,1)>netnom(:,2)), ((netnom(:,2)-netnom(:,1)).*(netnom(:,1)>netnom(:,2))), ...
            ((netnom(:,2)-netnom(:,1)).*(netnom(:,1)<=netnom(:,2))), ...
          (netnom(:,1)>netnom(:,3)), ((netnom(:,3)-netnom(:,1)).*(netnom(:,1)>netnom(:,3))), ...
            ((netnom(:,3)-netnom(:,1)).*(netnom(:,1)<=netnom(:,3))) ];
vars=6;
stuffpoor = zeros(numco,vars); % #gen x # variables
stuffrich = zeros(numco,vars);
stuffmean = zeros(numco,vars);
stuffmid = zeros(numco,vars);
stuffrichperc=stuffmean;
for i = 1:numco; 
    stuffpoor(i,:)  = sum( stuff .* ((weight.*poorie(:,i))*ones(1,vars)) ) / (cohsizpoor(i)*popp);
    stuffrich(i,:) = sum( stuff .* ((weight.*richie(:,i))*ones(1,vars)) ) / (cohsizrich(i)*popp);
    stuffmid(i,:) = sum( stuff .* ((weight.*middie(:,i))*ones(1,vars)) ) / (cohsizmid(i)*popp);
    stuffmean(i,:) = sum( stuff .* ((weight.*cohorts(:,i))*ones(1,vars)) ) / (cohortsizes(i)*popp);
    stuffrichperc(i,:) = sum( stuff .* ((weight.*richie(:,i))*ones(1,vars)) ) ...
                                        ./ sum( stuff .* ((weight.*cohorts(:,i))*ones(1,vars)) );
end;


loserspoor = stuffpoor(:,[1 4])';
losersmid = stuffmid(:,[1 4])';
losersrich = stuffrich(:,[1 4])';
losersmean = stuffmean(:,[1 4])';

amountspoor =  stuffpoor(:,[2 3 5 6])'./stuffpoor(:,[1 1 4 4])';                                             
amountsmid =  stuffmid(:,[2 3 5 6])'./stuffmid(:,[1 1 4 4])';                                             
amountsrich =  stuffrich(:,[2 3 5 6])'./stuffrich(:,[1 1 4 4])';                                             
amountsmean =  stuffmean(:,[2 3 5 6])'./stuffmean(:,[1 1 4 4])';                                             
                                              
                                              



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TABLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('========= overall population ==========');
disp('net worth / nonfin(%nw) / debt(%nw)');
nw = networthmean*cohortsizes';
assets = (networthmean  + mortgmvmean(1,:) + othdebtmvmean(1,:))*cohortsizes';
disp([nw, realmean(2,:)*cohortsizes'/nw, (mortgmvmean(1,:) + othdebtmvmean(1,:))*cohortsizes'/nw]);
disp('netfin (%nw), netnom(%nw)');
disp([netfinmean*cohortsizes'/nw,netnommean*cohortsizes'/nw]);
disp('net worth / nonfin(%assets) / debt(%assets)');
disp([nw, realmean(2,:)*cohortsizes'/assets, (mortgmvmean(1,:) + othdebtmvmean(1,:))*cohortsizes'/assets]);
disp('netfin (%assets), netnom(%assets)');
disp([netfinmean*cohortsizes'/assets,netnommean*cohortsizes'/assets]);


disp('========== overall balance sheet numbers (% assets) ===========');
disp('all');
disp('durables / equity / business / nominal /debt');
disp( ([realmean(2,:); squeeze(assdetailsmvmean(1,[8:9],:));...
           sum(squeeze(assdetailsmvmean(1,[[1:7] 10],:))); mortgmvmean(1,:) + othdebtmvmean(1,:)]*cohortsizes')'/assets );
nwpoor = networthpoor*cohsizpoor'/sum(cohsizpoor);
assetspoor = (networthpoor   + mortgmvpoor(1,:) + othdebtpoor(1,:))*cohsizpoor'/sum(cohsizpoor);%(1-quantiles(2));
disp('poor');
disp('durables / equity / business / nominal /debt');
disp( ([realpoor(2,:); squeeze(assdetailsmvpoor(1,[8:9],:));...
           sum(squeeze(assdetailsmvpoor(1,[[1:7] 10],:))); mortgmvpoor(1,:) + othdebtmvpoor(1,:)]*cohortsizes')'/assetspoor );
nwrich = networthrich*cohsizrich'/quantiles(1);
assetsrich = (networthrich + mortgmvrich(1,:) + othdebtrich(1,:))*cohsizrich'/quantiles(1);
disp('rich');
disp('durables / equity / business / nominal /debt');
disp( ([realrich(2,:); squeeze(assdetailsmvrich(1,[8:9],:));...
           sum(squeeze(assdetailsmvrich(1,[[[1:7] 10]],:))); mortgmvrich(1,:) + othdebtmvrich(1,:)]*cohortsizes')'/assetsrich );
nwmid = networthmid*cohsizmid'/sum(cohsizmid);%(quantiles(2)-quantiles(1));
assetsmid = (networthmid + mortgmvmid(1,:) + othdebtmid(1,:))*cohsizmid'/sum(cohsizmid);%(quantiles(2)-quantiles(1));
disp('middle class');
disp('durables / equity / business / nominal /debt');
disp( ([realmid(2,:); squeeze(assdetailsmvmid(1,[8:9],:));...
           sum(squeeze(assdetailsmvmid(1,[[[1:7] 10]],:))); mortgmvmid(1,:) + othdebtmvmid(1,:)]*cohortsizes')'/assetsmid );



      disp('========== overall balance sheet numbers (% net worth) ===========');
disp('poor (% networth');
disp('durables / equity / business / nominal /debt');
disp([realpoor(2,:); squeeze(assdetailsmvpoor(1,[8:9],:));...
           sum(squeeze(assdetailsmvpoor(1,[[1:7] 10],:))); mortgmvpoor(1,:) + othdebtmvpoor(1,:)]./(ones(5,1)*networthpoor));
 
disp('rich (%nw)');
disp('durables / equity / business / nominal /debt');
disp( [realrich(2,:); squeeze(assdetailsmvrich(1,[8:9],:));...
           sum(squeeze(assdetailsmvrich(1,[[[1:7] 10]],:))); mortgmvrich(1,:) + othdebtmvrich(1,:)]./(ones(5,1)*networthrich) );

disp('middle class');
disp('durables / equity / business / nominal /debt');
disp( [realmid(2,:); squeeze(assdetailsmvmid(1,[8:9],:));...
           sum(squeeze(assdetailsmvmid(1,[[[1:7] 10]],:))); mortgmvmid(1,:) + othdebtmvmid(1,:)]./(ones(5,1)*networthmid) );
disp('averages');
disp('durables / equity / business / nominal /debt');
disp( [realmean(2,:); squeeze(assdetailsmvmean(1,[8:9],:));...
           sum(squeeze(assdetailsmvmean(1,[[[1:7] 10]],:))); mortgmvmean(1,:) + othdebtmvmean(1,:)]./(ones(5,1)*networthmean) );

   
%%%%%%% the breakdown of net nominal positions in the following tables is the basis for Table 1 in the paper 
disp('======== PROFILES BY COHORT ==========');

disp('============ averages ============')
disp('cohort sizes (% of total pop)'); 
disp(cohortsizes);

disp('net worth / nonfin(%nw) / debt(%nw)');
disp([networthmean; realmean(2,:)./networthmean; (mortgmvmean(1,:) + othdebtmvmean(1,:))./networthmean]);
disp('netfin (%nw), netnom(%nw) nnp(0) (%nw)');
disp([netfinmean(1,:)./networthmean;netnommean(1,:)./networthmean;nnp0mean(1,:)./networthmean]);


disp('---------------------------------------');
disp('net nominal positions by instrument (%NW)');
disp('    short')
disp(shortnnp0mean(1,:)./networthmean);
disp('    bond')
disp(bondnnp0mean(1,:)./networthmean);
disp('    mortgage')
disp(-mortgmvmean(1,:)./networthmean);
disp('    equity')
disp((netnommean(1,:)-nnp0mean(1,:))./networthmean);
disp('----------------------------------------------')
disp('total NNP')
disp(netnommean(1,:)./networthmean);




disp('============ the poor ============')
disp('cohort sizes (% of total pop)'); 
disp(cohsizpoor);
disp('relative cohort size');
disp(cohsizpoor./cohortsizes);


disp('net worth / nonfin(%nw) / debt(%nw)');
disp([networthpoor; realpoor(2,:)./networthpoor; (mortgmvpoor(1,:) + othdebtmvpoor(1,:))./networthpoor]);
disp('netfin (%nw), netnom(%nw) nnp0(%nw)');
disp([netfinpoor(1,:)./networthpoor;netnompoor(1,:)./networthpoor;nnp0poor(1,:)./networthpoor]);

disp('---------------------------------------');
disp('net nominal positions by instrument (%NW)');
disp('    short')
disp(shortnnp0poor(1,:)./networthpoor);
disp('    bond')
disp(bondnnp0poor(1,:)./networthpoor);
disp('    mortgage')
disp(-mortgmvpoor(1,:)./networthpoor);
disp('    equity')
disp((netnompoor(1,:)-nnp0poor(1,:))./networthpoor);
disp('----------------------------------------------')
disp('total NNP')
disp(netnompoor(1,:)./networthpoor);





disp('============ the rich ============');
disp('cohort sizes (% of total pop)'); 
disp(cohsizrich);
disp('relative cohort size');
disp(cohsizrich./cohortsizes);
disp('cutoff critvar1 quantile by cohort');
disp(richval);


disp('net worth / nonfin(%nw) / debt(%nw)');
disp(networthrich);
disp([realrich(2,:)./networthrich; (mortgmvrich(1,:) + othdebtmvrich(1,:))./networthrich]);
disp('netfin (%nw), netnom(%nw) nnp0(%nw)');
disp([netfinrich(1,:)./networthrich;netnomrich(1,:)./networthrich;nnp0rich(1,:)./networthrich]);


disp('---------------------------------------');
disp('net nominal positions by instrument (%NW)');
disp('    short')
disp(shortnnp0rich(1,:)./networthrich);
disp('    bond')
disp(bondnnp0rich(1,:)./networthrich);
disp('    mortgage')
disp(-mortgmvrich(1,:)./networthrich);
disp('    equity')
disp((netnomrich(1,:)-nnp0rich(1,:))./networthrich);
disp('----------------------------------------------')
disp('total NNP')
disp(netnomrich(1,:)./networthrich);



disp('============ the middle class ============');
disp('cohort sizes (% of total pop)'); 
disp(cohsizmid);
disp('relative cohort size');
disp(cohsizmid./cohortsizes);
disp('cutoff critvar2 quantile by cohort');
disp(midval);


disp('net worth / nonfin(%nw) / debt(%nw)');
disp(networthmid);
disp([realmid(2,:)./networthmid; (mortgmvmid(1,:) + othdebtmvmid(1,:))./networthmid]);
disp('netfin (%nw), netnom(%nw) nnp0(%nw)');
disp([netfinmid(1,:)./networthmid;netnommid(1,:)./networthmid;nnp0mid(1,:)./networthmid]);

disp('---------------------------------------');
disp('net nominal positions by instrument (%NW)');
disp('    short')
disp(shortnnp0mid(1,:)./networthmid);
disp('    bond')
disp(bondnnp0mid(1,:)./networthmid);
disp('    mortgage')
disp(-mortgmvmid(1,:)./networthmid);
disp('    equity')
disp((netnommid(1,:)-nnp0mid(1,:))./networthmid);
disp('----------------------------------------------')
disp('total NNP')
disp(netnommid(1,:)./networthmid);




redistnwpoorimm = (netnompoor(2,:) - netnompoor(1,:))./networthpoor; 
redistnwpoorgrad = (netnompoor(3,:) - netnompoor(1,:))./networthpoor; 
redistnwrichimm = (netnomrich(2,:) - netnomrich(1,:))./networthrich; 
redistnwrichgrad = (netnomrich(3,:) - netnomrich(1,:))./networthrich; 
redistnwmidimm = (netnommid(2,:) - netnommid(1,:))./networthmid; 
redistnwmidgrad = (netnommid(3,:) - netnommid(1,:))./networthmid; 

redistincpoorimm = (netnompoor(2,:) - netnompoor(1,:))./incomepoor; 
redistincpoorgrad = (netnompoor(3,:) - netnompoor(1,:))./incomepoor; 
redistincrichimm = (netnomrich(2,:) - netnomrich(1,:))./incomerich; 
redistincrichgrad = (netnomrich(3,:) - netnomrich(1,:))./incomerich; 
redistincmidimm = (netnommid(2,:) - netnommid(1,:))./incomemid; 
redistincmidgrad = (netnommid(3,:) - netnommid(1,:))./incomemid; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Table 3 of paper %%%%%%%%%%%%%%%%%%%%%
disp('=========== REDISTRIBUTION (% NW) ==================');
disp(' CASE 1: FULL SURPRISE');
disp('rich ( % nw)');
disp([redistnwrichimm]);
disp('middle ( % nw)');
disp([redistnwmidimm]);
disp('poor ( % nw)');
disp([redistnwpoorimm]);
disp(' CASE 2: INDEXING ASAP');
disp('rich ( % nw)');
disp([redistnwrichgrad]);
disp('middle ( % nw)');
disp([redistnwmidgrad]);
disp('poor ( % nw)');
disp([redistnwpoorgrad]);

disp('=========== REDISTRIBUTION (% income) ==================');
disp(' CASE 1: FULL SURPRISE');
disp('rich ( % inc)');
disp([redistincrichimm]);
disp('middle ( % inc)');
disp([redistincmidimm]);
disp('poor ( % inc)');
disp([redistincpoorimm]);
disp(' CASE 2: INDEXING ASAP');
disp('rich ( % inc)');
disp([redistincrichgrad]);
disp('middle ( % inc)');
disp([redistincmidgrad]);
disp('poor ( % inc)');
disp([redistincpoorgrad]);

if addrate<.0001;

disp('=========== DURATION  ==================');
disp('rich');
disp([abs((netnomrich(3,:) - netnomrich(1,:))./(addrate*netnomrich(1,:)))]);
disp('middle');
disp([abs((netnommid(3,:) - netnommid(1,:))./(addrate*netnommid(1,:)))]);
disp('poor');
disp([abs((netnompoor(3,:) - netnompoor(1,:))./(addrate*netnompoor(1,:)))]);

end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Table 5 of paper %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('=========== DETAILS ON REDISTRIBUTION ==================');
disp('all');
disp('fraction of losers (inst, grad)');
disp(losersmean);
disp('mean gain, loss (/income) (full surprise first, then indexing asap)');
disp(amountsmean./(ones(4,1)*incomemean));
disp('rich');
disp('fraction of losers');
disp(losersrich);
disp('mean gain, loss (/income) (full surprise first, then indexing asap)');
disp(amountsrich./(ones(4,1)*incomerich));
disp('middle');
disp('fraction of losers');
disp(losersmid);
disp('mean gain, loss (/income) (full surprise first, then indexing asap)');
disp(amountsmid./(ones(4,1)*incomemid));
disp('poor ');
disp('fraction of losers');
disp(loserspoor);
disp('mean gain, loss (/income)  (full surprise first, then indexing asap)');
disp(amountspoor./(ones(4,1)*incomepoor));


%%%% redistribution by positions
shortredistnwpoorimm = (shortnnp0poor(2,:) - shortnnp0poor(1,:))./networthpoor; 
shortredistnwpoorgrad = (shortnnp0poor(3,:) - shortnnp0poor(1,:))./networthpoor; 
shortredistnwrichimm = (shortnnp0rich(2,:) - shortnnp0rich(1,:))./networthrich; 
shortredistnwrichgrad = (shortnnp0rich(3,:) - shortnnp0rich(1,:))./networthrich; 
shortredistnwmidimm = (shortnnp0mid(2,:) - shortnnp0mid(1,:))./networthmid; 
shortredistnwmidgrad = (shortnnp0mid(3,:) - shortnnp0mid(1,:))./networthmid; 

bondredistnwpoorimm = (bondnnp0poor(2,:) - bondnnp0poor(1,:))./networthpoor; 
bondredistnwpoorgrad = (bondnnp0poor(3,:) - bondnnp0poor(1,:))./networthpoor; 
bondredistnwrichimm = (bondnnp0rich(2,:) - bondnnp0rich(1,:))./networthrich; 
bondredistnwrichgrad = (bondnnp0rich(3,:) - bondnnp0rich(1,:))./networthrich; 
bondredistnwmidimm = (bondnnp0mid(2,:) - bondnnp0mid(1,:))./networthmid; 
bondredistnwmidgrad = (bondnnp0mid(3,:) - bondnnp0mid(1,:))./networthmid; 

mortredistnwpoorimm = (mortgmvpoor(2,:) - mortgmvpoor(1,:))./networthpoor; 
mortredistnwpoorgrad = (mortgmvpoor(3,:) - mortgmvpoor(1,:))./networthpoor; 
mortredistnwrichimm = (mortgmvrich(2,:) - mortgmvrich(1,:))./networthrich; 
mortredistnwrichgrad = (mortgmvrich(3,:) - mortgmvrich(1,:))./networthrich; 
mortredistnwmidimm = (mortgmvmid(2,:) - mortgmvmid(1,:))./networthmid; 
mortredistnwmidgrad = (mortgmvmid(3,:) - mortgmvmid(1,:))./networthmid; 

equityredistnwpoorimm = (equitynnppoor(2,:) - equitynnppoor(1,:))./networthpoor; 
equityredistnwpoorgrad = (equitynnppoor(3,:) - equitynnppoor(1,:))./networthpoor; 
equityredistnwrichimm = (equitynnprich(2,:) - equitynnprich(1,:))./networthrich; 
equityredistnwrichgrad = (equitynnprich(3,:) - equitynnprich(1,:))./networthrich; 
equityredistnwmidimm = (equitynnpmid(2,:) - equitynnpmid(1,:))./networthmid; 
equityredistnwmidgrad = (equitynnpmid(3,:) - equitynnpmid(1,:))./networthmid; 

disp('=========== REDISTRIBUTION (% NW) BY POSITION ==================');
disp('full surprise in top row; indexing asap in bottom row');
disp('rich ( % nw)');
disp('           short');
disp([shortredistnwrichimm;shortredistnwrichgrad]);
disp('           bond');
disp([bondredistnwrichimm;bondredistnwrichgrad]);
disp('           mortgage');
disp(-[mortredistnwrichimm;mortredistnwrichgrad]);
disp('           equity');
disp([equityredistnwrichimm;equityredistnwrichgrad]);
disp(' --- total -----')
disp([redistnwrichimm;redistnwrichgrad]);
disp('----------------------------------------------------------------');
disp('middle ( % nw)');
disp('           short');
disp([shortredistnwmidimm;shortredistnwmidgrad]);
disp('           bond');
disp([bondredistnwmidimm;bondredistnwmidgrad]);
disp('           mortgage');
disp(-[mortredistnwmidimm;mortredistnwmidgrad]);
disp('           equity');
disp([equityredistnwmidimm;equityredistnwmidgrad]);
disp(' --- total -----')
disp([redistnwmidimm;redistnwmidgrad]);
disp('----------------------------------------------------------------');
disp('poor ( % nw)');
disp('           short');
disp([shortredistnwpoorimm;shortredistnwpoorgrad]);
disp('           bond');
disp([bondredistnwpoorimm;bondredistnwpoorgrad]);
disp('           mortgage');
disp(-[mortredistnwpoorimm;mortredistnwpoorgrad]);
disp('           equity');
disp([equityredistnwpoorimm;equityredistnwpoorgrad]);
disp(' --- total -----')
disp([redistnwpoorimm;redistnwpoorgrad]);
disp('----------------------------------------------------------------');



redistrich1=(netnomrich(2,:) - netnomrich(1,:)).*cohsizrich*popp/(1000000000*ngdp);
redistmid1=(netnommid(2,:) - netnommid(1,:)).*cohsizmid*popp/(1000000000*ngdp);
redistpoor1=(netnompoor(2,:) - netnompoor(1,:)).*cohsizpoor*popp/(1000000000*ngdp);

redistrich2=(netnomrich(3,:) - netnomrich(1,:)).*cohsizrich*popp/(1000000000*ngdp);
redistmid2=(netnommid(3,:) - netnommid(1,:)).*cohsizmid*popp/(1000000000*ngdp);
redistpoor2=(netnompoor(3,:) - netnompoor(1,:)).*cohsizpoor*popp/(1000000000*ngdp);

totplus1=(max(redistpoor1,zeros(1,N+1))+max(redistmid1,zeros(1,N+1))+max(redistrich1,zeros(1,N+1)))*ones(N+1,1);
totminus1=-(min(redistpoor1,zeros(1,N+1))+min(redistmid1,zeros(1,N+1))+min(redistrich1,zeros(1,N+1)))*ones(N+1,1);

plusdist1=[max(redistrich1,zeros(1,N+1));max(redistmid1,zeros(1,N+1));max(redistpoor1,zeros(1,N+1))]/totminus1;
minusdist1=-[min(redistrich1,zeros(1,N+1));min(redistmid1,zeros(1,N+1));min(redistpoor1,zeros(1,N+1))]/totminus1;


totplus2=(max(redistpoor2,zeros(1,N+1))+max(redistmid2,zeros(1,N+1))+max(redistrich2,zeros(1,N+1)))*ones(N+1,1);
totminus2=-(min(redistpoor2,zeros(1,N+1))+min(redistmid2,zeros(1,N+1))+min(redistrich2,zeros(1,N+1)))*ones(N+1,1);

plusdist2=[max(redistrich2,zeros(1,N+1));max(redistmid2,zeros(1,N+1));max(redistpoor2,zeros(1,N+1))]/totminus2;
minusdist2=-[min(redistrich2,zeros(1,N+1));min(redistmid2,zeros(1,N+1));min(redistpoor2,zeros(1,N+1))]/totminus2;

%%%%%%%%%%%%%%%%%%%%%%%%%% Numbers for Tables 2 and 4 of paper %%%%%%%%%%%%%%%%%%%%%
disp('=========== AGGREGATE REDISTRIBUTION  ==================');
disp(' CASE 1: FULL SURPRISE');
disp('Net gain (%gdp), Total losses (%gdp), gains (%losses), ')
disp([(totplus1-totminus1) totminus1 totplus1/totminus1]);
disp('Redistribution (% total losses)');
disp('rich');
disp(plusdist1(1,:)- minusdist1(1,:));
disp('middle');
disp(plusdist1(2,:)- minusdist1(2,:));
disp('poor');
disp(plusdist1(3,:)- minusdist1(3,:));
disp('consumers by caste: rich / middle / poor')
disp([sum(plusdist1(1,:)- minusdist1(1,:)) ...
       sum(plusdist1(2,:)- minusdist1(2,:)) ...
        sum(plusdist1(3,:)- minusdist1(3,:))]);
disp('consumers by age')
disp(sum(plusdist1 - minusdist1));
    
disp('government / row / nonprofits  (%gdp)')
disp([NNPlambda(3:4,5)' NNPlambda(2,5)]/ngdp)

disp('government relative to NNP');
disp(-NNPlambda(3,5)/NNPlambda(3,1));

disp('all consumers rel to total NW');
disp(NNPlambda(1,5)/(nw*popp/1000000000));

disp('shareholders rel to MV');
disp(lambdahhscf(1)-lambdahhscf(2));


disp(' CASE 2: INDEXING ASAP');
disp('Net gain (%gdp), Total losses (%gdp), gains (%losses), ')
disp([(totplus2-totminus2) totminus2 totplus2/totminus2]);
disp('Redistribution (% total losses)');
disp('rich');
disp(plusdist2(1,:)- minusdist2(1,:));
disp('middle');
disp(plusdist2(2,:)- minusdist2(2,:));
disp('poor');
disp(plusdist2(3,:)- minusdist2(3,:));
disp('consumers by caste: rich / middle / poor')
disp([sum(plusdist2(1,:)- minusdist2(1,:)) ...
       sum(plusdist2(2,:)- minusdist2(2,:)) ...
        sum(plusdist2(3,:)- minusdist2(3,:))]);
disp('consumers by age')
disp(sum(plusdist2 - minusdist2));
    
disp('government / row / nonprofits')
disp([NNPlambda(3:4,6)' NNPlambda(2,6)]/ngdp)

disp('government relative to NNP');
disp(-NNPlambda(3,6)/NNPlambda(3,1));

disp('all consumers rel to total NW');
disp(NNPlambda(1,6)/(nw*popp/1000000000));

disp('shareholders rel to MV');
disp(lambdahhscf(1)-lambdahhscf(3));



disp(' CASE 2: INDEXING ASAP -- relative to full surprise');
disp('Net gain, Total losses')
disp([(totplus2-totminus2)/(totplus1-totminus1) totminus2/totminus1]);
  
disp('government / row / nonprofits  (%gdp)')
disp([NNPlambda(3:4,6)' NNPlambda(2,6)]./[NNPlambda(3:4,5)' NNPlambda(2,5)])






%%%%%%%%%%%%%%%%% some statistics on mortgage borrowing used in Technical Apppendix 

varsnow=2;
stuffnow = [havemort adjrate];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((weight.*poorie(:,i))*ones(1,varsnow)) ) / (cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((weight.*richie(:,i))*ones(1,varsnow)) ) / (cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((weight.*middie(:,i))*ones(1,varsnow)) ) / (cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((weight.*cohorts(:,i))*ones(1,varsnow)) ) / (cohortsizes(i)*popp);
end;


mortgfracpoor = stuffnowpoor(:,1)';
mortgfracrich = stuffnowrich(:,1)';
mortgfracmid = stuffnowmid(:,1)';
mortgfracmean = stuffnowmean(:,1)';
adjfracpoor = stuffnowpoor(:,2)'./mortgfracpoor;
adjfracrich = stuffnowrich(:,2)'./mortgfracrich;
adjfracmid = stuffnowmid(:,2)'./mortgfracmid;
adjfracmean = stuffnowmean(:,2)'./mortgfracmean;
tadjfracpoor = stuffnowpoor(:,2)';
tadjfracrich = stuffnowrich(:,2)';
tadjfracmid = stuffnowmid(:,2)';
tadjfracmean = stuffnowmean(:,2)';



%% this stuff gets averages only over mortgage holders in the cohort!!!
varsnow=3;
stuffnow = [mortyear interestnow maturity];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((havemort.* weight.*poorie(:,i))*ones(1,varsnow)) ) ...
                           / (mortgfracpoor(i)*cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((havemort.*weight.*richie(:,i))*ones(1,varsnow)) ) ...
                          / (mortgfracrich(i)*cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((havemort .* weight.*middie(:,i))*ones(1,varsnow)) ) ...
                          / (mortgfracmid(i)*cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((havemort.*weight.*cohorts(:,i))*ones(1,varsnow)) ) ...
                          / (mortgfracmean(i).*cohortsizes(i)*popp);
end;

disp('MORTGAGE INFORMATION');
disp('% hh with mortgages (poor, rich, mid, avg)');
disp([mortgfracpoor;mortgfracrich;mortgfracmid;mortgfracmean]);
disp('% mortgages w. adjustable rate (poor, rich, mid, avg)');
disp([adjfracpoor;adjfracrich;adjfracmid;adjfracmean]);




disp('middle class: year taken out/interest now/ maturity')
disp(round(stuffnowmid(:,1))');
disp(stuffnowmid(:,2)'/100);
disp(stuffnowmid(:,3)');
disp('rich: year taken out/interest now / maturity')
disp(round(stuffnowrich(:,1))');
disp(stuffnowrich(:,2)'/100);
disp(stuffnowrich(:,3)');
disp('poor: year taken out/interest now / maturity')
disp(round(stuffnowpoor(:,1))');
disp(stuffnowpoor(:,2)'/100);
disp(stuffnowpoor(:,3)');


%% this stuff gets averages only over adj mortgage holders in the cohort!!!
varsnow=6;
stuffnow = [mortyear interestnow interestorig maturity change adjoneyear];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((adjrate.* weight.*poorie(:,i))*ones(1,varsnow)) ) ...
                           / (tadjfracpoor(i)*cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((adjrate.*weight.*richie(:,i))*ones(1,varsnow)) ) ...
                          / (tadjfracrich(i)*cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((adjrate .* weight.*middie(:,i))*ones(1,varsnow)) ) ...
                          / (tadjfracmid(i)*cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((adjrate.*weight.*cohorts(:,i))*ones(1,varsnow)) ) ...
                          / (tadjfracmean(i).*cohortsizes(i)*popp);
end;
disp('ADJ RATE HOLDERS ONLY');
disp('middle class: year taken out/interest now/  interest orig / maturity / max change / % one year adj')
disp(round(stuffnowmid(:,1))');
disp(stuffnowmid(:,[2 3])'/100);
disp(stuffnowmid(:,4)');
disp(stuffnowmid(:,5)'/100);
disp(stuffnowmid(:,6)');
disp('rich: year taken out/interest now / interest orig / maturity / max change / % one year adj')
disp(round(stuffnowrich(:,1))');
disp(stuffnowrich(:,[2 3])'/100);
disp(stuffnowrich(:,4)');
disp(stuffnowrich(:,5)'/100);
disp(stuffnowrich(:,6)');
%% this stuff gets averages only over adj mortgage holders in the cohort!!!
varsnow=6;
stuffnow = [mortyear interestnow interestorig maturity change adjoneyear];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((havemort.*(1-adjrate).* weight.*poorie(:,i))*ones(1,varsnow)) ) ...
                           / ((mortgfracpoor(i)-tadjfracpoor(i))*cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((havemort.*(1-adjrate).*weight.*richie(:,i))*ones(1,varsnow)) ) ...
                          / ((mortgfracrich(i)-tadjfracrich(i))*cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((havemort.*(1-adjrate) .* weight.*middie(:,i))*ones(1,varsnow)) ) ...
                          / ((mortgfracmid(i)-tadjfracmid(i))*cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((havemort.*(1-adjrate).*weight.*cohorts(:,i))*ones(1,varsnow)) ) ...
                          / ((mortgfracmean(i)-tadjfracmean(i)).*cohortsizes(i)*popp);
end;

disp('FIXED RATE HOLDERS ONLY');
disp('middle class: year taken out/interest now/  interest orig / maturity / max change / % one year adj')
disp(round(stuffnowmid(:,1))');
disp(stuffnowmid(:,[2 3])'/100);
disp(stuffnowmid(:,4)');
disp(stuffnowmid(:,5)'/100);
disp(stuffnowmid(:,6)');
disp('rich: year taken out/interest now / interest orig / maturity / max change / % one year adj')
disp(round(stuffnowrich(:,1))');
disp(stuffnowrich(:,[2 3])'/100);
disp(stuffnowrich(:,4)');
disp(stuffnowrich(:,5)'/100);
disp(stuffnowrich(:,6)');


disp('================================================');
disp('repeat with par value weighting');

%% a table on mortgage behavior

varsnow=2;
stuffnow = [havemort.*owed adjrate.*owed];
stuffnowpoor = zeros(numco,varsnow); % #gen x # variables
stuffnowrich = zeros(numco,varsnow);
stuffnowmid = zeros(numco,varsnow);
stuffnowmean = zeros(numco,varsnow);
for i = 1:numco; 
    stuffnowpoor(i,:)  = sum( stuffnow .* ((weight.*poorie(:,i))*ones(1,varsnow)) ) / (cohsizpoor(i)*popp);
    stuffnowrich(i,:) = sum( stuffnow .* ((weight.*richie(:,i))*ones(1,varsnow)) ) / (cohsizrich(i)*popp);
    stuffnowmid(i,:) = sum( stuffnow .* ((weight.*middie(:,i))*ones(1,varsnow)) ) / (cohsizmid(i)*popp);
    stuffnowmean(i,:) = sum( stuffnow .* ((weight.*cohorts(:,i))*ones(1,varsnow)) ) / (cohortsizes(i)*popp);
end;


mortgfracpoor = stuffnowpoor(:,1)';
mortgfracrich = stuffnowrich(:,1)';
mortgfracmid = stuffnowmid(:,1)';
mortgfracmean = stuffnowmean(:,1)';
adjfracpoor = stuffnowpoor(:,2)'./mortgfracpoor;
adjfracrich = stuffnowrich(:,2)'./mortgfracrich;
adjfracmid = stuffnowmid(:,2)'./mortgfracmid;
adjfracmean = stuffnowmean(:,2)'./mortgfracmean;

disp('MORTGAGE INFORMATION (value weighted)');
disp('% value of mortgages w. adjustable rate (poor, rich, mid, avg)');
disp([adjfracpoor;adjfracrich;adjfracmid;adjfracmean]);

disp('================================================');
disp('compute overall averages');
mortgfrac = sum(stuffnowmean(:,1).*cohortsizes');
adjfrac = sum(stuffnowmean(:,2).*cohortsizes')/mortgfrac;
disp(adjfrac);