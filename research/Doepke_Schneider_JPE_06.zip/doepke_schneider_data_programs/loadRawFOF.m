function [vars,varNames] = loadRawFOF(tableName);
% Function: loadRawFOF.m
% Purpose:  reads raw flow of funds (fof) data from ascii text file and
%           creates the relevant matlab variables.
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Sept 20, 2005
% Input:    tableName - the complete filename of one ascii table
% Output:   vars.mat - the variables
%           varNames.mat - the corresponding names
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize variables
vars = []; %final variables read from text files
           %For now, rows are years, cols are variable names, 
           %heights are blocks
varNames = {}; %Cell array. For now row N corresponds to block N, 
               %cols are var names.           
blockNum = 0; %number of current variable block

% load the desired ascii file
fid = fopen(tableName,'r'); %open file for read
if isequal(fid,-1) %halt if file input error
    error('Text file cannot be input properly')
end

% initialize counter of variable numbers
numVars = 0;

% read line by line from ascii file, record data and variable names
while 1 %while file is open
    line = fgetl(fid); %input one line from the text file
    if ~isstr(line) 
        %%% end if the end of the file has been reached %%% 
        break
    else 
        %%% end of file not yet reached %%%
        rowFirstColumn = sscanf(line,'%s',1); %get 1st column of row as string
        if isequal(rowFirstColumn,'"DATES"'); %check if current row is header row
            %%% start a new block of data %%%
            blockNum = blockNum + 1; %increment the block number
            rowNum = 0; %reset row counter for this block
            rowHeader = sscanf(line,'%c'); %get whole line as a single string
            rowHeader = strread(rowHeader,'%s','delimiter',' ')'; %char array
            numVars = numVars + size(rowHeader,2); % increment counter of variables
            % record this block's variable names
            varNames(blockNum,1:size(rowHeader,2)) = rowHeader;
        else %otherwise current row is a data row
            %%% read a line of data for this block %%%
            rowNum = rowNum + 1; %increment data row counter
            dataHeader = sscanf(line,'%c'); %read row as a string
            dataHeader = strread(dataHeader,'%s','delimiter',' ')'; %remove spaces
            dataHeaderValues = str2num(char(dataHeader(1,2:size(dataHeader,2))))'; %values
            dataHeaderDate = strread(char(dataHeader(1,1)),'%s','delimiter','"'); 
            dataHeaderDate = str2num(char(dataHeaderDate(2,1))); %date of these values
            % record this date's values
            vars(rowNum,1:size(dataHeaderValues,2)+1,blockNum) = [dataHeaderDate dataHeaderValues];                  
        end % determining whether line is var names or vars
    end % case when end of file not reached 
end %while not end of file

% close the file for reading
fclose(fid);

% make the variables be just a 2D array, and the names just a single row
timePeriods = size(vars,1);
varsPerBlock = size(vars,2);
numBlocks = size(vars,3);
varTemp = zeros(timePeriods,varsPerBlock*numBlocks);
varNamesTemp = {};
for iBlock = 1:numBlocks %turn 3D into 2D
    varTemp(:,(iBlock-1)*varsPerBlock+1:iBlock*varsPerBlock) = vars(:,:,iBlock);
    varNamesTemp(1,(iBlock-1)*varsPerBlock+1:iBlock*varsPerBlock) = varNames(iBlock,:);
end

% return function output
% remove the extra columns (that are all zeros)
vars = varTemp(:,1:numVars);
varNames = varNamesTemp(1,1:numVars);
        