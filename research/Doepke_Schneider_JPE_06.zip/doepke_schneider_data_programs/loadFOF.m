%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program: loadFOF.m
% Purpose: reads all the raw flow of funds (FOF) data from ascii text
%          files, and turns all the variables into matlab format
% By:      Matthias Doepke, Martin Schneider, David Lagakos
% Date:    Oct 11, 2005
% Input:   None
% Uses:    All the raw ascii text data (*.prn) available
%          from http://www.federalreserve.gov/releases/z1/Current/data.htm.
%          The files needed are the ltabs, stabs, and btabs tables.
% Output:  .mat files containing the tables in matlab format.
% Notes:   The input files are expected to be in block format, where the
%          rows correpond to dates and the columns to variable names for each 
%          block. A new block starts where a row corresponds to a new set of
%          variable names, and the subsequent rows start a new set of
%          dates. This program can read the raw ascii files for an
%          arbitrary number of blocks, rows, or variables. So as the FOF
%          data is uptdated to have more variables are more recent data, in
%          theory this program should not have to be updated.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all;
clear all;

maindir = 'C:\temp\jpefinal\';

% file names and raw directory
rawDataDirectory = [maindir 'ffadata\'];
tableInfoFile = 'tableInfo.txt';
instrumentInfoFile = 'instrumentInfo.txt';
suppTableStart = 30; %row in tableInfo the supplemental tables start.

endyr = 2004; % last completed year
obsq = (endyr-1951)*4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Load the info about the tables that will be used, and 
% the instruments that will be pulled
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load info about tables
[tableNumbers,agentNumbers,agentNames,fileNames] = loadTableInfo(tableInfoFile);

% load info about instruments
[instrumentNumbers,instrumentCodes] = loadInstrumentInfo(instrumentInfoFile);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: Read in the tables one by one, keeping only the
%         necessary variables, and putting them into the proper
%         space in 'fof.mat'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% loop over all tables
for iTable = 1:size(fileNames,1) %index of table

    % get the current table's name
    currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
    disp(['Current table is number ',num2str(iTable),' of ',num2str(size(fileNames,1)) ]);
    
    % load in all data for the current table
    [rawVars,rawVarNames] = loadRawFOF(currentTable);
    
    % initialize 'fof' if only one table studied so far
    if iTable==1
        maxInstrumentNum = max(instrumentNumbers); %highest instrument number
        timeSeriesLength = size(rawVars,1); %number of time periods
        agentNum = max(agentNumbers); %number of agents
        fof = zeros(agentNum,timeSeriesLength,maxInstrumentNum);
    end
    
    % record the dates for this table
    % only record for the main tables, which are standard
    % not the supplemental tables with varying dates
    dates = rawVars(:,1)';
    if iTable<suppTableStart;
        fof(agentNumbers(iTable,1),:,1) = dates;
    end
    
    % loop over all series in table. record the data if the series is 
    % actually needed
    for iSeries = 2:size(rawVarNames,2)
        % the number of the current series in the table
        currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
        % loop over all possible instrument matches
        for iInstrument = 1:size(instrumentCodes,1)
            % loop over all codes for the this instrument
            for iCode = 1:size(instrumentCodes,2)
                % check whether this code is a match
                if isequal(instrumentCodes(iInstrument,iCode),currentSeries)
                    %%% we need this series %%%
                    if iTable<suppTableStart %regular table
                        fof(agentNumbers(iTable,1),...
                            1:size(rawVars,1),instrumentNumbers(iInstrument,1)) =...
                            fof(agentNumbers(iTable,1),...
                            1:size(rawVars,1),instrumentNumbers(iInstrument,1))...
                            + rawVars(:,iSeries)';
                        break
                    else %supplemental table
                        % first, transform the yearly data to quarterly
                        quarterlySeries = kron(rawVars(:,iSeries),ones(4,1));
                        % now find index corresponding to first date
                        % this assumes yearly data here.
                        firstDate = str2num([num2str(dates(1,1)) '01']);
                        regularTableDates = fof(1,:,1);
                        firstDateIndex = ...
                             find(regularTableDates==firstDate);
                        % finally, put data into fof at the
                        % appropriate date.
                        fof(agentNumbers(iTable,1),...
                             firstDateIndex:firstDateIndex+size(quarterlySeries,1)-1,...
                             instrumentNumbers(iInstrument,1)) =...
                             fof(agentNumbers(iTable,1),...
                             firstDateIndex:firstDateIndex+size(quarterlySeries,1)-1,...
                             instrumentNumbers(iInstrument,1))...
                             + quarterlySeries';
                         break
                    end %regular or suppl table "if" statement
                end %match-found "if" statement 
            end %iCode
        end %iInstrument
    end %iSeries
end %iTable



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Correct for idiosyncracies in the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Table 1: Households

% savings bonds (316140) recorded as a liability.
% it should not be counted since it is a subtotal
% already counted under 306150
iTable=1;
desiredSeriesName = 316140;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(1,:,6+26) = squeeze(fof(1,:,6+26)) - desiredSeries;

% savings bonds (306110) recorded as an asset.
% it should not be counted, since it's a subtotal already
% included under 306150.
iTable=1;
desiredSeriesName = 306110;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(1,:,6) = squeeze(fof(1,:,6)) - desiredSeries;



% Table 2: Nonfarm Nonfinancial Corp. Double counts several series under "other
% loans and advances, liab." Counts "market value of equities, memo" as a 
% liability when it shouldn't
fof(2,:,48) = zeros(1,timeSeriesLength); %drop 'equtities memo'

% drop #52 since its double counted
fof(2,:,52) = zeros(1,timeSeriesLength);

% set #40 to be just '316925'
% this is to avoid double counting: table reports subtotals
iTable=2;
desiredSeriesName = 316925;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(2,:,40) = desiredSeries;

% set #14 to zero: some of the subcategories of "other loans" were recorded as assets
fof(2,:,14) = 0 * squeeze(fof(2,:,14));


% Table 4: Farms. Problem: counts farm mortgages as an asset when it should 
% really be a liability.
fof(4,:,42) = fof(4,:,16); %set liability value to asset value
fof(4,:,16) = zeros(1,timeSeriesLength);



% Table 6: ROW. Counts "market value of equities, memo" as a 
% liability when it shouldn't. Also, 309100 is counted as an
% asset when it's really a liability.
fof(6,:,48) = zeros(1,timeSeriesLength); %drop 'equtities memo'

% move 309100 from asset to liab
iTable=6;
desiredSeriesName = 309100;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(6,:,26) = fof(6,:,26) - desiredSeries; %subtract from assets
fof(6,:,52) = fof(6,:,52) + desiredSeries; %add to liabilities



% Table 7: Fed. #28 (checkable deposits) double counts.
% Series 302500 is a liability, but treated as an asset.

% set #28 to be just series 312000
iTable=7;
desiredSeriesName = 312000;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(7,:,28) = desiredSeries;

% Set 302500 to be a liability, not an asset
iTable=7;
desiredSeriesName = 302500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(7,:,2) = fof(7,:,2) - desiredSeries; %subtract from assets
fof(7,:,28) = fof(7,:,28) + desiredSeries; %add to liabilities


% Table 10: Foreign Banks (L111). Drop 316960 from liab and add to assets
% READ in this series from this table. Remove it from 52, add it to 26.
iTable=10;
desiredSeriesName = 316970;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,26) = fof(agentNumbers(iTable,1),:,26)+desiredSeries;
fof(agentNumbers(iTable,1),:,52) = fof(agentNumbers(iTable,1),:,52)-desiredSeries;

% Table 8: Banks (L110). Drop 411600 from #26 (appears as asset, really a liab
% counted in #52)
iTable=8;
desiredSeriesName = 411600;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(8,:,26) = fof(8,:,26)-desiredSeries;

% keep only 1st code '306800' (in #15) -- the 2nd one is a liab that's already
% counted in #52.
iTable=8;
desiredSeriesName = 306800;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
        break %stop if 1st code found
    end
end
fof(8,:,15) = desiredSeries;



% Table 9: Banks II (L111). Drop 411600 from #26 (appears as asset, really a liab
% counted already in #52)
iTable=9;
desiredSeriesName = 411600;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,26) = fof(agentNumbers(iTable,1),:,26)-desiredSeries;



% Table 17: Private Pension Funds (L118). 'Total liabilities' (=315000) is 
% counted as a liability, when in fact it shouldn't be
% fof(agentNumbers(iTable,1),:,44) = zeros(1,timeSeriesLength);



% Table 22: GSEs (L124). Mortgages subtotals are double counted:
% 306500 should be dropped from #9. 'Other loans' are also double
% counted: 306920 should be dropped from #14

% drop 306500 from #9
iTable=22;
desiredSeriesName = 306500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,9) = fof(agentNumbers(iTable,1),:,9)-desiredSeries;

% drop 306920 from #14; we only we to keep the total 306925
iTable=22;
desiredSeriesName = 306920;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,14) = fof(agentNumbers(iTable,1),:,14)-desiredSeries;



% Table 23: Mortg Pools (L125). 306500 is counted twice in 'mortgages,
% asset' and shouldn't be counted at all.
iTable=23;
desiredSeriesName = 306500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,9) = fof(agentNumbers(iTable,1),:,9)-desiredSeries;



% Table 24: ABSs (L126). Mortgages are double counted:
% 306500 should be dropped from #9.
iTable=24;
desiredSeriesName = 306500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,9) = fof(agentNumbers(iTable,1),:,9)-desiredSeries;



% Table 26: ABSs (L128). Total Assets = 306500 and are incorrectly counted
% as home mortgages. 306500 should be dropped from #9.
iTable=26;
desiredSeriesName = 306500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,9) = fof(agentNumbers(iTable,1),:,9)-desiredSeries;



% Table 27: REITs (L129). Mortgages are double counted:
% 306500 should be dropped from #9.
iTable=27;
desiredSeriesName = 306500;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,9) = fof(agentNumbers(iTable,1),:,9)-desiredSeries;


% Table 28: Brokers & Dealers (L130)
% due to subtotals and asset/liab convention, pick off asset and liab totals directly
iTable=28;
desiredSeriesName = 306720;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,10) = desiredSeries;

desiredSeriesName = 316700;
desiredSeries = zeros(1,timeSeriesLength);
currentTable = [char(rawDataDirectory) char(fileNames(iTable,1))]; 
[rawVars,rawVarNames] = loadRawFOF(currentTable);
for iSeries = 2:size(rawVarNames,2)
    % the number of the current series in the table
    currentSeries = getSeriesName(char(rawVarNames(1,iSeries)));
    if isequal(desiredSeriesName,currentSeries)
        desiredSeries = desiredSeries + rawVars(:,iSeries)';
    end
end
fof(agentNumbers(iTable,1),:,10+26) = desiredSeries;



%%%% Final Idiosyncracy: Mortgages are not split up for all agents into %%%%
%%%% commercial and residential, whereas we would like this. %%%%
%%%% Need to read mortgage totals directly from instrument tables %%%%

% load the 'commercial mortgages' instrument table
currentTable = [char(rawDataDirectory) 'ltab220d.prn']; 
[vars,varNames] = loadRawFOF(currentTable);

% Add up commercial and home mortgages into column 9 (9+26) only
fof(:,:,9) = fof(:,:,9)+fof(:,:,16);
fof(:,:,9+26) = fof(:,:,9+26)+fof(:,:,16+26);

% for iAgent=1:30
%      fof(iAgent,:,9) = fof(iAgent,:,9)+fof(iAgent,:,16);
% end

% Set the 'commercial mortgages' to zero
fof(:,:,16) = zeros(size(fof(:,:,16),1),size(fof(:,:,16),2));
fof(:,:,16+26) = zeros(size(fof(:,:,16+26),1),size(fof(:,:,16+26),2));

numAgents = size(varNames,2);

for iAgent = 1:numAgents
    if isequal(char(varNames(1,iAgent)),'"FL153165505.Q"')
        %household LIAB 
        fof(1,:,16+26) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL103165505.Q"')
        %corp LIAB
        fof(2,:,16+26) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL113165505.Q"')
        %noncorp LIAB 
        fof(3,:,16+26) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL643165503.Q"')
        %REIT LIAB 
        fof(24,:,16+26) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL153065505.Q"')
        %household 
        fof(1,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL103065503.Q"')
        %corp 
        fof(2,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL113065503.Q"')
        %noncorp 
        fof(3,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL213065503.Q"')
        %state gov 
        fof(5,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL313065505.Q"')
        %fed gov 
        %here we add to state gov which is already added
        fof(5,:,16) = fof(5,:,16) + vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL763065505.Q"')
        %comm bank 
        fof(8,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL443065505.Q"')
        %sav inst 
        fof(9,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL513065503.Q"')
        %prop cas lif ins 
        fof(13,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL543065505.Q"')
        %life ins
        fof(12,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL573065505.Q"')
        %priv pensions 
        fof(14,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL223065505.Q"')
        %state and loc pens
        fof(15,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL413065505.Q"')
        %GSE
        fof(20,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL673065505.Q"')
        %ABS 
        fof(21,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL613065503.Q"')
        %fin comp 
        fof(22,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL623065503.Q"')
        %mort comp 
        fof(23,:,16) = vars(:,iAgent)';
    elseif isequal(char(varNames(1,iAgent)),'"FL643065503.Q"')
        % REITs
        fof(24,:,16) = vars(:,iAgent)';
    end
end

% Put commercial mortgages into billions
fof(:,:,16)=fof(:,:,16)/1000;
fof(:,:,16+26)=fof(:,:,16+26)/1000;

% exactTotal = fof(1,:,16)+fof(2,:,16)+fof(3,:,16)+fof(5,:,16)+fof(8,:,16)+fof(9,:,16)+fof(12,:,16)+fof(13,:,16)+fof(14,:,16)+fof(15,:,16)+fof(19,:,16)+fof(21,:,16)+fof(22,:,16)+fof(23,:,16)+fof(24,:,16)
% sum(squeeze(fof(:,:,n))) - sum(squeeze(fof(:,:,n+26)))


%%% convert sectors whose totals are reported in millions (i.e. farms) to billions

%% NOTE: loadFOF already puts commercial mortgages (insts 16,42) into billions
%% for ALL agents because it reads directly from the instrument raw data file. 
%% So we should not change these column
millions = [[1:4] [6:30]]';
millionsInstruments = [[1:15] [17:41] [43:52]]';
fof(millions,:,millionsInstruments) = fof(millions,:,millionsInstruments)/1000; 

% Now save home mortages as total mortgages minus commercial
fof(:,:,9) = fof(:,:,9)-fof(:,:,16);
fof(:,:,9+26) = fof(:,:,9+26) - fof(:,:,16+26);

% dimensions of main ffa data array
% sample size depends on length of files that have been read
sample = size(fof,2);
agents = 30; 

% it is helpful to define a few index sets and associated lengths
ipos = [2:1:53];  % all nom, indirect and misc positions
numpos = 52;
iass = [2:1:27]; % all asset side positions
ilia = [28:1:53]; % all liability side positions 
num1side = 26;


%%% clean up 2 special instruments that were not properly handled by double counted 
%% unallocated insurance contracts: have been written as liabilities into funds' records
%%  set positions to zeros
sample = size(fof,2);
fof(14,:,20+26) = zeros(sample,1);
fof(27,:,20+26) = zeros(sample,1);
fof(12,:,20+26) = sum(squeeze(fof(:,:,20)))';
%fof(12,:,20) = zeros(sample,1);

%% mortgage pools: have been written as liabilities into GSE, pool records
%%  remove for all 
poolassets = sum(squeeze(fof(20,:,iass))')';  % pool assets
gseissues = squeeze(fof(19,:,21+26))';  % agency bonds issued by gses
fof(:,:,21+26) = zeros(agents,sample); % clear agency debt
fof(19,:,21+26) = gseissues;  % refill the two relevant types of bonds
fof(20,:,21+26) = poolassets;
poolshare = poolassets./(poolassets+gseissues);  % share of pools in total agency


%% pension reserves in federal retirement plans
%% turn nonmarketable bonds (incorrectly read as pension reserves) into treasuries
fof(11,:,6) = squeeze(fof(11,:,6)) + squeeze(fof(11,:,18+26)); 
fof(5,:,6+26) = squeeze(fof(5,:,6+26)) + squeeze(fof(11,:,18+26)); 
%%  for pension reserves (liab), write total value of assets
fof(11,:,18+26) = squeeze(fof(11,:,iass)) * ones(num1side,1);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% shorten at end of "endyr" %%%%%%%%%%%

fof = fof(:,1:obsq,:);
poolassets = poolassets(1:obsq);
poolshare = poolshare(1:obsq);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% save results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% save the array for use in fofcalc
save fofdata fof poolshare poolassets rawDataDirectory;

% save totals for bonds for use in factors calculation
mortg = sum(squeeze(fof(:,:,9)))';
corp = sum(squeeze(fof(:,:,8)))';
muni = sum(squeeze(fof(:,:,7)))';
agency = sum(squeeze(fof(:,:,21)))';

save otherlongterm mortg corp muni agency;  