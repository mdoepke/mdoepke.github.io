

%% this code computes annual value for instruments for which we assume constant maturity
%%      called by factors code

% inputs needed are:
%     endyr
%     maxmatnow = maturity 
%     faces =  series of outstanding face values, always begins in 1952 and ends in endyr
% intrate, faces



% observations for which we need coupon rates (add stuff to sample in front)
intobs = obs+maxmatnow-1;
% make coupon rates
useyields = [yields(1,maxmatnow)*ones(maxmatnow-1,1);yields(:,maxmatnow)];

% construct an estimate of new issues from 1952-maxmatnow+1 on
% assume that before 1952, debt was just replicated, and the age distribution was even
% so 1/maxmatnow of constant total face value issued every year !
newfacesearly = faces(1)/maxmatnow;
newfaces = zeros(endyr-1952+maxmatnow,1);
newfaces(1:maxmatnow) = newfacesearly*ones(maxmatnow,1);
for t=2:obs;
    newfaces(t+maxmatnow-1) = faces(t) - faces(t-1) + newfaces(t);
end;

% fill in payments
payments = zeros(obs,maxmatnow);

for t=1:obs;
    yr=t+maxmatnow-1; % year measured off start of useyields and newfaces
    for horizon=1:maxmatnow;
            payments(t,horizon) = payments(t,horizon) + newfaces(yr+horizon-maxmatnow);    % principals expected        
          for age=horizon:maxmatnow;  % age at yr+horizon for bonds of maturity i that pay coupon at horizon
            payments(t,horizon) = payments(t,horizon) + useyields(yr+horizon-age)*newfaces(yr+horizon-age);
          end;                  
    end;
end;


% picture of payments
figure;
surf([1952:endyr],[1:maxmatnow],payments');
title(['expected nominal payments, ' namenow]);




