%% construction of factors for mortgages
%%     is called by factors code


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MORTGAGES %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we want to begin again in 1967
% since the avg maturity in 1963 is 21 years, we use 20 years for all earlier years
% this means we need to go back at least until 1948 = 1967 - 19 to construct facesm;

% actually it is convenient to start 30 years earlier to inc initial steady state phase
%% so arrays below will have intobsm+30 rows
% the actual construction of amort etc will begin for year 32, which is 1949 on current scale!
intobsm = (endyr-1951)+19;
obsshort = endyr-1951;

%%%%%%%%%%%%%%%%%% maturity data: now a vector
matm = [20*ones(15+15,1);fix(housedata(:,3))]; 
matm = [20*ones(30,1);matm]; % this adds the steady state phase


%%%%%%%%%%%%%%%%%%%%% mortgage face values data 
mortg = mortgages(4:4:end); % from fof
mortg = mortg(1:end-1); % convert to annual 52-01
facesm = [mortg(1)*ones(35+15,1);mortg];  % this is total; length is intobsm+30 (to accom init period)
%facesm = 100*ones(intobsm+30,1);
%facesm = zeros(intobsm+30,1);

%mortg=zeros(intobsm+30,1);
%mortg(60)=100;

%%%%%%%%%%%%%%%%%%%%%% floating rate percentage data
% actual data begins in 1982
% we have made up numbers for the earlier period (donbe previously when constructing housedata.txt
% basically start in 1963 with 20%, 
% then have it gradually increase, reaching a plateau of 60% 1976-81 (this is 
% the historical high, realized in 1984)

float = [.2*ones(15,1);housedata(:,4)/100];
%float = [.12*ones(28+15,1);.1+.04*[1:6]';float(35:end)];
%float = [.12*ones(28+19,1);.12+.12*[1:2]';float(35:end)];
float = [.06*ones(28+21,1);float(35:end)];
float = [float(1)*ones(30,1);float];



%%%%%%%%%%%%%%% splitting up faces: set up & initialize arrays where we will record float/fixed
facesfloat = zeros(intobsm+30,1);
facesfixed = zeros(intobsm+30,1); % these split up faces will be calculated recursively below
facesfixedage = zeros(intobsm+30,maxmat); % second argument is age of otstanding loan 0...29
facesfloatage = zeros(intobsm+30,maxmat); % second argument is age of otstanding loan 0...29
%% initialize, withextra 30 years
facesfloat(1:31) = float(1)*facesm(1:31);
facesfixed(1:31) = (1-float(1))*facesm(1:31); % these split up faces will be calculated recursively below
facesfixedage(1:31,1:30) = (1-float(1))*facesm(1:31)*[ones(1,20) zeros(1,10)]/matm(1); 
facesfloatage(1:31,1:30) = float(1)*facesm(1:31)*[ones(1,20) zeros(1,10)]/matm(1); 


%%%%%%%%%%%%%%%%%  dealing with missing mortgage rate data
% 1952-63, mortgage rate = 20yr Treasury rate; before that: mortgage rate = 1952 20yr Treasury rate
mortgrates = [yields(1,20)*ones(34+15,1);yields(1:11,20);housedata(:,2)/100];
%mortgrates = [yields(1,20)*ones(34+15,1);yields(1:11,20);yields(housedata(:,3),2)/100];

%mortgrates = 0.01 * ones(intobsm+30,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% new array for tracking rates after 
 % create copies of mortgrates to track those rates!
 mortgratestrack = zeros(intobsm+30,intobsm+30);
 mortgratestrack(1:31,:)=ones(31,1)*mortgrates';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% new array for payments, depending on where we are currently
%%%%% this is what will be used to calculate payments!
%%  not just origin year of loan
%% format here is calendar time in rows, origin year of loan in column
%% so i,j entry is payment to be from year i forward on loan originated in year j 
%% to track how the payments on a loan are reduced over time with lower interest rates,
%%    can go down columns
%% to calculate outstanding columns given time i expectations, use a row vector here!
pmttrack = zeros(intobsm+30,intobsm+30);



%%%%%%%%%%%%%%%%%%%%%%%%%%% steady state phase: compute pmt and issues to sustain faces, fill arrays
% even distribution is replicated in initial situation 
% this is very different from bonds: in steady state with constant issue, constant maturity,
% the relationship between total faces and issues is: 

earlypmt = mortg(1) / sum([20:-1:1].*exp(-mortgrates(1)*[1:20]));
earlyissue = earlypmt * (1 - exp(- 20*mortgrates(1))) * exp(-mortgrates(1))/ (1-exp(-mortgrates(1)));

% [this is because also on the loans issued the past matm years, we repay 1/matm for every one !]

%% factor that links pmt, faces for different vintages:
discountsums = cumsum(exp(-mortgrates(1)*[1:20])); 
earlyagefactor = discountsums([20:-1:1]); % idea: agefactor(age+1)*pmt = outstanding faces for loans aged age !

% now ready to fill arrays
for age=0:19;
facesfixedage(1:31,age+1) = (1-float(1))* earlypmt * earlyagefactor(age+1);
facesfloatage(1:31,age+1) = float(1)* earlypmt * earlyagefactor(age+1);
end;

newfacesfixed = zeros(intobsm+30,1); 
newfacesfixed(1:31) = (1-float(1))*earlyissue * ones(31,1);
newfacesfloat = zeros(intobsm+30,1); 
newfacesfloat(1:31) = float(1)*earlyissue * ones(31,1);
newfacesm = zeros(intobsm+30,1); 
newfacesm(1:31) = earlyissue * ones(31,1); % this is new faces in total

pmt=zeros(intobsm+30,1);
pmt(1:31) = earlypmt*ones(31,1);
pmttrack(1:31,:)=ones(31,intobsm+30)*earlypmt;




agefactor = zeros(intobsm+30,1);
for t=1:intobsm+30;
   discountsums = cumsum(exp(-mortgrates(t)*[1:matm(t)])); 
   agefactor(t,1:matm(t)) = discountsums([matm(t):-1:1]); % idea: agefactor(age+1)*pmt = outstanding faces for loans aged age !
end;
% allows to easily calculate amortization !!!
% outstanding of bonds issued at t once they are age yrs out = agefactor(t,age) * pmt(t)

% logic: we calculate newfaces for 1948 ff, 19 years before payments calc starts 
% we also add 20 extra periods up front, to make possible recursive calculation for 
% newfaces starting in 1948

% calculate repayments for the years after 1948
for t=32:intobsm+30; % counts starting years    
    % overall tilgung can be calculated from joint value issued
     tilgung=0; tilgungfloat=0; tilgungfixed=0;       
     for age=1:maxmat;      % loan made age years ago
        if matm(t-age)>age-1;    %this means the loan is not fully amortized BEFORE t 
           tilgung = tilgung + pmt(t-age)*exp(-mortgrates(t-age)*(matm(t-age)-age+1)) ;
           tilgungfloat = tilgungfloat + float(t-age)*pmt(t-age)*exp(-mortgrates(t-age)*(matm(t-age)-age+1)) ;
           tilgungfixed = tilgungfixed + (1-float(t-age))*pmt(t-age)*exp(-mortgrates(t-age)*(matm(t-age)-age+1)); 
       %[t age]
       %    pause;    
          
       end;
     end;
%    tilgung = sum ( (matm([t-1:-1:t-maxmat]) > [0:maxmat-1]) .* facesm([t-1:-1:t-maxmat)./matm([1:t-1) ); % check greatr or equal
    newfacesm(t) = facesm(t) - facesm(t-1) +  tilgung;
%%% new mortgages issued in t 
    pmt(t) = (1-exp(-mortgrates(t))) * newfacesm(t) / (exp(-mortgrates(t))*(1 - exp(-matm(t)*mortgrates(t))));
    newfacesfixed(t) = (1-float(t))*newfacesm(t);
    newfacesfloat(t) = float(t)*newfacesm(t);
    
   % separate fixed and floating par values - etwas doppelt gemoppelt mit der tilgung aber macht das prinzip klar
    facesfixed(t) = facesfixed(t-1) - tilgungfixed + newfacesfixed(t);
    facesfloat(t) = facesfloat(t-1) - tilgungfloat + newfacesfloat(t);     
    % for faces by age, subtract total cumulative tilgung from newfaces
    facesfixedage(t,1) = newfacesfixed(t);
    facesfloatage(t,1) = newfacesfloat(t);
    for age = 1:maxmat-1; 
        if matm(t-age)>age;  % this means loan is not fully amortized BEFORE OR IN t 
            facesfixedage(t,age+1) = (1-float(t-age)) * pmt(t-age) * agefactor(t-age,age+1);
            facesfloatage(t,age+1) = float(t-age) * pmt(t-age) * agefactor(t-age,age+1);
            %sum(exp(-mortgrates(t-age)*[matm(t-age):-1:(matm(t-age)-age+1)]));
        end;
    end;
    
    
    %%% reset payment for refinancing
       %% note that the recursive calculation refers back to pmt as the anchor of the mortg calculation
       %% what we now do is recompute payment for all loans that have higher than current rates!
       %% using rest maturity as maturity, and current faces as outstanding
       %% this also changes amortization on all refinanced loans
    for age = 1:maxmat-1;   
        if matm(t-age)>age;  % this means loan is not fully amortized BEFORE OR IN t 
             if mortgrates(t)<mortgrates(t-age);    % condition for refinancing
                disp('next'); 
                disp([t t-age]);
                disp([pmt(t-age) mortgrates(t-age) (pmt(t-age) * agefactor(t-age,age+1))]); 
               pmt(t-age) = (1-exp(-mortgrates(t))) * (pmt(t-age) * agefactor(t-age,age+1))...
                                  / (exp(-mortgrates(t))*(1 - exp(-(matm(t-age)-age)*mortgrates(t))));
               mortgrates(t-age) = mortgrates(t);
                 % must replace agefactor for the loans issued in t-age
                 % this provides new evolution of PV, given new payment 
               discountsums = cumsum(exp(-mortgrates(t)*[1:(matm(t-age)-age)])); 
               agefactor(t-age,age+1:matm(t-age)) = discountsums([matm(t-age)-age:-1:1]);        
               
               disp([pmt(t-age) mortgrates(t-age) pmt(t-age) * agefactor(t-age,age+1)]);
             % rem that pmt*agefactor is faces (by age), and that matm-age is rest mat!!!                              
             end;
        end;
    end;    
           
mortgratestrack(t,:) = mortgrates';     % the just updated mortgrates and pmt are copied into the track part 
pmttrack(t,:)=pmt';

end;
    

paymentsm = zeros(obsshort,maxmat); % it's never beyond 30
paymentsmfull = zeros(obsshort,maxmat); % this records fulll payments, float also

% we want age specific corrections for fixed rate mortgage borrower ONLY
% for the age specific part, can then just use float to get fraction per cohort for scf adj.
paymentsmage = zeros(obsshort,maxmat,maxmat); % third dimension is age of loan
paymentsmagefull = zeros(obsshort,maxmat,maxmat); % again a copy for full 
%%paymentsmagefloat = zeros(obs,maxmat,maxmat); % also a copy for float 
parfixedage = zeros(obsshort,maxmat); % second dimension is age of loan

for t=1:obsshort;
    yrm=t+50-1; % year measured off start of relevant newfacesm
    for horizon=1:maxmat;
        for age = 0:maxmat-1;  
            if matm(yrm-age)>age+horizon-1;  % loan is not fully amortized BEFORE yrm + horizon
                paymentsmage(t,horizon,age+1) = (1-float(yrm-age))*pmttrack(yrm,yrm-age);
%                paymentsmagefloat(t,horizon,age+1) = float(yrm-age)*pmt(yrm-age);
                paymentsmagefull(t,horizon,age+1) = pmttrack(yrm,yrm-age);
                paymentsm(t,horizon) = paymentsm(t,horizon) + (1-float(yrm-age))*pmttrack(yrm,yrm-age);
                paymentsmfull(t,horizon) = paymentsmfull(t,horizon) + pmttrack(yrm,yrm-age);
            end; 
       end;
   end;
end;        
       
%%%%%%%%%%%%%%%%%%%%%%%%
% drop the artificial first twenty years again
facesm = facesm(31:end);
facesfixedage = facesfixedage(31:end,:);
facesfloatage = facesfloatage(31:end,:);

facesfixed = facesfixed(31:end);
facesfloat = facesfloat(31:end);
newfacesfixed = newfacesfixed(31:end);
newfacesfloat = newfacesfloat(31:end);
newfacesm = newfacesm(31:end);
matm = matm(31:end);
float = float(31:end);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% now for the factors, be careful to distinguish floating rate and fixed

% aggregate perspective for FOF correction requires one factor that corrects 
% for both floating rate and market value, since our data give SUM of par values !
parm = facesm(20:end);
parfixed = facesfixed(20:end);
parfloat = facesfloat(20:end);
parfixedage = facesfixedage(20:end,:);
parfloatage = facesfloatage(20:end,:);


mvfixed = zeros(sc,endyr-1951);
mvfixedage = zeros(sc,endyr-1951,maxmat);

for sc=1:scenarios;
    
    mvfixed(sc,:) =  sum( (squeeze(eval(sc,:,:)).*paymentsm)' );    
for age=0:maxmat-1;
    mvfixedage(sc,:,age+1) = sum( (squeeze(eval(sc,:,:)).*squeeze(paymentsmage(:,:,age+1)))' );
end;
end;    
    

figure;
surf([1952:2004],[1:30],(squeeze(mvfixedage(1,:,:))./parfixedage)');
title('market value adjustment, fixed rate mortgages by age');


% picture of payments
figure;
surf([1952:2004],[1:30],paymentsm');
title('expected nominal payments (fixed rate mortg)');



figure;
plot([1952-19:2004],[newfacesfixed./newfacesm facesfixed./facesm newfacesm./facesm]);
legend('fixed rate share in new issues','fixed share in outstanding','new issues in outstanding');
title('evolution of fixed rate debt');

