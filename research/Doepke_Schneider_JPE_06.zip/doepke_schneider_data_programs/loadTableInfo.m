function [tableNumbers,agentNumbers,agentNames,fileNames] = loadTableInfo(tableInfoFile);
% Function: loadTableInfo.m
% Purpose:  Loads matrices with the desired info for each table
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Sept 22, 2005
% Input:    tableInfoFile - the name of the file in which the table
%                           names and column info are located.
% Output:   tableNumbers - simple numerical ordering of tables
%           agentNumbers - maps each table to an agent
%           agentNames - one-word name of each agent
%           fileNames - names of the files corresponding to each table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize variables
tableNumbers = []; 
agentNumbers = []; 
agentNames = {}; %cell array
fileNames = {}; %cell array

% load the file for reading
fid = fopen(tableInfoFile,'r');
if isequal(fid,-1) %halt if file input error
    error('Text file cannot be input properly')
end

% read and discard the first line
line1 = fgetl(fid);

% read the subsequent lines, which are the instruments and codes
while 1 %while files open
     newLine = fgetl(fid); %input one line from the names file
    if ~isstr(newLine) 
        %%% end of the file has been reached %%% 
        break
    elseif isequal(newLine,'')
        %%% blank line reached %%%
        break
    else    
        %%% end of data not yet reached %%%
        %turn line into cell array
        newLine = sscanf(newLine,'%c');
        newLine = strread(newLine,'%s')'; 
        
        % record the relevant info for this row
        tableNumbers = [tableNumbers; str2num(char(newLine(1,1)))];
        agentNumbers = [agentNumbers; str2num(char(newLine(1,2)))];
        agentNames = [agentNames; newLine(1,3)];
        fileNames = [fileNames; newLine(1,4)];
        
    end %case when file not done
end % end of file
        
% close the file
fclose(fid);