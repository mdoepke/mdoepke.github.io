
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program: factors.m
% Purpose: This code reads interest and Treasury data and constructs revaluation 
%          factors for 5 instrument classes: government, mortgages, muni, 
%          corporate, short; also computes share of short instruments in 
%          government debt, as well as age dependent revaluation factors 
%          for mortgages in selected years (cf the variable 'pickyears' in 
%          line ///).
%          Factors are for (i) restating positions at market value and 
%          (ii) the the Full Surprise and Indexing ASAP inflation experiments 
%          considered in the paper. 
%          Both experiments are based on an inflation episode of length 
%          'epilength' and annual extra inflation rate 'addrate' 
%          (cf lines 200ff).        
%          The code also produces Figure 4 of the paper and Figure 1 of the 
%          Technical Appendix, as well as a number of other graphs that 
%          illustrate the revaluation factors.
%
% Uses:    [note: all files should be in the directory pointed to by the 
%           variable maindir in line ???]
%          CPIAUCSL.xls    - Fed's seasonally adjusted cpi; monthly end-of month
%           (see line ??? for reading)
%          housedata.xls   - Federal Housing Finance Board historical summary 
%             table 9 (see line ???)
%          \data\m\ directory  -  Fed constant maturity rates from 
%             release h.15 (see the code loadCM.mat)
%             note: if h15.zip file from web is unzipped, a directory 'data' will 
%                   be created, with m as one of its subdirectories!
%          zeroyld1.xls, zeroyld2.xls  -  McCulloch-Kwan zero coupon interest 
%             rate series (see the code loadzeros.mat)
%          fedyields.m  -  based on Fed's zero coupon yield data
%          treasCRSP.mat   -  file with data from CRSP Treasury database, prepared
%             by the code loadTreas.m
%          otherlongterm.mat - positions of long term instruments from FFA, prepared
%             by the code loadFOF.m
%
% Output:  basefactors.mat, to be used by fofcalc.m
%
% Updating: to update this code, all input data must be extended and the 
%           variables 'endyr' and 'endDate' must be reset (cf lines 80ff)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



close all; clear all;

% maindir points to main directory
maindir = 'C:\temp\jpefinal\';


%%%%%%%%%%%%%%%%%% notes on structure
%
% there are 3 different procedures
%
% (1) for government debt, use quarterly data on interest rates, debt,
% from CRSP 
%
% (2) for mortgages, use annual data on interest rates, contract structure 
% from FHFB, 1967-2004, and combine with FFA par values
% this leads to annual revaluation factors 1952-2004.
%   (this is in the mortgfac code)
%
% (3) for muni, corporate, agency bonds, use annual data on interest rates
% from Fed, and FFA par values.
% this is also done at annual level, 1952-2004 and then fill in quarters
%    (this is done by repeatedly applying the onematfac code)


% also obtain revaluation factors by age of household for 1989, 2001,
%  and save factors for combination with SCF
pickyears = [1989 2001];


rloadCM = 'loadCM';

% this should be directory with Fed interest data
dirInterest = [maindir 'data\m\'];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PRELIMINARIES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% here specify end of sample
endyr = 2004;
endDate = 200412; %in YYYYMM format

% sample sizes
% long annual sample: for bond calculation: from 52-04, 53 observations
obs=endyr-1951; 
% quarterly sample 52-04
obsq = obs * 4;

% maximal maturity 
% for the annual samples, yearly payments, 30 years
maxmat = 30;
% for the quarterly samples, monthly payments, 40*12+1 months
maxmatqm = 40*12+1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CM INTEREST RATES %%%%%%%%%%%%%%%%%%%%%%%%%
% load Fed constant maturity yield curve, from release h.15, in %

run(rloadCM);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ZERO COUPON YIELDS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load mcculloch zero coupon yields

loadzeros_edit;
%% result of this
%% matrices yields and prices (both intobs x maxmat)





%%%%%%%%%%% FORMAT INFLATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this is fred's seasonally adjusted cpi; monthly end-of month 1947ff
% note that fred reports cpi at beg of month; we use number for end of prev month
cpi = xlsread('CPIAUCSL.xls');
% discard first couple of obs and also the date column
cpim = cpi((1951-1946)*12 : 1+(endyr-1946)*12, 1);
% inflation arrays have last realization (for t) in position for date t
inflm = log(cpim(2:end))-log(cpim(1:end-1));
infl = log(cpim(13:12:end))-log(cpim(1:12:end-12));
inflq = log(cpim(4:3:end))-log(cpim(1:3:end-3));




%%%%%%%%%%%%%%%%%%%%%%% DATA ON OTHER LONG TERM ASSETS 

% now load mortgages / corporate bonds / muni / agency ; from ffa
% this file was prepared by loadFOF
load otherlongterm;
mortgages = mortg;

% mortgage data
% annual since 1963; columns of interest are int.rate (4) / maturity (5)/ % floating (13) (all for new mortgages)
housedata = xlsread('housedata.xls');
housedata = housedata(:,[1 4 5 13]);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VALUATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% format for the matrices is: 

% zero coupon interest rates
%    zeroyieldsm, pricesqm            obsq x maxmat
%    zeroyields, prices               obs x maxmat
%    zeroyieldsashort, pricesashort   obsshort x maxmat

% zero coupon prices
%    evalqm            scenarios x obsq x maxmatqm
%    eval             scenarios x obs x maxmat
%    pricesashort       scenarios x obsshort x maxmat

% adjustment factors
%    allfactors
%    

% construct various real term structures

% first need matrix of ACTUAL expected inflation factors (years x horizons) 
inflexp = zeros(obs,maxmat);      % cumulative inflation factor
inflexpqm = zeros(obsq,maxmatqm);

inflexppp = zeros(obs,maxmat);    % per period inflation expectations array (annual)

% use realized inflation when available, then project out 2004 value
helpinfl = [infl; ones(maxmat,1)*infl(end)];
for i=1:obs;
inflexp(i,:) = exp( cumsum(helpinfl(i+1:i+maxmat))' );
inflexppp(i,:) = helpinfl(i+1:i+maxmat)';
end;

helpinflqm = [inflm; ones(maxmatqm,1)*infl(end)];
for i=3:3:obs*12;
inflexpqm(i/3,:) = exp( cumsum(helpinflqm(i+1:i+maxmatqm))' );
%inflexppp(i/3,:) = helpinfl(i+1:i+maxmat)';
end;

% real zero coupon bond price and ytm
realprices = prices.*inflexp;
realpricesqm = pricesqm.*inflexpqm;
realyields =  - log(realprices) ./ (ones(obs,1)*[1:1:maxmat]);  % real ytm




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% define inflation scenarios

scenarios = 3; % three scenarios: market value, full surprise, indexing asap
epilength = 10; % episode length in years


% make figure 4 of paper
addrate = .05;   % this is for the picture only!
addratem=.05/12;
indasapqm1 = exp([addratem*[1:1:epilength*12] addrate*epilength*ones(1,maxmatqm-epilength*12)]);
addrate=.2;
addratem=.2/12;
indasapqm2 = exp([addratem*[1:1:epilength*12] addrate*epilength*ones(1,maxmatqm-epilength*12)]);
figure;
hold on;
plot([1/12:1/12:15],1./indasapqm1(1:15*12),'g-','LineWidth',2);
plot([1/12:1/12:15],1./indasapqm2(1:15*12),'b-','LineWidth',2);
plot([1/12:1/12:15],(1/indasapqm2(16*12))*ones(1,15*12),'b--','LineWidth',2);
plot([1/12:1/12:15],(1/indasapqm1(16*12))*ones(1,15*12),'g--','LineWidth',2);
set(gca,'FontSize',14);
legend('5% inflation for 10 years','20% inflation for 10 years');
xlabel('Maturity');
ylabel('Remaining Value');

print -depsc2 losses.eps;

% actual addrate used in calculations
% 5% for most results in "Inflation and the Redistribution of Nominal Wealth"
% 10% for most results in "Effects on Aggregates anbd Welfare"
addrate = .05;%1e-10;  % extra inflation to be added per year

% NOTE: for all pictures and computation involving DURATION, use instead
%addrate = 1e-10;
%epilength=30;
% the calculations are then like computing a numerical derivative...

addratem = addrate/12;

eval = zeros(scenarios,obs,maxmat);
evalqm = zeros(scenarios,obsq,maxmatqm);

eval(1,:,:) = prices;
evalqm(1,:,:) = pricesqm;

% full surprise
eval(2,:,:) = prices/exp(addrate*epilength);
evalqm(2,:,:) = pricesqm/exp(addrate*epilength);

% indexing asap
% new excess cumulative expected inflation factors
indasap = exp([addrate*[1:1:epilength] addrate*epilength*ones(1,maxmat-epilength)]);
indasapqm = exp([addratem*[1:1:epilength*12] addrate*epilength*ones(1,maxmatqm-epilength*12)]);

eval(3,:,:) = prices ./ (ones(obs,1) * indasap);
evalqm(3,:,:) = pricesqm ./ (ones(obsq,1) * indasapqm);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ADJUSTMENT FACTORS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% GOVERNMENT DEBT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this file was prepared by loadTreas
treasfile = ['treasCRSP'];
load(treasfile);

% reformat payments to 1952-2004 quarterly
payments = payments(9:(endyr-1949)*4,:);
spayments = spayments(9:(endyr-1949)*4,:);
pubpayments = pubpayments(9:(endyr-1949)*4,:);
spubpayments = spubpayments(9:(endyr-1949)*4,:);
values = values(9:(endyr-1949)*4,:);
svalues = svalues(9:(endyr-1949)*4,:);
pubvalues = pubvalues(9:(endyr-1949)*4,:);
spubvalues = spubvalues(9:(endyr-1949)*4,:);
parvalues = parvalues(9:(endyr-1949)*4,:);
sparvalues = sparvalues(9:(endyr-1949)*4,:);
pubparvalues = pubparvalues(9:(endyr-1949)*4,:);
spubparvalues = spubparvalues(9:(endyr-1949)*4,:);



% result is quarterly, so use evalqm and fill directly into basefactors
for sc = 1:scenarios;
 basefactors(sc,:,1) = sum( (squeeze(evalqm(sc,:,:)).*(pubpayments))')' ./ (pubparvalues);
 basefactors(sc,[[1:32] 212],1) = sum( (squeeze(evalqm(sc,[[1:32] 212],:)).*(payments([[1:32] 212],:)))')' ...
                                                           ./ (parvalues([[1:32] 212],:));
 basefactors(sc,:,5) = sum( (squeeze(evalqm(sc,:,:)).*(spayments))')' ./ (sparvalues);
end;


% short bond share
shortgovshare = sparvalues./(sparvalues + pubparvalues);
shortgovshare([[1:32] 212]) = sparvalues([[1:32] 212])./(sparvalues([[1:32] 212]) + parvalues([[1:32] 212]));


mktfactor =  (values + svalues)./(sparvalues+parvalues);
mktpubfactor =  (pubvalues + spubvalues)./(spubparvalues+pubparvalues);

discfactor = sum( (squeeze(evalqm(1,:,:)).*(spayments+payments))')' ./ (sparvalues+parvalues);
discpubfactor = sum( (squeeze(evalqm(1,:,:)).*(spubpayments+pubpayments))')' ./ (spubparvalues+pubparvalues);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CORPORATE BONDS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

faces = corp(4:4:end);
maxmatnow = 10;
namenow = 'corporate';

onematfac;

% here annual data, so use eval and load into afactors
for sc = 1:scenarios;
 afactors(sc,:,3) = sum( (squeeze(eval(sc,:,1:maxmatnow)).*payments)')' ./ faces;
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MUNICIPAL BONDS %%%%%%%%%%%%%%%%%%%%%%%%%

faces = muni(4:4:end);
maxmatnow = 20;
namenow = 'muni';


onematfac;

% here annual data, so use eval and load into afactors
for sc = 1:scenarios;
 afactors(sc,:,2) = sum( (squeeze(eval(sc,:,1:maxmatnow)).*payments)')' ./ faces;
end;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MORTGAGES %%%%%%%%%%%%%%%%%%%%%%%%%%%%

mortgfac;

% market value: take floating rate at par!
afactors(1,:,4) = (mvfixed(1,:)' + parfloat)./parm;
% full surprise: devalue floating rate at constant factor
afactors(2,:,4) = (mvfixed(2,:)' + parfloat./exp(addrate*epilength))./parm;
% indexing asap: devalue floating rate with first yr surprise only
afactors(3,:,4) = (mvfixed(3,:)' + parfloat./exp(addrate))./parm;


%%%%%%%%%%%%%%%%%%%%%%%%%% MORTGAGES AS 7 YEAR BONDS %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% (this is for illustration; will not be used in fofcalc for valuation)
 
faces = mortgages(4:4:end);
maxmatnow = 7;
namenow = '7 year mortg';

onematfac;

% here annual data, so use eval and load into afactors
for sc = 1:scenarios;
 afactors(sc,:,7) = sum( (squeeze(eval(sc,:,1:maxmatnow)).*payments)')' ./ faces;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SHORT INSTRUMENTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

basefactors(1,:,6) = ones(obsq,1);
basefactors(3,:,6) = ones(obsq,1)/exp(addrate*.5);
basefactors(2,:,6) = ones(obsq,1)/exp(addrate*epilength);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% format variables to quarterly 1952:1-2002:1

% bonds where we worked with annual scheme: convert to quarterly
for sc=1:scenarios;

    endoflastyear = kron( [squeeze(afactors(sc,1,[2 3 4 7]))'; squeeze(afactors(sc,1:end-1,[2 3 4 7]))] ,ones(4,1));
    endofcurrentyear = kron( squeeze(afactors(sc,:,[2 3 4 7]) ),ones(4,1));
    weights = kron(ones(obs,4),[.75;.5;.25;0]);
    
    basefactors(sc,:,[2 3 4 7])= [weights.*endoflastyear + (1-weights).*endofcurrentyear];
 
end;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% mortgfactors (age-specific) for scf years
mortgfactors = zeros(length(pickyears),scenarios+1,30);


for yearindex=1:length(pickyears);

    yearnow = pickyears(yearindex) 
    
    obsnow = yearnow - 1951;
    
     
mortgfactors(yearindex,1,:) = (squeeze(mvfixedage(1,obsnow,:))' + parfloatage(obsnow,:)) ./ (parfixedage(obsnow,:) + parfloatage(obsnow,:));
mortgfactors(yearindex,2,:) = (squeeze(mvfixedage(2,obsnow,:))' + parfloatage(obsnow,:)/exp(addrate*epilength))...
                                                                ./ (parfixedage(obsnow,:) + parfloatage(obsnow,:));
mortgfactors(yearindex,3,:) = (squeeze(mvfixedage(3,obsnow,:))' + parfloatage(obsnow,:)./exp(addrate*.5))...
                                                               ./ (parfixedage(obsnow,:) + parfloatage(obsnow,:));
mortgfactors(yearindex,4,:) = ones(1,30);

end;



save basefactors basefactors mortgfactors shortgovshare addrate pickyears endyr scenarios;

figure;
hold on;
plot([1982:2004],newfacesfixed(50:end)./newfacesm(50:end),'b','LineWidth',2);
plot([1975:2004],facesfixed(43:end)./facesm(43:end),'g','LineWidth',2);
plot(1989,1-.3072,'b*');
plot([1975:1982],newfacesfixed(43:50)./newfacesm(43:50),'b--','LineWidth',2);
legend('fixed rate share in new issues','fixed share in outstanding loans',...
    '1989 SCF');
%text(1992,1-.3057-.1,'1989 SCF');
%title('Evolution of Fixed Rate Mortgages');
axis ([1975 2004 .3 1]);
print -depsc2 mortgshare.eps;



