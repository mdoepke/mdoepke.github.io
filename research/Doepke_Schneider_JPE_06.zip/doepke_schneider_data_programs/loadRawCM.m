function [cm,dates] = loadRawCM(fileName,endDate);
% Function: loadRawCM.m
% Purpose:  loads one of Fed's constant maturity (CM) series
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Nov 11, 2005
% Input:    endDate -- the final date data is required in YYYYMM format
%           fileName -- the ascii file name to be read in
% Output:   cm - the desired CM series 
%           dates - the corresponding dates in YYYYMM format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% read monthly data from text file %%%

% initialize output vars
cm = [];
dates = [];

% load the file for reading
fid = fopen(fileName,'r');
if isequal(fid,-1) %halt if file input error
    error('Text file cannot be input properly')
end

while 1 %while not end of file
    % get the next line in the raw data
    newLine = fgetl(fid);
    if isequal(newLine,'') %get 1st character
        firstChar=' ';
    else
        firstChar = newLine(1,1);
    end
    if ~isstr(newLine) 
        %%% end if the end of the file has been reached %%% 
        break
    elseif ~or(isequal(firstChar,'0'),isequal(firstChar,'1')) 
        %%% end of file not reached yet, text, blank lines etc found %%%
    else
        %%% end of file not reached yet, data found %%%
        
        % turn data to strings
        newLine = sscanf(newLine,'%c');
        newLine = strread(newLine,'%s')'; 

        % format variables in this line
        seriesDate = char(newLine(1,1)); %raw date
        year = char(seriesDate(1,4:7));
        month = char(seriesDate(1,1:2));
        seriesDate = str2num([year month]); %date as a number
        seriesValue = str2num(char(newLine(1,2))); %series value
        
        % record this line's values
        dates = [dates; seriesDate];
        cm = [cm; seriesValue];
        
    end %if eof not reached 
end %while not end of file

% close the file for reading
fclose(fid);

% adjust the series to end at 'endDate'
dates = dates(dates<=endDate);
cm = cm(1:size(dates,1),1);


%%%%% convert the series to quarterly %%%%

datesStr = num2str(dates);
years = str2num(datesStr(:,1:4));
months = str2num(datesStr(:,5:6));
quarters = ((months>=01).*(months<=03)*1)...
    +((months>=04).*(months<=06)*2)...
    +((months>=07).*(months<=09)*3)...
    +((months>=10).*(months<=12)*4);
datesQuarterly = years*100 + quarters;

% initialize quarterly matrices
cm_quarterly = [];
dates_quarterly =[];

% loop over all quarters
firstDate = years(1,1)*100 + quarters(1,1);
lastDate = years(size(years,1),1)*100 + quarters(size(quarters,1),1);
currentQuarter = firstDate;
while currentQuarter <= lastDate
    
    % compute averages for this quarter
    avg = sum(cm(datesQuarterly==currentQuarter))...
         /sum(datesQuarterly==currentQuarter);
    
    % record the quarterly data
    cm_quarterly = [cm_quarterly; avg];
    dates_quarterly = [dates_quarterly; currentQuarter];
    
    % advance to the next quarter
    quarterString = num2str(currentQuarter); 
    if quarterString(1,5:6)=='04'
        currentQuarter = currentQuarter + 100 - 3;
    else
        currentQuarter = currentQuarter + 1;
    end
end

% return output
cm = cm_quarterly;
dates = dates_quarterly;