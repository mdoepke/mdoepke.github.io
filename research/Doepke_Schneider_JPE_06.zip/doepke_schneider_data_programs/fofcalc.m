
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program: fofcalc.m
% Purpose: This code does all sectoral calculations and produces Figures
%          1-3, 5 and 6 of the paper. It also prepares sectoral redistribution 
%          vectors for those years for which SCF calculations are to be done 
%          (years are selected in the variable pickyears in factors.m). Sectoral 
%          statistics for those years are presented in a set of tables.
%
% Uses:    [note: all files should be in the directory pointed to by the 
%           variable path in line ???]
%          fdimv.xls    - annual market value of FDI from BEA  
%               (see line ??? for reading)
%          nipagdptable.xls   -  nominal gdp from nipa (Table 1.1.5 quarterly) 
%          various ltab tables from the ffa, contained in the 'ffadata' directory, 
%                which the code finds by following the path specified in loadFOF.m
%          basefactors.mat  -   valuation factors prepared by factors.m 
%          fofdata.mat  -   ffa data converted to matlab by loadFOF.m
%
% Output:  files named factorsYYYY.mat, where YYYY represents years selected by  
%                the variable pickyears in factors.m  
%
% Updating: to update this code, all input data must be extended
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



close all; clear all;


printflag = 0; % set to 1 to save pictures as postscript files

%%%%%%% load flow of funds data prepared by the loadFOF code
% the matrix fof in the file fofdata is #sectors(28)  x  sample size  x  # instruments
% column 1 is date, then 26 asset and 26 liability columns
load fofdata;

%%%%%%% load valuation factors and treasury short share
load basefactors;
% basefactorsa array has size  numval x sample x 6 (where 6 is number of different factors we made)
% order of basefactors is treasury(bonds) / muni / corp / mortg / treasury(bills) / other short

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% preliminaries %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% observation numbers for years considered in scf application (measured in quarters off 1951:1)
pickobs = (pickyears-1951)*4; % obs in FFA array
pickobsira = pickyears - 1984; % obs in IRA table
        
% define an additional scenario that has everything valued at par
numval=scenarios+1; 

% load quarterly gdp table (nipa 1.1), with dates 1952:1 - endyr:4 preselected
gdptable = xlsread('nipagdptable.xls');
gdp = gdptable(1,3:end)'/1000;

%% set to one if foreign equity is NOT to be counted as equity (default)
noforeignstock=1;


% dimensions of main ffa data array
% sample size depends on length of files that have been read
sample = size(fof,2);
cols = 53;   % maximal number of columns
agents = 30; 
assets = 52;

% it is helpful to define a few index sets and associated lengths
ipos = [2:1:53];  % all nom, indirect and misc positions
numpos = 52;
iass = [2:27]; % all asset side positions
ilia = [28:53]; % all liability side positions 
num1side = 26;
iassnoii = [[2 3] [5:22] 25 27]; % assets except inv. interm. shares 
ilianoii = 26 + [[2 3] [5:22] 25 27]; % assets except inv. interm. shares 
iposnoii = [ iassnoii [28:52]]; % it's ok to have all liab positions
numnoii = 21;

sam = [1952:.25:2004.75]';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% introducing short government 
% this comes from treasury data, not ffa

% rule: households hold no bills directly
% identify outstanding bills
alltreas = squeeze(fof(5,:,6+26))';
allbills = shortgovshare .* alltreas;
insttreas = alltreas - squeeze(fof(1,:,6))'; % institutional holdings of treasuries
instbillshare = allbills ./ insttreas; % share of bills in inst holdings
% rearrange liability side of govmt
fof(5,:,25+26) = allbills;
fof(5,:,6+26) = alltreas - allbills;
% 
for agent=2:30;
  fof(agent,:,25) = instbillshare .* squeeze(fof(agent,:,6))';
  fof(agent,:,6) = (1-instbillshare).*squeeze(fof(agent,:,6))';
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% check raw fof data matrix before any modifications are made
%for n = 1:26;
%    figure;
%    hold on;
%    plot(sam,sum(squeeze(fof(:,:,n))),'k-');
%    plot(sam,sum(squeeze(fof(:,:,n+26))),'r-');
%    diff = sum(squeeze(fof(:,:,n))) - sum(squeeze(fof(:,:,n+26)));
%   plot(sam,diff);
 
%end;
%break




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% handle equity and fdi

%%% read instrument table on corporate equity 
currentTable = [char(rawDataDirectory) 'ltab213d.prn']; 
[equitydet,eqdetnames] = loadRawFOF(currentTable);
% eliminate date column and go to billions
equitydet = equitydet(1:sample,2:end)/1000;

%%% load market value of fdi from bea
% this is annual year end 1982-2004 in millions
% 1982:4 is obs 124
help1 = xlsread('fdimv.xls');
help1=help1(1:end,2);
help0=help1(1:end-1);
%help=help(1:end-1);
fdimv=zeros(sample,1);
fdimv([124:4:end]) = help1;
help1 = help1(2:end);
fdimv([125:4:end-3]) = .75*help0+.25*help1;
fdimv([126:4:end-2]) = .5*help0+.5*help1;
fdimv([127:4:end-1]) = .25*help0+.75*help1;
%fdimv(end)=help1(end);
fdimv=fdimv/1000;

%%% read fdi(at current cost) from ffa
currentTable = [char(rawDataDirectory) 'ltab229d.prn']; 
[misc1,misc1names] = loadRawFOF(currentTable);
% eliminate TWO date columns and go to billions
misc1 = misc1(1:sample,[[2:29] [31:size(misc1,2)-2]])/1000;

%%% fill in fdimv with fdi at current cost before 1982
fdi = misc1(:,16); 
fdifactor = fdimv(124)/fdi(124);
fdimv(1:123) = fdifactor * fdi(1:123); 

%%% define fdi in foreign banks & funding corps in US (current cost)
bankfdi = misc1(:,10);
fundfdi = misc1(:,15);
fundforbankinv = misc1(:,38);


%%% load flow components of FDI to eliminate intercompany debt 
currentTable = [char(rawDataDirectory) 'atab229d.prn']; 
[atab230d,misc1flnames] = loadRawFOF(currentTable);
% eliminate date column and go to billions
atab230d = atab230d(1:sample,2:end)/1000;
% .265 is the average debt fdi over the 81-now sample and series appears stationary
% we assume that level of debt is .265 of total before 81
% after that we cumulate debt (it is book value, quarterly at annual rates) and subtract from total
fdidebt = [.265 * fdimv(1:120); .265*fdimv(120)+cumsum(atab230d(121:end,22)/4)];
fdiequity = fdimv - fdidebt;

%%% remove fdi equity from households' direct holdings
fof(1,:,22) = squeeze(fof(1,:,22))' - fdiequity;
%%% note: fdiequity will be added to row equity holdings below
%%% also, we effectively assume that intercompany loans are in foreign currency




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% remove foreign equity
% domestically held domestic equity: dom nonfin issues + dom fin issues
%                                    - row portfolio invm - fdiequity 
outequity1 = equitydet(:,2)+equitydet(:,4);


domhelddom = equitydet(:,2) + equitydet(:,4) - equitydet(:,8) - fdiequity;
% domestically held foreign equity
domheldfor = equitydet(:,3);

fineqshare = equitydet(:,4)./outequity1; % share of financial outstanding

% foreign equity share in portfolio of domestic agents
foreignshare = domheldfor ./ (domhelddom + domheldfor);

if noforeignstock == 1;
% subtract foreign share from all holdings (except row)
 for agent=1:agents;
    if (agent ~= 6 & agent ~= 30);
     fof(agent,:,22) = (1-foreignshare).*squeeze(fof(agent,:,22)');
    end;
 end;
end;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% dealing with US deposits abroad

discrep = sum(squeeze(fof(:,:,24+26))) - sum(squeeze(fof(:,:,24)));

dollarshare = 1;

fof(:,:,2) = fof(:,:,2) + dollarshare*squeeze(fof(:,:,24));
fof(8,:,2) = fof(8,:,2) + dollarshare*discrep; 

fof(:,:,2+26) = fof(:,:,2+26) + dollarshare*squeeze(fof(:,:,24+26));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% handle pension assets

% remark on pension reserve positions: we never actually use these below!! 
% but they are consistently defined just in case

% remove private dc and db pension claims from households
%  dc assets will be added back in below in disaggregated form !
%fof(1,:,18) = squeeze(fof(1,:,18))' - squeeze(fof(14,:,iass)) * ones(num1side,1); 
% subtract liabilities of private funds from hh pension holdings
%  (recall that private pension sector does not add up in ffa!!)
fof(1,:,18) = squeeze(fof(1,:,18))' - squeeze(fof(14,:,18+26))';
fof(14,:,18+26) = zeros(sample,1);
fof(27,:,18+26) = zeros(sample,1);

% redefine sector 14 as private dc funds
fof(27,1:132,:) = .2 * fof(14,1:132,:);
fof(14,1:132,:) = .8 * fof(14,1:132,:);
fof(14,133:end,:) = squeeze(fof(14,133:end,:) - fof(27,133:end,:));


%%% reclassify part of life insurance as dc pension fund
%% available estimates are 1992-2002 only; rule is: 
%% (i) take 1992 number for separate account: 10% of assets
%% (ii) increase linearly, so that in 2002 it is .29 
%% (iii) assume throughout that sep account has 2/3 in stocks, rest proportionately
sepshare = [.1:.0045:.28]';

% linearly extrapolate the next 11 quarters
sepshare = [sepshare; sepshare(end)+cumsum(.0045*ones(11,1))];
lifesep = zeros(52,cols);

totallife = squeeze(fof(12,161:end,ilia))*ones(26,1);
  % split equity first
sepequity = sepshare.*totallife*(2/3);
nonsepequity = squeeze(fof(12,161:end,22))' - sepequity; 
  % other assets
nonequity = totallife - squeeze(fof(12,161:end,22))';
restshare = sepshare.*totallife./(3*nonequity);
  % this is the new mutual fund component
lifesep(:,iass) = (sepshare*ones(1,26)).*squeeze(fof(12,161:end,iass));
lifesep(:,22) = sepequity;
lifesep(:,18+26) = lifesep(iass) * ones(num1side,1);
  % subtract from other l.i.assets
fof(12,161:end,iass) = ((1-sepshare)*ones(1,26)).*squeeze(fof(12,161:end,iass));
fof(12,161:end,22) = nonsepequity;
  % adjust also liabilities: subtract separate account from pension liab
fof(12,161:end,18+26) = squeeze(fof(12,161:end,18+26))' - sepshare .* totallife;
  % find total pensions, as we found total agency
  % calculate share of sep assets in total pensions
  % for every agent, remove pensions, add new portfolio to agents
 % in fact, only households have pensions !
fof(1,161:end,18) = squeeze(fof(1,161:end,18))' - sepshare.*totallife; 
%% now add life sep to dc pensions funds - then it is separate sector
%% for which we resolve mmmf part!
fof(14,161:end,:) = squeeze(fof(14,161:end,:))+lifesep;
alldc = squeeze(fof(14,:,iass)) * ones(num1side,1);  % useful later for SCF factors (need in trillions) !



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% go to trillions

fof = fof/1000;
equitydet = equitydet/1000;
fdiequity = fdiequity/1000;
fdidebt = fdidebt/1000;
bankfdi=bankfdi/1000; 
fundfdi=fundfdi/1000;
fundforbankinv = fundforbankinv/1000;
fdimv=fdimv/1000;
poolassets = poolassets/1000;
alldc = alldc/1000;
outequity1 = outequity1/1000;
%% check after pension correction
%fofdiscr = zeros(sample,cols);
%for agent = 1:27;
%    fofdiscr = fofdiscr + squeeze(fof(agent,:,:));
%end;
%break;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% consolidate investment intermediaries

%% before consolidation, record shares of different long term bonds held 
%% for use later in directly-held-bonds-multiplier for SCF
%% the order is treas(long), muni, corp, mortg (incl pools), agency

%%% include mortgages now to have cmos covered!

bondqs= squeeze(fof(1,pickobs,[6 7 8 9 21]))...
            + [zeros(length(pickyears),3) ...
                 poolshare(pickobs).*squeeze(fof(1,pickobs,21))' ...
                   -poolshare(pickobs).*squeeze(fof(1,pickobs,21))'];  
bondshares = bondqs ./ (sum(bondqs')'*ones(1,5));



%%% create a record of direct holdings of households for comparison w. SCF
hhraw = squeeze(fof(1,:,:));





%%% consolidate mutual funds and MMMFs
% their shares are held by other inv interm.s
% also, there are no cross holdings between them
% so we assign mmmf and mf assets to holders, proportionately by par value
allmmmf = squeeze(fof(16,:,iass))*ones(num1side,1);
allmf = squeeze(fof(17,:,iass))*ones(num1side,1);
for agent = 1:agents;
    flag=(agent<16)+(agent>17);
    if flag>0;  % except for the mfs themselves
       mmmfshare = fof(agent,:,4)'./allmmmf; % current agent's share in total mmmf assets
       mmmfshare(isnan(mmmfshare)) = 0;  % initially no mmmfs, so set share to zero
       mfshare = fof(agent,:,23)'./allmf;
       mfshare(isnan(mfshare)) = 0;  % initially no mfs, so set share to zero
       fof(agent,:,iass) = squeeze(fof(agent,:,iass)) ...
                                + (mmmfshare*ones(1,num1side)).*squeeze(fof(16,:,iass))...
                                   + (mfshare*ones(1,num1side)).*squeeze(fof(17,:,iass));
    end;
end;


%%% consolidate dc pension assets (from private dc funds and life insurance)

% these are only held by the households - simply add on !
% household pension reserves were removed from hh sector above, are now added back
% the only `pensions claims' at this point are those thru life insurance that are not sep acc
%  as well as the govmt fund db reserves
fof(1,:,iassnoii) = squeeze(fof(1,:,iassnoii)) + squeeze(fof(14,:,iassnoii));





%%% consolidate federally related mortgage pools

% for later use, first record net mortgage positions before consolidation of pools 
% for all agents
% (for hh this has more negative pos, for gov, row.  smaller than final total)
mort = zeros(sample,agents);
for agent=1:agents;
mort(:,agent) = squeeze(fof(agent,:,9))' + squeeze(fof(agent,:,16))' ...
                    - squeeze(fof(agent,:,9+26))' - squeeze(fof(agent,:,16+26))';
end;
% now treat mortgage pools as mutual funds, with 
% mortgage backed securities as equity-style claims on mortgage portfolio
for agent=1:agents;
    if agent ~= 20; % except for mortgage pool sector itself
      % compute share of current agent's (bondholder's) pool assets as a fraction 
      %    of total agency bonds
    totshare = poolshare.*squeeze(fof(agent,:,21)'./poolassets);
      % remove agency bonds corresponding to pools 
    fof(agent,:,21) = (1-poolshare).*squeeze(fof(agent,:,21)');
      % instead add pool assets directly to balance sheet of bondholder
    fof(agent,:,iass) = squeeze(fof(agent,:,iass)) + (totshare*ones(1,num1side)).*squeeze(fof(20,:,iass));
    end; 
end;
fof(20,:,21+26) = zeros(sample,1);   % set to zero for consistency 



%%% another check, after investment intermediary and mortg pools consolidation
%note: misc assets and foreign deposits of mmmf matters
%noii = [[1:13]  15   18 19  [21:30]];
%for n = 1:26;
%    figure;
%    hold on;
%    plot(sam,sum(squeeze(fof(noii,:,n))),'k-');
%    plot(sam,sum(squeeze(fof(noii,:,n+26))),'r-');
%    diff = sum(squeeze(fof(noii,:,n))) - sum(squeeze(fof(:,:,n+26)));
%    plot(sam,diff);
%   
%end;
%break;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% construct consolidated government sector
allgov = zeros(sample,cols);

%% add Fed Reserve to Consol Fed/State/Local Govmt
allgov(:,ipos) = squeeze(fof(5,:,ipos)) + squeeze(fof(7,:,ipos));
%% add pensions: both federal and state&local pensions (we assume all is db!)
allgov(:,iass) = allgov(:,iass) + squeeze(fof(15,:,iass) + fof(11,:,iass)); 
%% record mortgages held by government 
mortgov = mort(:,5) + mort(:,7) + mort(:,11) + mort(:,15);
% subtract pension asset totals from household pension reserves position
%allsl = squeeze(fof(15,:,iass) + fof(11,:,iass)) * ones(num1side,1); % total dbpension claims (par)
allsl = squeeze(fof(15,:,18+26))' + squeeze(fof(11,:,18+26))';
fof(1,:,18) = squeeze(fof(1,:,18))' - allsl; 
% remarks: 
% (i) we do not need to subtract liabilities from allgov, since never added them before
% (ii) at this point, all that is left in hh pension item is 
% claims on life insurance companies, which we assume to be nominal !




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% construct consolidated row sector


%%% add fof row sector and foreign banks
allrow = squeeze(fof(6,:,:)) + squeeze(fof(30,:,:));

 % add fdiequity at market value to equity holdings of row!
 % remove bankfdi as intra-ROW holding
rowportfeq = allrow(:,22); 
allrow(:,22) = allrow(:,22) + fdiequity - bankfdi;
   

%%% reassign part of funding corporations to row
%% rule: all commercial paper liab of fcs are foreign-issued (cf. ffa guide)
%% however, the cp position is also a residual, so a mess
%% in pricnciple, it should be backed by investments in foreign banking offices - fdi(misc liab) 
%% so we assign all 
rowfundpaper =  - fundfdi + fundforbankinv;
fof(26,:,5+26) = squeeze(fof(26,:,5+26))' - rowfundpaper;
allrow(:,5+26) = allrow(:,5+26) + rowfundpaper;
allrow(:,22) = allrow(:,22) - fundfdi;

mortrow = mort(:,6) + mort(:,30);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% handle corporate financial sector 
                                
allfin = zeros(sample,cols);

allfin(:,:) = squeeze(fof(8,:,:)) + squeeze(fof(9,:,:)) + squeeze(fof(10,:,:))...
                    + squeeze(fof(12,:,:)) + squeeze(fof(13,:,:))...
                    + squeeze(fof(18,:,:)) + squeeze(fof(21,:,:)) + squeeze(fof(22,:,:)) ...
                    + squeeze(fof(23,:,:)) + squeeze(fof(24,:,:))...
                    + squeeze(fof(25,:,:)) + squeeze(fof(26,:,:))...
                    + squeeze(fof(19,:,:)) + squeeze(fof(29,:,:));

  mortfin =  sum(mort(:,[8 9 10 12 13 18 21 22 23 24 25 26 19 29])')'  + mort(:,20);
  mortcorp  =  sum(mort(:,[2 27 8 9 10 12 13 18 21 22 23 24 25 26 19 29])')' + mort(:,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% consolidate corporate and derive outstanding equity 
%% consolidated corporate sector: noncorp business + financial + private db plans
allcorp(:,:) = allfin(:,:) + squeeze(fof(2,:,:)) + squeeze(fof(27,:,:));




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% construct various versions of the household sector
%% includes nonprofits and noncorp business
allhh = squeeze(fof(1,:,:))+squeeze(fof(3,:,:))+squeeze(fof(4,:,:));%+squeeze(fof(28,:,:));
%% without nonprofits
onlyhh = squeeze(fof(1,:,:))+squeeze(fof(3,:,:))+squeeze(fof(4,:,:));
%% only noncorp business
hhbus = squeeze(fof(3,:,:)) + squeeze(fof(4,:,:));  % it is important to NOT have holdings thru business in it
%% hh only, w/0 business
hhnobus = squeeze(fof(1,:,:));  

morthhnobus = mort(:,1); 
morthh = mort(:,1)+mort(:,3)+mort(:,4);%+mort(:,28);
morthhonly = mort(:,1) + mort(:,3) + mort(:,4);


%% check concol by broad sector
sectors = zeros(4,sample,cols);
sectors(1,:,:)=allhh;
sectors(2,:,:)=allgov;
sectors(3,:,:)=allcorp;
sectors(4,:,:)=allrow;
   % here define equity: pension and life ins not included (this is discr w fof!!)
   % but we have fdi in it !!
outequity = sum(squeeze(sectors([1 2 4],:,22)))';

 %% to have a scf type calc whre bus treated like equity: here define outstanding priv bus equity!
outbus = squeeze(fof(1,:,27))';

%sam = [1952:.25:2004.75]';
%for n = 1:27;
%    figure;
%    hold on;
%    plot(sam,sum(squeeze(sectors(:,:,n))),'k-');
%    plot(sam,sum(squeeze(sectors(:,:,n+26))),'r-');
%    plot(sam,sum(squeeze(sectors(:,:,n)))-sum(squeeze(sectors(:,:,n+26))),'b-');
%end;
%break;


% check position dicrepancies relative to gdp, 2004
% ass = (allgov(212,1:27)+allhh(212,1:27)+allrow(212,1:27)+allcorp(212,1:27))/gdp(212));
% lia = (allgov(212,27:53)+allhh(212,27:53)+allrow(212,27:53)+allcorp(212,27:53))/gdp(212));
% disc = ass - lia;
% sum(disc([2 3 [5:21]));

%% view the discrepancy
%  [sam/1000 (NNPgov(:,4)+NNPhh(:,4)+NNProw(:,4)+NNPcorp(:,4))./gdp]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% convert to market value 

% for positions, will be using arrays of size numval x sample x agents, where numval = number of values to be computed 
numval = 4; 
% order is current mv / imm inflation / grad inflation / par

% for factors, will be using arrays of zise numval x sample x cols
% with empty first column, and then two copies of nom asset adjustment factors
factors = zeros(numval,sample,cols);


for val = 1:3;
% begin by assigning short run factor
factors(val,:,[2 3 5 10 11 12 13 14 15 17])  = squeeze(basefactors(val,:,6))' * ones(1,10);
% insert other factors
% just assign to what they are made for, and in addition:
% (i) treat commercial mortgages (16) like home mortgages
% (ii) treat life insurance reserves (19), pension reserves at life insurance (18)
% and also unallocated insurance contracts (20; these are life insurance contracts 
% held thru private pension funds) like agency securities (i.e. 20 year riskless coupon bonds) 
factors(val,:,[[6:1:9] 21 16 18 19 20 25]) = squeeze(basefactors(val,:,[ 1 2 3 4 3 3 3 3 3 5])); 

% now second copy for liabilities
factors(val,:,ilia) = squeeze(factors(val,:,iass));
end;

factors(4,:,[2 3 [5:21]]) = ones(sample,19);  
factors(4,:,ilia) = squeeze(factors(4,:,iass));   % importantly, this screens out misc assests /liab

%%%% REMARK: there is now a zero for equity; keep this in mind
%% the factor matrices automatically just pick out the nominal assets,
%% leaving out equity and the hybrid stuff




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% construct net nominal positions 

%% NNP arrays 
% the big array is #valuations x sample x agents
% this calculates nnp for original agents, with only inv interm netted out 
% the is also the enduser nnp for the row
% also 1 gives hh w/o noncorp business
% and 2 gives nonfin corp

%%%%%
%% remark: here we increase NUMVAL by scenearios;
%%  for every scenarios the difference to mkt value is also recorded
%%% will reset this below
numval = numval+scenarios;
NNP = zeros(numval,sample,agents);

% NNP(0) for major sectors
NNPcorp = zeros(sample,numval);
NNPfin = zeros(sample,numval);
NNPgov = zeros(sample,numval);
NNProw = zeros(sample,numval);
NNPhh = zeros(sample,numval);
NNPhhonly = zeros(sample,numval);
NNPhhnobus = zeros(sample,numval);
NNPbus = zeros(sample,numval);
NNPnonfin = zeros(sample,numval);

% arrays for lambda and NNP(lambda)
lambda = zeros(sample,numval);
lambdabus = zeros(sample,numval);
lambdanonfin = zeros(sample,numval);

NNPlambda = zeros(numval,sample,agents);
NNPlambdafin = zeros(sample,numval);
NNPlambdagov = zeros(sample,numval);
NNPlambdarow = zeros(sample,numval);
NNPlambdahh = zeros(sample,numval);
NNPlambdahhnobus = zeros(sample,numval);
NNPlambdahhonly = zeros(sample,numval);

% arrays for gross positions
assetsfin = zeros(sample,numval);
assetshhnobus = zeros(sample,numval);
assetsnonfin = zeros(sample,numval);
liabfin = zeros(sample,numval);
liabhhnobus = zeros(sample,numval);
liabbus = zeros(sample,numval);
liabnonfin = zeros(sample,numval);
liabhhlambda = zeros(sample,numval);

%%%% create also arrays by type of positions

numpos2 = 4;

%%% here we summarize into short (1), long (2), mort (3)
%% and we add: total long (2+3)
%% as well as assets short, liab short, assets total long, liab total long 
posNNPfin = zeros(sample, numval, 3*numpos2);
posNNPgov = zeros(sample, numval, 3*numpos2);
posNNProw = zeros(sample, numval, 3*numpos2);
posNNPhh = zeros(sample, numval, 3*numpos2);
posNNPhhnobus = zeros(sample, numval, 3*numpos2);
posNNPhhonly = zeros(sample, numval, 3*numpos2);
posNNPcorp = zeros(sample, numval, 3*numpos2);
posNNPcorp = zeros(sample, numval, 3*numpos2);
posNNPcorp = zeros(sample, numval, 3*numpos2);
posNNPbus = zeros(sample, numval, 3*numpos2);
posNNPnonfin = zeros(sample, numval, 3*numpos2);

     % we need position lambdas
poslambda = zeros(sample,numval,numpos2);
posNNPlambdafin = zeros(sample, numval, 3*numpos2);
posNNPlambdagov = zeros(sample, numval, 3*numpos2);
posNNPlambdarow = zeros(sample, numval, 3*numpos2);
posNNPlambdahh = zeros(sample, numval, 3*numpos2);
posNNPlambdahhnobus = zeros(sample, numval, 3*numpos2);
posNNPlambdahhonly = zeros(sample, numval, 3*numpos2);


     %we also need index sets that summarize the position groups
  ishortass = [2 3 5 [10:15] 17 25 26];    
  ishortlia = ishortass + 26;
  ilongass = [[6:8] [18:21]];
  ilonglia = ilongass + 26;
  imortass = [9 16];
  imortlia = imortass + 26;
  ilmass = [[6:9] 16 [18:21]];
  ilmlia = ilmass + 26;
   % collect in cell array
  ipos = {ishortass,ishortlia,12;ilongass,ilonglia,7;imortass,imortlia,2;ilmass,ilmlia,9}; 
  
numval=numval-3; 

for val=1:numval;
% fill direct NNP    
for agent = 1:agents;
    NNP(val,:,agent) = (squeeze(factors(val,:,iass)).*squeeze(fof(agent,:,iass))...
                            -squeeze(factors(val,:,ilia)).*squeeze(fof(agent,:,ilia)))*ones(num1side,1);
                       
end;

% for private business, sum farmm and nonfarm
    NNPbus(:,val) = squeeze(NNP(val,:,3))' + squeeze(NNP(val,:,4))';


% other direct positions; fin is for illustration only 
NNPfin(:,val) = (squeeze(factors(val,:,iass)).*allfin(:,iass)...
                            - squeeze(factors(val,:,ilia)).*allfin(:,ilia))*ones(num1side,1);
NNPgov(:,val) = (squeeze(factors(val,:,iass)).*allgov(:,iass)...
                            - squeeze(factors(val,:,ilia)).*allgov(:,ilia))*ones(num1side,1);
NNProw(:,val) = (squeeze(factors(val,:,iass)).*allrow(:,iass)...
                            - squeeze(factors(val,:,ilia)).*allrow(:,ilia))*ones(num1side,1);
NNPhh(:,val) = (squeeze(factors(val,:,iass)).*allhh(:,iass)...
                            - squeeze(factors(val,:,ilia)).*allhh(:,ilia))*ones(num1side,1);
NNPhhnobus(:,val) = (squeeze(factors(val,:,iass)).*hhnobus(:,iass)...
                            - squeeze(factors(val,:,ilia)).*hhnobus(:,ilia))*ones(num1side,1);
NNPhhonly(:,val) = (squeeze(factors(val,:,iass)).*onlyhh(:,iass)...
                            - squeeze(factors(val,:,ilia)).*onlyhh(:,ilia))*ones(num1side,1);
NNPcorp(:,val) = (squeeze(factors(val,:,iass)).*allcorp(:,iass))*ones(num1side,1)...
                            - (squeeze(factors(val,:,ilia)).*allcorp(:,ilia))*ones(num1side,1);

% calculate pool mortgage value
poolmortgages(:,val) = sum((squeeze(factors(val,:,imortass)).*squeeze(fof(20,:,imortass)))')';




%%%%%%%%% gross asset positions
assetshhnobus(:,val) = (squeeze(factors(val,:,iass)).*hhnobus(:,iass))*ones(num1side,1);
liabhhnobus(:,val) =  (squeeze(factors(val,:,ilia)).*hhnobus(:,ilia))*ones(num1side,1);
assetsrow(:,val) = (squeeze(factors(val,:,iass)).*allrow(:,iass))*ones(num1side,1);
liabrow(:,val) =  (squeeze(factors(val,:,ilia)).*allrow(:,ilia))*ones(num1side,1);
assetsgov(:,val) = (squeeze(factors(val,:,iass)).*allgov(:,iass))*ones(num1side,1);
liabgov(:,val) =  (squeeze(factors(val,:,ilia)).*allgov(:,ilia))*ones(num1side,1);
assetsfin(:,val) = (squeeze(factors(val,:,iass)).*allfin(:,iass))*ones(num1side,1) + poolmortgages(:,val);
liabfin(:,val) =  (squeeze(factors(val,:,ilia)).*allfin(:,ilia))*ones(num1side,1) + poolmortgages(:,val);
assetsnonfin(:,val) = (squeeze(factors(val,:,iass)).*(allcorp(:,iass)-allfin(:,iass)...
                          +squeeze(fof(3,:,iass)) +squeeze(fof(4,:,iass))))*ones(num1side,1);
liabnonfin(:,val) = (squeeze(factors(val,:,ilia)).*(allcorp(:,ilia)-allfin(:,ilia)...
                          +squeeze(fof(3,:,ilia)) +squeeze(fof(4,:,ilia))))*ones(num1side,1);
liabbus(:,val) =  (squeeze(factors(val,:,ilia)).*hhbus(:,ilia))*ones(num1side,1);
assetsbus(:,val) =  (squeeze(factors(val,:,iass)).*hhbus(:,iass))*ones(num1side,1);

                        %%%%%%%%% here interject calculation of subposition NNPS


         for posnow=1:numpos2;
% logic changes: first, assign assets and liabilities (at positions numpos+1:2*numpos and 
%     2*numppos+1:3*numpos, respectively), then take differences, which will be at 1:numpos!!
          
  posNNPfin(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*allfin(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPfin(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*allfin(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
        posNNPfin(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*allfin(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*allfin(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
         
  posNNPgov(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*allgov(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPgov(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*allgov(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
        posNNPgov(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*allgov(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*allgov(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);

  posNNProw(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*allrow(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNProw(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*allrow(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
        posNNProw(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*allrow(:,ipos{posnow,1})...
                                   - squeeze(factors(val,:,ipos{posnow,2})).*allrow(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);

  posNNPhhnobus(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*allhh(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPhhnobus(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*allhh(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
        posNNPhhnobus(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*hhnobus(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*hhnobus(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);

  posNNPhhonly(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*onlyhh(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPhhonly(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*onlyhh(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
        posNNPhhonly(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*onlyhh(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*onlyhh(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);

  posNNPcorp(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*allcorp(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPcorp(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*allcorp(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
            posNNPcorp(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*allcorp(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*allcorp(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
                        
  posNNPbus(:,val,posnow+numpos2) = (squeeze(factors(val,:,ipos{posnow,1})).*hhbus(:,ipos{posnow,1}))*ones(ipos{posnow,3},1);
posNNPbus(:,val,posnow+2*numpos2) = (squeeze(factors(val,:,ipos{posnow,2})).*hhbus(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
            posNNPbus(:,val,posnow) = (squeeze(factors(val,:,ipos{posnow,1})).*hhbus(:,ipos{posnow,1})...
                            - squeeze(factors(val,:,ipos{posnow,2})).*hhbus(:,ipos{posnow,2}))*ones(ipos{posnow,3},1);
         end;                

          % record pool mortgages as bonds!  [for now done also in the NET positions]
         
           
                 
        posNNPfin(:,val,2) = posNNPfin(:,val,2) + (posNNPfin(:,val,3) - squeeze(factors(val,:,9))'.*mortfin);
        posNNPcorp(:,val,2) = posNNPcorp(:,val,2) + (posNNPcorp(:,val,3) - squeeze(factors(val,:,9))'.*mortcorp);
        posNNPhh(:,val,2) = posNNPhh(:,val,2) + (posNNPhh(:,val,3) - squeeze(factors(val,:,9))'.*morthh);
        posNNPhhnobus(:,val,2) = posNNPhhnobus(:,val,2) + (posNNPhhnobus(:,val,3) - squeeze(factors(val,:,9))'.*morthhnobus);
        posNNPhhonly(:,val,2) = posNNPhhonly(:,val,2) + (posNNPhhonly(:,val,3) - squeeze(factors(val,:,9))'.*morthhonly);
        posNNPgov(:,val,2) = posNNPgov(:,val,2) + (posNNPgov(:,val,3) - squeeze(factors(val,:,9))'.*mortgov);
        posNNProw(:,val,2) = posNNProw(:,val,2) + (posNNProw(:,val,3) - squeeze(factors(val,:,9))'.*mortrow);
      
        posNNPfin(:,val,3) = squeeze(factors(val,:,9))'.*mortfin;
        posNNPcorp(:,val,3) = squeeze(factors(val,:,9))'.*mortcorp;
        posNNPhh(:,val,3) = squeeze(factors(val,:,9))'.*morthh;
        posNNPhhnobus(:,val,3) = squeeze(factors(val,:,9))'.*morthhnobus;
        posNNPhhonly(:,val,3) = squeeze(factors(val,:,9))'.*morthhonly;
        posNNPgov(:,val,3) = squeeze(factors(val,:,9))'.*mortgov;
        posNNProw(:,val,3) = squeeze(factors(val,:,9))'.*mortrow;
         
        
        
        for posnow=1:numpos2;                    
            poslambda(:,val,posnow) = - squeeze(posNNPcorp(:,val,posnow))./ outequity;  
            poslambdabus(:,val,posnow) = - squeeze(posNNPbus(:,val,posnow))./ outbus;  
            posNNPlambdagov(:,val,posnow) = squeeze(posNNPgov(:,val,posnow)) - squeeze(poslambda(:,val,posnow)).*allgov(:,22);
            posNNPlambdarow(:,val,posnow) = squeeze(posNNProw(:,val,posnow)) - squeeze(poslambda(:,val,posnow)).*allrow(:,22);
            posNNPlambdahh(:,val,posnow) = squeeze(posNNPhh(:,val,posnow)) - squeeze(poslambda(:,val,posnow)).*allhh(:,22);
            posNNPlambdahhonly(:,val,posnow) = squeeze(posNNPhhonly(:,val,posnow)) - squeeze(poslambda(:,val,posnow)).*onlyhh(:,22);
            posNNPlambdafin(:,val,posnow) = squeeze(posNNPfin(:,val,posnow)) - squeeze(poslambda(:,val,posnow)).*allfin(:,22);
        end;
        
        


                        
                        
%%% lambda
%% lambda(:,1) is at current mv
%% the others are used in experiments, but, importantly, ONLY for nominal part
%% real component of equity must always be calculated from OLD lambda(:,1) !!
lambda(:,val) = - NNPcorp(:,val) ./ outequity;

%% position incorporating indirect nom asset thru equity
for agent = 1:agents;
    NNPlambda(val,:,agent) = squeeze(NNP(val,:,agent))' - lambda(:,val).*squeeze(fof(agent,:,22))';
end;
NNPlambdagov(:,val) = NNPgov(:,val) - lambda(:,val).*allgov(:,22);
NNPlambdarow(:,val) = NNProw(:,val) - lambda(:,val).*allrow(:,22);
NNPlambdahh(:,val) = NNPhh(:,val) - lambda(:,val).*allhh(:,22);
NNPlambdahhonly(:,val) = NNPhhonly(:,val) - lambda(:,val).*onlyhh(:,22);
NNPlambdafin(:,val) = NNPfin(:,val) - lambda(:,val).*allfin(:,22);
liablambdahh(:,val) = lambda(:,val).*onlyhh(:,22) + liabbus(:,val) - assetsbus(:,val);
liablambdarow(:,val) = lambda(:,val).*allrow(:,22);
 % now fill the differences !!!
  if val>1;
    for agent = 1:agents;
    NNP(val+scenarios,:,agent) = squeeze(NNP(val,:,agent))' - squeeze(NNP(1,:,agent))';
    NNPlambda(val+scenarios,:,agent) = squeeze(NNPlambda(val,:,agent))' - squeeze(NNPlambda(1,:,agent))';
    end;
    NNPhh(:,val+scenarios) = NNPhh(:,val) - NNPhh(:,1);
    NNPhhonly(:,val+scenarios) = NNPhhonly(:,val) - NNPhhonly(:,1);
    NNPbus(:,val+scenarios) = NNPbus(:,val) - NNPbus(:,1);
    NNPhhnobus(:,val+scenarios) = NNPhhnobus(:,val) - NNPhhnobus(:,1);
    NNPgov(:,val+scenarios) = NNPgov(:,val) - NNPgov(:,1);
    NNPfin(:,val+scenarios) = NNPfin(:,val) - NNPfin(:,1);
    NNPcorp(:,val+scenarios) = NNPcorp(:,val) - NNPcorp(:,1);
    NNProw(:,val+scenarios) = NNProw(:,val) - NNProw(:,1);
    NNPlambdahh(:,val+scenarios) = NNPlambdahh(:,val) - NNPlambdahh(:,1);
    NNPlambdahhonly(:,val+scenarios) = NNPlambdahhonly(:,val) - NNPlambdahhonly(:,1);
    NNPlambdagov(:,val+scenarios) = NNPlambdagov(:,val) - NNPlambdagov(:,1);
    NNPlambdarow(:,val+scenarios) = NNPlambdarow(:,val) - NNPlambdarow(:,1);
    NNPlambdafin(:,val+scenarios) = NNPlambdafin(:,val) - NNPlambdafin(:,1);
    liablambdahh(:,val+scenarios) = liablambdahh(:,val) - liablambdahh(:,1);
    liablambdarow(:,val+scenarios) = liablambdarow(:,val) - liablambdarow(:,1);
    assetshhnobus(:,val+scenarios) = assetshhnobus(:,val) - assetshhnobus(:,1);
    assetsbus(:,val+scenarios) = assetsbus(:,val) - assetsbus(:,1);
    assetsrow(:,val+scenarios) = assetsrow(:,val) - assetsrow(:,1);
    assetsgov(:,val+scenarios) = assetsgov(:,val) - assetsgov(:,1);
    assetsfin(:,val+scenarios) = assetsfin(:,val) - assetsfin(:,1);
    assetsnonfin(:,val+scenarios) = assetsnonfin(:,val) - assetsnonfin(:,1);
    liabhhnobus(:,val+scenarios) = liabhhnobus(:,val) - liabhhnobus(:,1);
    liabbus(:,val+scenarios) = liabbus(:,val) - liabbus(:,1);
    liabrow(:,val+scenarios) = liabrow(:,val) - liabrow(:,1);
    liabgov(:,val+scenarios) = liabgov(:,val) - liabgov(:,1);
    liabfin(:,val+scenarios) = liabfin(:,val) - liabfin(:,1);
    liabnonfin(:,val+scenarios) = liabnonfin(:,val) - liabnonfin(:,1);
    
                           %% again interject position by position calc
        for posnow=1:numpos2;
         posNNPcorp(:,val+scenarios,posnow) = squeeze(posNNPcorp(:,val,posnow)) - squeeze(posNNPcorp(:,1,posnow));
         posNNPfin(:,val+scenarios,posnow) = squeeze(posNNPfin(:,val,posnow)) - squeeze(posNNPfin(:,1,posnow));
         posNNPhhonly(:,val+scenarios,posnow) = squeeze(posNNPhhonly(:,val,posnow)) - squeeze(posNNPhhonly(:,1,posnow));
         posNNPhhnobus(:,val+scenarios,posnow) = squeeze(posNNPhhnobus(:,val,posnow)) - squeeze(posNNPhhnobus(:,1,posnow));
         posNNPbus(:,val+scenarios,posnow) = squeeze(posNNPbus(:,val,posnow)) - squeeze(posNNPbus(:,1,posnow));
         posNNPlambdagov(:,val+scenarios,posnow) = squeeze(posNNPlambdagov(:,val,posnow)) - squeeze(posNNPlambdagov(:,1,posnow));
         posNNPgov(:,val+scenarios,posnow) = squeeze(posNNPcorp(:,val,posnow)) - squeeze(posNNPcorp(:,1,posnow));
         posNNPlambdarow(:,val+scenarios,posnow) = squeeze(posNNPlambdarow(:,val,posnow)) - squeeze(posNNPlambdarow(:,1,posnow));
         posNNPlambdahh(:,val+scenarios,posnow) = squeeze(posNNPlambdahh(:,val,posnow)) - squeeze(posNNPlambdahh(:,1,posnow));
   posNNPlambdahhonly(:,val+scenarios,posnow) = squeeze(posNNPlambdahhonly(:,val,posnow)) - squeeze(posNNPlambdahhonly(:,1,posnow));
         posNNPlambdafin(:,val+scenarios,posnow) = squeeze(posNNPlambdafin(:,val,posnow)) - squeeze(posNNPlambdafin(:,1,posnow));
        end;  
  end;

end;

%end;





%% need a lambda for business
lambdabus = zeros(sample,numval);
for val=1:numval;
lambdabus(:,val) = - (squeeze(NNPlambda(val,:,3))' + squeeze(NNPlambda(val,:,4))')...
                                           ./ squeeze(fof(1,:,27))';
                                       
end;



% define nonfinancial and non corporate
NNPnonfin = NNPcorp+NNPbus-NNPfin;
posNNPnonfin = posNNPcorp + posNNPbus - posNNPfin;

NNPnonfinc = NNPcorp - NNPfin;
posNNPnonfinc = posNNPcorp  - posNNPfin;

posNNPbus = posNNPnonfin - posNNPnonfinc;

assetsnonfinc = assetsnonfin - assetsbus;
liabnonfinc = liabnonfin - liabbus;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% prepare factors to convert SCF numbers

%% the asset classes for which we get holdings data from scf are 
%% NOMINAL: bond, mortg(assets), life, 
%% OTHER: equity, bus, mmmf, mutf, othma, retqliq

%% the scf exercise then works with 9 asset classes, the following order:
%% short, gov, muni , corp, mortg (asssets),  life, agency, equity, bus

%% we assign factors from basefactors matrix for these classes.


%% we create the following map between SCF and FFA observables
%  bond = bonds held directly
%  mmmf = mmmf
%  mutf = mutual funds
%  othma = trust
%  retqliq = iras + dcpensions
% for each of these classes, we construct a 1x9 vector that splits up the SCF position


%  load IRA data: this is a supplementary table in FFA 
%  (FFA also adds IRA assets to totals
%  data are annual and begin in 1985
%  order of columns is
%  date / total / at banks/ at savinst / at credit unions / at life ins / at mmmf / at mutf / other  
currentTable = [char(rawDataDirectory) 'ltab225.i.prn']; 
[iradata,iranames] = loadRawFOF(currentTable);
% go to trillions
iradata = iradata/1000;
    
%  we treat the first three columns as time&savings deposits (so short term),
%   treat 'other' and life like dcpensions, and treat rest directly



    
for yearindex = 1:length(pickobs);
    
    yearnow = pickyears(yearindex); 
    obsnow = pickobs(yearindex);       % obs number in ffa array
    obsiranow = pickobsira(yearindex);    % obs number in ira table
    
    
%%%%%%%%%%%%%%%%%%%%%%%% split up money in IRAs
allira = iradata(obsiranow,2); % total money in iras
% share for subclasses held within iras
shortira = sum(iradata(obsiranow,[3:5]))/allira;  % first three ira columns are treated as 'short'
mmmfira = iradata(obsiranow,7)/allira;  
mutfira = iradata(obsiranow,8)/allira;
restira = (iradata(obsiranow,9)+iradata(obsiranow,6))/allira; % other and life ins


%%%%%%%%%%%%%%%%%%%%%% multipliers that split up SCF positions into 9 asset classes

%% directly held long bonds
% recall bondshares gives the weights on direct bondholdings from above  
bondfactor = zeros(1,10);
bondfactor([[2:5] 7]) =  bondshares(yearindex,:);

%% investment intermediaries
helpfactors = zeros(3,10);
invinterm = [14 16 17];
intermnow = zeros(3,cols);
for i=1:3;
    intermhere = invinterm(i);
    intermnow(i,:) = squeeze(fof(intermhere,obsnow,:))';
    intermsharenow = intermnow(i,:)/sum(intermnow(i,iassnoii));
% note: here we are not using inv interm holdings by other inv interm; at this point fof is already consolidated!
    helpfactors(i,[[1:8] 10]) = [sum(intermsharenow([2 3 5 [10:15] 17])) intermsharenow(6:8) (intermsharenow(9)+intermsharenow(16)) ...
                                 (intermsharenow(19)+intermsharenow(20)) intermsharenow(21:22) intermsharenow(25)];
end;             
            
mutffactor = helpfactors(3,:);
mmmffactor = helpfactors(2,:);
trustfactor = helpfactors(3,:);
 % calculate share of ira money in scf item RETQLIQ
irashare = allira / (allira + alldc(obsnow));
penfactor = ((1-irashare) + irashare*restira) * helpfactors(1,:)...
                     + irashare * ([shortira zeros(1,9)]...
                                    + mutfira * mutffactor...
                                    + mmmfira * mmmffactor);
                     


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% factor matrix for broad asset classes used in the SCF exercise
%% this matrix is numval x 9
scfassfactors = zeros(numval,10);
scfassfactors(1:numval-1,[[1:7] 10]) = squeeze(basefactors(:,obsnow,[6 1 2 3 4 3 3 5]));
scfassfactors(numval,:) = ones(1,10); % for par value, just fill ones !!!
scfassfactors(1,8) = 1;  % equity at initial market value  
scfassfactors(1,9) = 1;  % for bus, simply treat initial net worth like outst equity for corp !
for jjj=2:numval-1;
scfassfactors(jjj,8) = 1 + lambda(obsnow,1) - lambda(obsnow,jjj); % equity with revaluation
scfassfactors(jjj,9) = 1 + lambdabus(obsnow,1) - lambdabus(obsnow,jjj); % bus with revaluation
end;
% for calculating netfin position, it is still helpful to carry around the lambdas themselves into scf
lambdanow = lambda(obsnow,:);
lambdabusnow = lambdabus(obsnow,:);


%%%%%%%%%%%%%%%%%% record aggregate household holdings for broad asset classes
hhnobus = squeeze(fof(1,obsnow,:))';  % it is important to NOT have holdings thru business in it
  % (in scf we have actual numbers for bus that differ by person)
holdingsnow = [sum(hhnobus([2 3 5 [10:15] 17])) hhnobus([6:8])...
                  (hhnobus(9) + hhnobus(16)) (sum(hhnobus(18:20)))...
                    hhnobus([21:22]) hhnobus(27) hhnobus(25)];
hhbus = squeeze(fof(3,obsnow,:))' + squeeze(fof(4,obsnow,:))';  
holdingsbusnow = [sum(hhbus([2 3 5 [10:15] 17])) hhbus([6:8])...
                  (hhbus(9) + hhbus(16)) (sum(hhbus(18:20)))...
                    hhbus([21:22]) 0 hhbus(25)];
                   

% aggregates for corp, gov, row 
holdingscorpnow = [sum(allcorp(obsnow,[2 3 5 [10:15] 17])) allcorp(obsnow,[6:8])...
                  (allcorp(obsnow,9) + allcorp(obsnow,16)) (sum(allcorp(obsnow,18:20)))...
                    allcorp(obsnow,[21:22]) 0 allcorp(obsnow,25)];
debtcorpnow = [sum(allcorp(obsnow,26+[2 3 5 [10:15] 17])) allcorp(obsnow,26+[6:8])...
                  (allcorp(obsnow,26+9) + allcorp(obsnow,26+16)) (sum(allcorp(obsnow,26+[18:20])))...
                    allcorp(obsnow,26+[21:22]) 0 allcorp(obsnow,26+25)];
            
holdingsrownow = [sum(allrow(obsnow,[2 3 5 [10:15] 17])) allrow(obsnow,[6:8])...
                  (allrow(obsnow,9) + allrow(obsnow,16)) (sum(allrow(obsnow,18:20)))...
                    allrow(obsnow,[21:22]) 0 allrow(obsnow,25)];
debtrownow =  [sum(allrow(obsnow,26+[2 3 5 [10:15] 17])) allrow(obsnow,26+[6:8])...
                  (allrow(obsnow,26+9) + allrow(obsnow,26+16)) (sum(allrow(obsnow,26+[18:20])))...
                    allrow(obsnow,26+[21:22]) 0 allrow(obsnow,26+25)];


holdingsgovnow = [sum(allgov(obsnow,[2 3 5 [10:15] 17])) allgov(obsnow,[6:8])...
                  (allgov(obsnow,9) + allgov(obsnow,16)) (sum(allgov(obsnow,18:20)))...
                    allgov(obsnow,[21:22]) 0 allgov(obsnow,25)];
debtgovnow = [sum(allgov(obsnow,26+[2 3 5 [10:15] 17])) allgov(obsnow,26+[6:8])...
                  (allgov(obsnow,26+9) + allgov(obsnow,26+16)) (sum(allgov(obsnow,26+[18:20])))...
                    allgov(obsnow,26+[21:22]) 0 allgov(obsnow,26+25)];

holdingsallhhnow = [sum(allhh(obsnow,[2 3 5 [10:15] 17])) allhh(obsnow,[6:8])...
                  (allhh(obsnow,9) + allhh(obsnow,16)) (sum(allhh(obsnow,18:20)))...
                    allhh(obsnow,[21:22]) 0 allhh(obsnow,25)];
            
% corrections for hh debt: leave out mortgages, neg muni           
debtallhhnow = [allhh(obsnow,35)+allhh(obsnow,42) ...
                 (sum(allhh(obsnow,ilia))-allhh(obsnow,35) -allhh(obsnow,42)- allhh(obsnow,53)-allhh(obsnow,33))];
% remove hh neg muni holdings also from asset side
holdingsallhhnow(3) = holdingsallhhnow(3) - allhh(obsnow,33); 
% repeat corrections for other household aggregates
debtnow = [hhnobus(35)+hhnobus(42)  (sum(hhnobus(ilia))-hhnobus(35) -hhnobus(42)- hhnobus(53) - hhnobus(33))];
holdingsnow(3) = holdingsnow(3) - hhnobus(33); 
debtbusnow = [hhbus(35)+hhbus(42)  (sum(hhbus(ilia))-hhbus(35) - hhbus(42)- hhbus(53))];

          
% nonprofits
holdingsnonprnow = holdingsallhhnow - holdingsnow - holdingsbusnow;
debtnonprnow = debtallhhnow - debtnow - debtbusnow;
holdingsnonprnow(9)=0; % drop private equity

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% mortgage factor matrix
mortgfactorsnow = squeeze(mortgfactors(yearindex,:,:));

ngdp = gdp(obsnow-4);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% summary tables for positions and revaluation

%% NNPs

disp([ num2str(yearnow) ' aggregate numbers ALL RELATIVE TO NOMINBAL GDP']);
disp('COLUMNS are current MV / inst. infl / grad infl / par / redist(inst) / redist(grad) / shit');
disp('NNP');
disp('ROWS are households only / w. nonprofits / govmt / row / corp / fin');
NNPnow=[NNPhhonly(obsnow,:);NNPhh(obsnow,:);NNPgov(obsnow,:);squeeze(NNP(:,obsnow,6))';NNPcorp(obsnow,:); NNPfin(obsnow,:)];
disp(NNPnow/ngdp);
disp('NNPlambda');
disp('ROWS are households only / w. nonprofits / govmt / row ');
NNPlambdanow = [NNPlambdahhonly(obsnow,:);NNPlambdahh(obsnow,:);NNPlambdagov(obsnow,:);NNPlambdarow(obsnow,:)];
disp(NNPlambdanow/ngdp);


disp('***************************');
disp(['Revaluation Factors, '  num2str(yearnow)]);
disp('ROWS are securities: short / treas / muni / corp / mortg / life ins / agency / short gov')
disp([scfassfactors(:,[[1:7] 10])'  (scfassfactors(2:4,[[1:7] 10])' - scfassfactors(1,[[1:7] 10])'*ones(1,3))]...
       ./ [ones(8,1) scfassfactors(1,[[1:7] 10])'*ones(1,6)]);
disp('ROWS are equity, private bus')
disp([scfassfactors(:,8:9)'  (scfassfactors(2:4,8:9)' - scfassfactors(1,8:9)'*ones(1,3))]...
       ./  [ones(2,1) scfassfactors(1,8:9)'*ones(1,6)]);
disp('ROWS are bundles: all bonds / MMMfunds / MutFunds / PenFunds/ Trust')
stuff = [bondfactor;mmmffactor;mutffactor;penfactor;trustfactor]*scfassfactors';
disp([stuff(:,1) [stuff(:,2:4) stuff(:,2:4)-stuff(:,1)*ones(1,3)]./(stuff(:,1)*ones(1,6))]);

disp('***************************');
disp(['Duration, '  num2str(yearnow)]);
disp('COLS are securities: short / treas / muni / corp / mortg / life ins / agency / shortgov')
disp(abs(scfassfactors(3,[[1:7] 10]) - scfassfactors(1,[[1:7] 10])) ./ ((addrate)*scfassfactors(1,[[1:7] 10])));
disp('COLS are equity, private bus')
disp(abs(scfassfactors(3,8:9) - scfassfactors(1,8:9)) ./  ((addrate)*scfassfactors(1,8:9)));
disp('COLS are bundles: all bonds / MMMfunds / MutFunds / PenFunds/ Trust')
stuff = [bondfactor;mmmffactor;mutffactor;penfactor;trustfactor]*scfassfactors';
disp(abs(stuff(:,3)-stuff(:,1))'./((addrate)*stuff(:,1)'));


%% holdings by position 

disp('=======================================================');
disp(['holdings by position, ' num2str(yearnow)]);
disp('=======================================================');
disp('outstanding gov-related debt');
disp('(cols are treas muni agency shortgov total; rows are gov corp total)');
xx=[debtgovnow([2 3 7 10]), sum(debtgovnow([2 3 7 10]));...
    debtcorpnow([2 3 7 10]), sum(debtcorpnow([2 3 7 10]))];
disp([xx;sum(xx)]);

disp('holdings (treas muni agency shortgov total)'); 
disp('(rows are gov hhnobus, hhbus, row, corp, nonprof, total'); 
xx=[holdingsgovnow([2 3 7 10]), sum(holdingsgovnow([2 3 7 10]));...
    holdingsnow([2 3 7 10]),sum(holdingsnow([2 3 7 10]));...
        holdingsbusnow([2 3 7 10]),sum(holdingsbusnow([2 3 7 10]));...
        holdingsrownow([2 3 7 10]),sum(holdingsrownow([2 3 7 10]));...
        holdingscorpnow([2 3 7 10]),sum(holdingscorpnow([2 3 7 10]));...
        holdingsnonprnow([2 3 7 10]), sum(holdingsnonprnow([2 3 7 10]))];
disp([xx;sum(xx)]);
disp('=======================================================');
disp('other debt');
disp('total outstanding (short corp mortg life) where rows are corp, gov, row, bus, hh, total')
xx=[debtcorpnow([1 4 5 6]),sum(debtcorpnow([1 4 5 6]));...
        debtgovnow([1 4 5 6]),sum(debtgovnow([1 4 5 6]));...
        debtrownow([1 4 5 6]),sum(debtrownow([1 4 5 6]));...
        debtbusnow(2) 0 debtbusnow(1) 0 debtbusnow(1)+debtbusnow(2);...
        debtnow(2) 0 debtnow(1) 0 debtnow(1)+debtnow(2)];
disp([xx;sum(xx)]);

disp('holdings (short corp mortg life) where rows are hhnobus, corp, gov, row, bus, nonprof, total') 
xx=[holdingsnow([1 4 5 6]),sum(holdingsnow([1 4 5 6]));...
        holdingscorpnow([1 4 5 6]),sum(holdingscorpnow([1 4 5 6]));...
        holdingsgovnow([1 4 5 6]),sum(holdingsgovnow([1 4 5 6]));...
        holdingsrownow([1 4 5 6]),sum(holdingsrownow([1 4 5 6]));...
        holdingsbusnow([1 4 5 6]),sum(holdingsbusnow([1 4 5 6]));...
    holdingsnonprnow([1 4 5 6]), sum(holdingsnonprnow([1 4 5 6]))];
disp([xx;sum(xx)]);
disp('=======================================================');


disp('equity');
disp('outstanding nonforeign corporate');
disp(outequity(obsnow));
disp('holdings, where cols are hhnobus, hhbus, row, gov, nonpr, total'); 
xx=[holdingsnow(8);...
        holdingsbusnow(8);...
        holdingsrownow(8);...
        holdingsgovnow(8);...
    holdingsnonprnow(8)];
disp([xx',sum(xx)]);
disp('outstanding noncorporate');
disp(squeeze(fof(1,obsnow,27)));


%% save result for use in scf exercise
filename = ['factors' num2str(yearnow)];
save(filename);



end; % endloop over picked years    

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$




%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%%%    FIGURES FOR THE PAPER



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 1: NNPs
figure;
hold on;
%plot([1952.25:.25:endyr+1],100*NNPfin(:,1)./gdp,'g','LineWidth',3); 
%plot([1952.25:.25:endyr+1],100*NNPnonfin(:,1)./gdp,'g--','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*NNPhhnobus(:,1)./gdp,'g','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*NNPbus(:,val)./gdp,'g-.','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*NNPfin(:,1)./gdp,'g:','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNPlambdahhonly(:,1)./gdp,'b','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPhhnobus(:,1)./gdp,'g','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPlambdarow(:,1)./gdp,'b--','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNProw(:,1)./gdp,'g--','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPlambdagov(:,1)./gdp,'b:','LineWidth',3);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
legend('Households','Households direct','Rest of the World','Rest of the World direct','Government');
axis ([1952.25 endyr+1 -60 65]);
%title('Positions, %GDP');
hold off;

if printflag==1;
pause;
print -depsc2 figure1.eps
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 2 (4 way positions plot) (indexing asap version is not saved)

%%%%%%%%%%%%%%%% note on matlab plot dimension
% determine by letting h=subplot(2,2,1) -> now h is the subplot handle, then get(h,'Properties')
% coordintaes order is bottom left x , bottom left y, width, height
% coordinates of the subplot are in 0,1 square of (relative) coordinates for the figure
% matlab default for 2x2 panes is: size of subplots .3270, .3439
% top left plot at    0.1300 0.5811 , top right at 0.5780  0.5811 
% bottom left plot at   0.1300 0.1100 , bottom right at .5780, .1100


%% we want to define the ysize of the top row of subplots so that overall scale of the figure is preserved
  % these are axes scales for positions and two redist figures
axe = [-65,80;-18,13];
axetop = [-60,65;-12,12]; 
topratio = (axetop(:,2) - axetop(:,1))'./(axe(:,2) - axe(:,1))';


%define new arrangement: define margins and space between figures in x and y dimensions
xmargin = .05; ymargin = .05; xspace = .05; yspace = .14; 

for jj=1:2;
xsize = (1-2*xmargin-xspace)/2;
ysize(jj) = (1-2*ymargin-yspace)/(1+topratio(jj));
ysizetop(jj) = topratio(jj)*ysize(jj);
% subplot control coordinate vectors: use set command or subplot command directly to assign these properties!
subplotcoord =zeros(4,4);
subplotcoord(1,:) = [xmargin ymargin+ysize(jj)+yspace xsize ysizetop(jj)];
subplotcoord(2,:) = [xmargin+xsize+xspace ymargin+ysize(jj)+yspace xsize ysizetop(jj)];
subplotcoord(3,:) = [xmargin ymargin xsize ysize(jj)];
subplotcoord(4,:) = [xmargin+xsize+xspace ymargin xsize ysize(jj)];
coord{jj} = subplotcoord;
end;


%%%%%%%% positions plots

titles = {'2b. Short Instruments & Loans', '2c. Bonds', '2d. Mortgages'};
titles2 = {'POSITIONS', 'INDEXING ASAP'};
%filenames = {'netpositions','fullsurprise','indexing'};
vals = [1 6];
for jj=1:2;
val= vals(jj);   
figure;
title(titles2{jj});
%subplot(2,2,1);
subplotcoord = coord{jj};
subplot('Position',subplotcoord(1,:));
hold on;
%plot([1952.25:.25:endyr+1],100*NNPfin(:,1)./gdp,'g','LineWidth',3); 
%plot([1952.25:.25:endyr+1],100*NNPnonfin(:,val)./gdp,'g:','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNPhhnobus(:,val)./gdp,'g','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*NNPbus(:,val)./gdp,'g-.','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNProw(:,val)./gdp,'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNPlambdahhonly(:,val)./gdp,'b','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNPlambdarow(:,val)./gdp,'b--','LineWidth',2);
plot([1952.25:.25:endyr+1],100*NNPlambdagov(:,val)./gdp,'b:','LineWidth',2);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
legend('Household DNP','Rest of the World DNP');
axis ([1952.25 endyr+1 axetop(jj,1) axetop(jj,2)]);
title('2a. All Positions');
hold off;

for j=1:3;
%subplot(2,2,j+1);
subplot('Position',subplotcoord(j+1,:))

hold on;
%plot([1952.25:.25:endyr+1],100*NNPfin(:,1)./gdp,'g','LineWidth',3); 
plot([1952.25:.25:endyr+1],100*squeeze(posNNPlambdahhonly(:,val,j))./gdp,'b','LineWidth',2);
plot([1952.25:.25:endyr+1],100*squeeze(posNNPlambdarow(:,val,j))./gdp,'b--','LineWidth',2);
plot([1952.25:.25:endyr+1],100*squeeze(posNNPlambdagov(:,val,j))./gdp,'b:','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*squeeze(posNNPnonfin(:,val,j))./gdp,'g:','LineWidth',2);
plot([1952.25:.25:endyr+1],100*squeeze(posNNPhhnobus(:,val,j))./gdp,'g','LineWidth',2);
%plot([1952.25:.25:endyr+1],100*squeeze(posNNPbus(:,val,j))./gdp,'g-.','LineWidth',2);
plot([1952.25:.25:endyr+1],100*squeeze(posNNProw(:,val,j))./gdp,'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
%legend('Nonfin Corp','Hh. NNP(0)','NonCorp','Financial','Househ. NNP(\lambda)','R.O.W.','Government');
axis ([1952.25 endyr+1 axe(jj,1) axe(jj,2)]);
if j==1;
    legend('Households','Rest of the World','Government');
    axis ([1952.25 endyr+1 axetop(jj,1) axetop(jj,2)]);  
end;
title(titles{j});
hold off;

end;

if jj==1;
if printflag==1;
pause;
print -depsc2 figure2.eps;
end;
end;

end;









if addrate<.001;
%%%%%%%%%%%%%%%%%%%%%%% duration plots, sensible only for very small inflation rate!!!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% duration for NNPs, not saved
figure;
hold on;
%plot([1952.25:.25:endyr+1],*NNPfin(:,4)./gdp,'g','LineWidth',3); 
%plot([1952.25:.25:endyr+1],1e13*abs(1-NNPcorp(:,3)./NNPcorp(:,1)),'g--','LineWidth',3);
plot([1952.25:.25:endyr+1],abs(squeeze(NNP(6,:,1))'./(addrate*squeeze(NNP(1,:,1))')),'g:','LineWidth',3);
plot([1952.25:.25:endyr+1],abs(NNPhhonly(:,6)./(addrate*NNPhhonly(:,1))),'g','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(NNProw(:,6)./(addrate*NNProw(:,1))),'b--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(NNPgov(:,6)./(addrate*NNPgov(:,1))),'b:','LineWidth',2);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
legend('Corporate','Househ. DNP','Househ. NNP','R.O.W.','Government');
%axis ([1952.25 2002.5 0 10]);
title('Duration');
hold off;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 3 (duration by sector)

axetop = [1.9,6.5];
axe = [.9,5]; 
topratio = (axetop(:,2) - axetop(:,1))'./(axe(:,2) - axe(:,1))';

%define new arrangement: define margins and space between figures in x and y dimensions
xmargin = .05; ymargin = .05; xspace = .05; yspace = .14; 

jj=1;
xsize = (1-2*xmargin-xspace)/2;
ysize(jj) = (1-2*ymargin-yspace)/(1+topratio(jj));
ysizetop(jj) = topratio(jj)*ysize(jj);
% subplot control coordinate vectors: use set command or subplot command directly to assign these properties!
subplotcoord =zeros(4,4);
subplotcoord(1,:) = [xmargin ymargin+ysize(jj)+yspace xsize ysizetop(jj)];
subplotcoord(2,:) = [xmargin+xsize+xspace ymargin+ysize(jj)+yspace xsize ysizetop(jj)];
subplotcoord(3,:) = [xmargin ymargin xsize ysize(jj)];
subplotcoord(4,:) = [xmargin+xsize+xspace ymargin xsize ysize(jj)];


figure;

subplot('Position',subplotcoord(1,:));
hold on;
plot([1952.25:.25:endyr+1],abs(assetshhnobus(:,6)./(addrate*assetshhnobus(:,1))),'g','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(liabhhnobus(:,6)./(addrate*liabhhnobus(:,1))),'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs((assetshhnobus(:,6)-liablambdahh(:,6))...
                       ./(addrate*(assetshhnobus(:,1)-liablambdahh(:,1)))),'b','LineWidth',2);
legend('Assets Direct','Liabilities Direct','Assets + Net Indirect');
%axis ([1952.25 2002.5 0 200]);
set(gca,'Ytick',[2 3 4 5 6]);
axis ([1952.25 endyr+1 axetop(1,1) axetop(1,2)]);
title('3a. Households');
hold off;

subplot('Position',subplotcoord(3,:));
hold on;
plot([1952.25:.25:endyr+1],abs(assetsfin(:,6)./(addrate*assetsfin(:,1))),'k','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(liabfin(:,6)./(addrate*liabfin(:,1))),'k--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(assetsfin(:,6)./(addrate*assetsfin(:,1))),'g','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(liabfin(:,6)./(addrate*liabfin(:,1))),'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs((assetsfin(:,6)+assetsnonfin(:,6))...
             ./(addrate*(assetsfin(:,1)+assetsnonfin(:,1)))),'b-','LineWidth',2);
plot([1952.25:.25:endyr+1],abs((liabfin(:,6)+liabnonfin(:,6))...
             ./(addrate*(liabfin(:,1)+liabnonfin(:,1)))),'b--','LineWidth',2);
legend('Assets','Liabilities',4);
axis ([1952.25 endyr+1 axe(1,1) axe(1,2)]);
title('3c. All Business (black) & Financial System (grey)');
hold off;

subplot('Position',subplotcoord(2,:));
hold on;
plot([1952.25:.25:endyr+1],abs(liabgov(:,6)./(addrate*liabgov(:,1))),'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(NNPlambdagov(:,6)./(addrate*NNPlambdagov(:,1))),'b--','LineWidth',2);
legend('Debt','NNP');
axis ([1952.25 endyr+1 axetop(1,1) axetop(1,2)]);
set(gca,'Ytick',[2 3 4 5 6]);
title('3b. Government');
hold off;

subplot('Position',subplotcoord(4,:));
hold on;
plot([1952.25:.25:endyr+1],abs(assetsrow(:,6)./(addrate*assetsrow(:,1))),'g','LineWidth',2);
plot([1952.25:.25:endyr+1],abs(liabrow(:,6)./(addrate*liabrow(:,1))),'g--','LineWidth',2);
plot([1952.25:.25:endyr+1],abs((assetsrow(:,6)-liablambdarow(:,6))...
          ./(addrate*(assetsrow(:,1)+liablambdarow(:,1)))),'b-','LineWidth',2);
legend('Assets Direct','Liabilities Direct','Assets + Net Indirect');
%axis ([1952.25 2002.5 0 6]);
axis ([1952.25 endyr+1 axe(1,1) axe(1,2)]);
title('3d. Rest of the World');
hold off;

if printflag==1;
pause;
print -depsc2 figure5.eps;
end;

else;     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% if addrate has normal size, proceed to do redistribution pictures
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 6 (churn)
figure;
subplot(2,1,1);
hold on;
plot([1952.25:.25:endyr+1],-100*assetshhnobus(:,5)./gdp,'g-','LineWidth',2); 
plot([1952.25:.25:endyr+1],-100*liabhhnobus(:,5)./gdp,'b-','LineWidth',2);
plot([1952.25:.25:endyr+1],-100*(liabhhnobus(:,5)-assetsbus(:,5)+liabbus(:,5))./gdp+100*(lambda(:,1)-lambda(:,2)).*onlyhh(:,22)...
    ./gdp,'b-.','LineWidth',2);
title('6a. Full Surprise Scenario');
axis tight;
legend('Direct Losses','Direct Gains','Gains + Net Indirect Gain',4);
grid on;

subplot(2,1,2);
hold on;
plot([1952.25:.25:endyr+1],-100*assetshhnobus(:,6)./gdp,'g-','LineWidth',2);
plot([1952.25:.25:endyr+1],-100*liabhhnobus(:,6)./gdp,'b-','LineWidth',2);
plot([1952.25:.25:endyr+1],-100*(liabhhnobus(:,6)+liabbus(:,6)-assetsbus(:,6))./gdp+100*(lambda(:,1)-lambda(:,3)).*onlyhh(:,22)...
    ./gdp,'b-.','LineWidth',2);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
axis tight;
hold off;
title('6b. Indexing ASAP Scenario');
legend('Direct Losses','Direct Gains','Gains + Net Indirect Gain',4);
grid on;
if printflag==1;
pause;
print -depsc2 figure4.eps;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% figure 3 (indexing ASAP)
figure;
hold on;
%plot([1952.25:.25:endyr+1],100*NNPfin(:,6)./gdp,'g','LineWidth',3); 
%plot([1952.25:.25:endyr+1],100*NNPcorp(:,6)./gdp,'g--','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPlambdahhonly(:,6)./gdp,'b','LineWidth',3);
plot([1952.25:.25:endyr+1],squeeze(100*NNP(6,:,1))'./gdp,'g-','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPlambdarow(:,6)./gdp,'b--','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNProw(:,val)./gdp,'g--','LineWidth',3);
plot([1952.25:.25:endyr+1],100*NNPlambdagov(:,6)./gdp,'b:','LineWidth',3);
plot([1952.25:.25:endyr+1],zeros((endyr-1951)*4,1),'k','LineWidth',1);
legend('Households','Households direct','Rest of the World','Rest of the World direct','Government');
axis tight;
hold off;
% title('INDEXING ASAP')
if printflag==1;
pause;
print -depsc2 figure3.eps;
end;


end; % end condition on addrate





