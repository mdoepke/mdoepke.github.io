function seriesName = getSeriesName(fullInstrumentName);
% Function: getSeriesName.m
% Purpose:  Pulls the FOF 6-digit series name from a full series name
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Sept 28, 2005
% Input:    fullInstrumentName - String containing full FOF instrument name, 
%                                e.g. "FL935050003"
% Output:   seriesName - 6-digit series name, e.g. 505000; this corresponds 
%                        to one particular FOF series, such as "commercial 
%                        mortgages." It is returned as a number.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isequal(fullInstrumentName(1,1),'"') %if name surrounded by quotes
    seriesName = str2num(fullInstrumentName(1,6:size(fullInstrumentName,2)-4));
else %no quotes
    seriesName = str2num(fullInstrumentName(1,5:size(fullInstrumentName,2)-3))
end