function [instrumentNumbers,instrumentCodes] = loadInstrumentInfo(instrumentInfoFile);
% Function: loadInstrumentInfo.m
% Purpose:  Loads file with FOF codes for each instrument 
% By:       Matthias Doepke, Martin Schneider, David Lagakos
% Date:     Sept 28, 2005
% Input:    instrumentInfoFile - the name of the file in which the
%                                instrument codes are stored
% Output:   instrumentNumbers - a column consisting of the numbers of our
%                               instruments.
%           instrumentCodes - a matrix consisting of codes (cols) for each
%                             instrument (rows)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize variables
instrumentNumbers = [];
instrumentCodes = [];

% load the file for reading
fid = fopen(instrumentInfoFile,'r');
if isequal(fid,-1) %halt if file input error
    error('Text file cannot be input properly')
end

% read the first line, determine the max # of codes
line1 = fgetl(fid);
line1 = sscanf(line1,'%c');
line1 = strread(line1,'%s')';
maxNumberCodes = size(line1,2)-1;

% read the subsequent lines, which are the instruments and codes
while 1 %while files open
    newLine = fgetl(fid); %input one line from the names file
    if ~isstr(newLine) 
        %%% end of the file has been reached %%% 
        break
    elseif isequal(newLine,'')
        %%% blank line reached %%%
        break
    else 
        %%% end of file not yet reached %%%
        %turn line into cell array
        newLine = sscanf(newLine,'%c');
        newLine = strread(newLine,'%s')'; 
        
        % record the instrument number
        instrumentNumbers = [instrumentNumbers; str2num(char(newLine(1,1)))];
        
        % record the codes
        instrumentCodesRow = zeros(1,maxNumberCodes); %initialize row of codes
        for iCode=2:maxNumberCodes+1
            instrumentCodesRow(1,iCode-1) = str2num(char(newLine(1,iCode)));
        end
        instrumentCodes = [instrumentCodes; instrumentCodesRow];
    end %case when file not done
end % end of file
        
% close the file
fclose(fid);