clear all;

% this code loads SCF data and reconciles SCF, FFA
% all dollar amounts are in 000s !


% the additional files needed are:
%        SCFTabling1989.txt
%        earnings89nohead.txt
%        addition89.txt
%        assdet.xls
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCF PUBLIC EXTRACT
% load SCF public extract, but the column NORMINC has been deleted
SCF = load('SCFTabling1989.txt');


% eliminate two observations that had funny earnings numbers
SCF = [SCF(1:3330,:); SCF(3336:10330,:); SCF(10336:end,:)];

all=size(SCF,1);
cols=size(SCF,2);

% names for important variables 
age = SCF(:,1); 

married = SCF(:,44);
kids = SCF(:,29);

real = SCF(:,[48 49 14])/1000;  % networth, nonfin, debt 
income = SCF(:,26)/1000;
identities = SCF(:,cols-1:cols);
weight = SCF(:,cols-2);
equity = SCF(:,18)/1000;
bus = SCF(:,6)/1000;
clear SCF;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DETAILS ABOUT MORTGAGES
% load more detailed information about mortgages that is not contained in public extract
%% the file housescf is an extract from raw scf constructed in stata 
%% see stata file checkscf for order of question codes from raw scf
%% it's alphabetically sorted, so do 'describe' in stata to get order of variables
load housescf;
hscf = [data(1:3330,:); data(3336:10330,:); data(10336:end,:)];

havemort = (hscf(:,3)==1); % have mortgage (1/0)
mortyear = hscf(:,4); % year mortgage was issued or last refinanced
maturity = hscf(:,7); % maturity in years
interestnow = hscf(:,11); % interest rate in %
adjrate = (hscf(:,12)==1); % adj rate (1/0) 
interestorig = hscf(:,19); % interest when mortgage first taken out
adjoneyear = (hscf(:,15)==6); % adjustable after one year (1/0)
change = hscf(:,17); 
owed = hscf(:,5);
% fraction of mortgage owners



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DETAILS ABOUT EARNINGS
%% the file earnings89nohead was constructed in excel as follows:
%% (i) start from scf_data1.txt 
%% (ii)rearrange x4100 and x4700 
%% (iii)merge with scf_data2 
%% (iv) eliminate two problematic observations

SCF = load('earnings89nohead.txt');
% this file has earnings related data from 1989 scf
% columns are x1 weight asalh asals abush abuss hoursh hourss
% (these from work questions - salary and bus earnings for head, spouse)
% laby busy finy tray othy  empl.code(h) empl.code(s)

% state the dollar numbers in 000s
SCF(:,3:6) = SCF(:,3:6)/1000;
SCF(:,9:13) = SCF(:,9:13)/1000;


% assign names to earnings related variables
asalh = SCF(:,3);
asals = SCF(:,4);
abush = SCF(:,5);
abuss = SCF(:,6);
laby = SCF(:,9);
busy = SCF(:,10);
ahoursh = SCF(:,7);
ahourss = SCF(:,8);
statush = SCF(:,14);
statuss = SCF(:,15);
earnings1 = asalh + asals;
earnings2 = laby+busy;


clear SCF;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BUS INCOME AND PENSION DATA 
SCF = load('addition89.txt');
% this data set contains id, busincome, busincome2(rent etc.), reteq, retqliq

SCF(:,2:5) = SCF(:,2:5)/1000;
id2=SCF(:,1);
retacc = SCF(:,5);
nomretacc = retacc - SCF(:,4);
busy1 = SCF(:,2);
busy2 = SCF(:,3);
clear SCF;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LOAD DETAILS OF ASSET HOLDINGS
finstuff = xlsread('assdet.xls');
finstuff = [finstuff(1:3330,:); finstuff(3336:10330,:); finstuff(10336:end,:)];
finstuff = finstuff/1000;

%%% for the scf exercise, we work with the following categories:
%% short, govmt,  muni, corp, mortg (ass), agency, lifeins., equity, bus /  mortgages, otherdebt



%%%%%%%%%%%%%%%%%%%%%%%%  reconciliation: description

%% as input for the reconciliation, fofcalc produces debtcorp, debtgov, debtrow
%% as well as holdingscorp and so on
%% all holdings vectors have the same format, and so do the debt vectors,
%%   except those for the households (various versions), which only have mortgages, other debt!
%% the general format is:
%% short, govmt,  muni, corp, mortg (ass), agency, lifeins., equity, bus, shortgov 


%% what is total business NNP ? 
%% we say short (except Treasury), corp, lifeins are clearly bus debt 
%%   
%% what is mortg (ass) ? ignore for hh, it is small
%%     also govmt has no identifiable commercial mortg, it seems all resid.
%% govmt, muni, agency, shortgov(treas) are clearly govmt debt
% for mortg, split it from Fof, ratio is about .5
%% we have hh posoitions from fof, and their replacement
%% what's with bus debt/holdings not to hh?  leave as is!!




%%% this code will pass on a matrix assdetails (all x 10), that will have investment 
%% intermediaries netted out using our own fof shares, not the ones of the scf itself
%%
%% it will also pass on the matrix scfassfactors, created by fofcalc, that provides 
%% 4 x 9 matrix of factors for the 8 asset classes
%% note that on asset side mortgages get the `generic' factor !!
%% also life insurance policies get treated like agency securities


bonds = finstuff(:,1) + finstuff(:,15);  % bonds: aggregate and savings bonds
life = finstuff(:,2);
short = finstuff(:,4) + finstuff(:,6) - finstuff(:,7); % subtract mma as a proxy for mmmf
mmmf = finstuff(:,7);
mutf = finstuff(:,9);
trust = finstuff(:,11);
pen = finstuff(:,14);  % this is dc pensions plus iras
stocks = finstuff(:,16);
mortg = finstuff(:,8) + finstuff(:,12);
othfin = finstuff(:,10);
othdebt = real(:,3) - mortg;

%% the factors matrix contains
%% (i) factors for investment intermediaries and the bond aggregate of the SCF
%% this gives holdings of the 6 core assets per dollar of face (bonds, short) and market 
%% (inv interm holdings) value on the SCF
%% so format for these factors is 1 x 9
%%
%% 
load factors1989;


assdetails = zeros(all,10);
assdetails(:,1) = short;
assdetails(:,6) = life;
assdetails(:,8) = stocks;
assdetails(:,9) = bus;
assdetails = assdetails + bonds * bondfactor; 
assdetails = assdetails + mmmf * mmmffactor; 
assdetails = assdetails + mutf * mutffactor; 
assdetails = assdetails + trust * trustfactor; 
assdetails = assdetails + pen * penfactor; 



%% calculate aggregates (trillions)
assagg = sum(assdetails.* (weight*ones(1,10)))/1e9;
debtagg = sum([mortg othdebt].* (weight*ones(1,2)))/1e9;
othfinagg = sum(othfin.* weight)/1e9;



aggmmmfscf = sum(mmmf.*weight)/1e9;
aggmutfscf = sum(mutf.*weight)/1e9;
aggtrustscf = sum(trust.*weight)/1e9;
aggpenscf = sum(pen.*weight)/1e9;
aggbondsscf = sum(bonds.*weight)/1e9;




aggmmmf = sum(intermnow(2,iassnoii));
aggmutf = sum(intermnow(3,iassnoii));
aggpen = sum(intermnow(1,iassnoii));
aggbonds = sum(bondqs(1,:));

disp('discrepancies in invm intermeidary accounts');
disp('MMMF (ffa, scf)');
disp([aggmmmf aggmmmfscf]);
disp('mutf (ffa, scf)');
disp([aggmutf aggmutfscf]);
disp('pension (ffa, scf)');
disp([aggpen aggpenscf]);
disp('long bonds (ffa, scf)');
disp([aggbonds aggbondsscf]);

disp('trusts in scf');
disp(aggtrustscf);


disp('how this plays out for individual assets');
disp('ffa holdings: mmmf, mutf, pen, bond, sum');
x=[aggmmmf*mmmffactor;aggmutf*mutffactor;aggpen*penfactor;aggbonds*bondfactor];
disp([x;sum(x)]);
disp('all holdings, ffa'); 
disp([holdingsnow]);

disp('scf holdings: mmmf, mutf, pen, bond, trusts, sum');
x=[aggmmmfscf*mmmffactor;aggmutfscf*mutffactor;aggpenscf*penfactor;aggbondsscf*bondfactor];
disp([x;sum(x)]);
disp('adding scf trust holdings:');
x=[x;aggtrustscf*trustfactor];
disp([aggtrustscf*trustfactor;sum(x)]);

disp('all holdings, scf'); 
disp([ assagg]);


disp('debt (mortg, other) ffa, scf');
disp([debtnow;debtagg]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DEFINE AGE-SPECIFIC MORTGAGE FACTORS

%% the matrix mortgfactorsnow was prepared by factors code

%% age for purposes of determining market value of outstanding mortgage payments
%%  needs to be converted to index in mortgfactors matrix
%% we assume that mortgage is new if <45, and has 2 years left if >65
mortgageage = (age-44) .* (age>44 & age<67) + (age<45)*1 + (age>66)*22;

%% set up vector of mortgage values, to compute mortgage market value, taking age into account
mortgmv = zeros(all,numval);
for val=1:numval;
mortgmv(:,val) = mortg .* mortgfactorsnow(val,mortgageage)';
end;
commortgfactor = scfassfactors(:,5);
scfassfactors(:,5) = (sum((weight*ones(1,numval)).*mortgmv) ./ sum(weight.*mortg*ones(1,numval)))';




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% REDEFINE SECTORAL NOMINAL HOLDINGS TO MATCH SCF HH AGGREGATES
%% CORPORATE SECTOR
holdingscorpscf = holdingscorpnow;
debtcorpscf = debtcorpnow;
%%%% on the holdings side:
%% replace cons loans - assume all short borrowing of hh is from corp!
holdingscorpscf(1) = holdingscorpnow(1) - debtnow(2) + debtagg(2); % consumer loans are replaced


%% replace mortgages - here allow for some granted by govmt 
nethhmort = debtnow(1)-holdingsnow(5);
govmortshare = holdingsgovnow(5)/nethhmort;
corpmortshare = 1 - govmortshare;
nonresidmort = holdingscorpnow(5) - corpmortshare * nethhmort;
holdingscorpscf(5) = corpmortshare * (debtagg(1)-assagg(5)) +  nonresidmort;
%%%% on the debt side:
%% replace short, corp.bond, life ins.
debtcorpscf([1 4 6]) = debtcorpnow([1 4 6]) - holdingsnow([1 4 6]) + assagg([1 4 6]);

%% GOVERNMENT
%% note: must include self-holdings!
holdingsgovscf = holdingsgovnow;
holdingsgovscf(5) = govmortshare*(debtagg(1)-assagg(5)); % mortgages
debtgovscf = debtgovnow;
% treas, muni, agency, shortgov
debtgovscf([2 3 7 10]) =  debtgovnow([2 3 7 10]) - holdingsnow([2 3 7 10]) + assagg([2 3 7 10]); 

%% note: we are assuming that the row does not deal directly with the hh, except perhaps thru equity

%% reset household holdings
holdingsscf = assagg;  
debtscf = debtagg;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% RESET EQUITY POSITIONS AND LAMBDAS

%% nominal position of households thru corp equity holdings (ffa)
NNPhhcorpnow = - lambdanow(1:numval) * holdingsnow(8); 

%% nominal position of households thru noncorp equity holdings (ffa)
NNPpribusnowfof =  (scfassfactors(:,[[1:7] 10]) * holdingsbusnow([[1:7] 10])' - scfassfactors(:,[5 1]) * debtbusnow')'; 


lambdafof =  - (NNPpribusnowfof + NNPhhcorpnow) / (holdingsnow(8)+holdingsnow(9)+holdingsgovnow(8)+holdingsrownow(8));

%% aggregate business sector for use in scf exercise
NNPbus = (scfassfactors(:,[[1:7] 10])*(holdingscorpscf([[1:7] 10]) - debtcorpscf([[1:7] 10]))')' + NNPpribusnowfof;
NNPcorpscf =  (scfassfactors(:,[[1:7] 10])*(holdingscorpscf([[1:7] 10]) - debtcorpscf([[1:7] 10]))')';


%% convention for equity: gov and row hold only corp equity, for households, both is possible!
allequity = assagg(8)+assagg(9)+holdingsgovnow(8)+holdingsrownow(8);
allcorpequity = assagg(8)+holdingsgovnow(8)+holdingsrownow(8);
lambdaotherscf = - NNPcorpscf / allcorpequity;
lambdahhscf = - (NNPbus - (holdingsgovnow(8)+holdingsrownow(8))*NNPcorpscf/allcorpequity) / (assagg(8)+assagg(9));


%% recall extrafactor only used to adjust datasets
extrafactor = 1;

%% now need to adjust the scfassfactors: put the same lambdascf for both equity and bus !!
scfassfactors(1,8) = extrafactor;  % equity at initial market value  
scfassfactors(2,8) = extrafactor + lambdahhscf(1) - lambdahhscf(2); % equity with instantaneous revaluation
scfassfactors(3,8) = extrafactor + lambdahhscf(1) - lambdahhscf(3);       % equity with gradual revaluation
scfassfactors(1,9) = extrafactor;  % for bus, simply trat initial net worth like outst equity for corp !
scfassfactors(2,9) = extrafactor + lambdahhscf(1) - lambdahhscf(2); % equity with instantaneous revaluation
scfassfactors(3,9) = extrafactor + lambdahhscf(1) - lambdahhscf(3);       % equity with gradual revaluation





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% REDEFINE INDIRECT NOMINAL POSITIONS
%% NNPlambda = net indirect positions
%% sectoral matrices here have same format (6 x 7) as in fofcalc
%%  rows are hhonly, hh (w. nonprof), gov, row, corp, fin
%%  columns are value (orig, imm, grad, par, and then 3 differences)
%% 

NNPlambda = NNPlambdanow;

%% redefine NNPlambda for the gov sector, due to reconciliation!!!
% recall row is unaffected since it does not deal with hh directly by ass
NNPlambda(3,1:numval) = (scfassfactors(:,[[1:7] 10]) * (holdingsgovscf([[1:7] 10]) - debtgovscf([[1:7] 10]))')'...
                                  - lambdaotherscf * holdingsgovscf(8);
NNPlambda(1,1:numval) = (scfassfactors(:,[[1:7] 10]) * holdingsscf([[1:7] 10])' - scfassfactors(:,[5 1]) * debtagg')'...
                                  - lambdahhscf * (holdingsscf(8)+holdingsscf(9));
NNPlambda(2,1:numval) = (scfassfactors(:,[[1:7] 10]) * holdingsnonprnow([[1:7] 10])' - scfassfactors(:,[5 1]) * debtnonprnow')'...
                                  - lambdaotherscf * (holdingsnonprnow(8));                     
NNPlambda(4,1:numval) = (scfassfactors(:,[[1:7] 10]) * (holdingsrownow([[1:7] 10]) - debtrownow([[1:7] 10]))')'...
                                  - lambdaotherscf * holdingsrownow(8);
NNPlambda(:,numval+1:numval+scenarios) = NNPlambda(:,2:numval) - NNPlambda(:,1)*ones(1,scenarios);
NNPlambdanow(2,1:numval) = NNPlambdanow(2,1:numval) - NNPlambdanow(1,1:numval);
NNPlambdanow(2,numval+1:numval+scenarios) = zeros(1,scenarios);


NNP = zeros(5,7);
NNP(3,1:4) = (scfassfactors(:,[[1:7] 10]) * (holdingsgovscf([[1:7] 10]) - debtgovscf([[1:7] 10]))')';
NNP(1,1:4) = (scfassfactors(:,[[1:7] 10]) * holdingsscf([[1:7] 10])' - scfassfactors(:,[5 1]) * debtagg')';
NNP(2,1:4) = (scfassfactors(:,[[1:7] 10]) * holdingsnonprnow([[1:7] 10])' - scfassfactors(:,[5 1]) * debtnonprnow')';
NNP(4,1:4) = (scfassfactors(:,[[1:7] 10]) * (holdingsrownow([[1:7] 10]) - debtrownow([[1:7] 10]))')';
NNP(5,1:4) = NNPbus;
oNNP = zeros(5,7);
oNNP(3,1:4) = (scfassfactors(:,[[1:7] 10]) * (holdingsgovnow([[1:7] 10]) - debtgovnow([[1:7] 10]))')';
oNNP(1,1:4) = (scfassfactors(:,[[1:7] 10]) * holdingsnow([[1:7] 10])' - scfassfactors(:,[5 1]) * debtnow')';
oNNP(2,1:4) = (scfassfactors(:,[[1:7] 10]) * holdingsnonprnow([[1:7] 10])' - scfassfactors(:,[5 1]) * debtnonprnow')';
oNNP(4,1:4) = (scfassfactors(:,[[1:7] 10]) * (holdingsrownow([[1:7] 10]) - debtrownow([[1:7] 10]))')';
oNNPc = (scfassfactors(:,[[1:7] 10]) * (holdingscorpnow([[1:7] 10]) - debtcorpnow([[1:7] 10]))')';
oNNP(5,1:4) = NNPpribusnowfof + oNNPc;



NNP(:,numval+1:numval+scenarios) = NNP(:,2:numval) - NNP(:,1)*ones(1,scenarios);
oNNP(:,numval+1:numval+scenarios) = oNNP(:,2:numval) - oNNP(:,1)*ones(1,scenarios);



disp('********************************************************************************');
disp('what happens in the reconciliation');
disp('before and after asset by asset:');
holnow = holdingscorpnow+holdingsgovnow+holdingsnow+holdingsrownow+holdingsbusnow;
dnow = debtcorpnow+debtgovnow+debtrownow + [debtbusnow(2)+debtnow(2) 0 0 0 debtbusnow(1)+debtnow(1) 0 0 0 0 0];
dscf = debtcorpscf+debtgovscf+debtrownow + [debtbusnow(2)+debtscf(2) 0 0 0 debtbusnow(1)+debtscf(1) 0 0 0 0 0];
holscf = holdingscorpscf+holdingsgovscf+holdingsscf+holdingsrownow+holdingsbusnow;
disp('ffa: holdings, debt, discrepancy');
disp([holnow; dnow; holnow-dnow]); 
disp('scf: holdings, debt, discrepancy');
disp([holscf; dscf; holscf-dscf]); 


disp('NNP (hh, nonprofits, gov, row, bus)');
disp('old');
disp(oNNP);
disp('sums to');
disp(sum(oNNP));
disp('new');
disp(NNP);
disp('sums to');
disp(sum(oNNP));
disp('************************************************************************');
disp('NNPlambda (hh, gov, row)');
disp('old');
disp(NNPlambdanow([1 3 4],:));
disp('sums to');
disp(sum(NNPlambdanow));
disp('new');
disp(NNPlambda([1 3 4],:));
disp('sums to');
disp(sum(NNPlambda));
disp('************************************************************************');
disp('NNPlambdas again, relative to gdp');
disp('NNP (hh, gov, row');
disp('old');
disp(NNPlambdanow([1 3 4],:)/ngdp);
disp('sums to');
disp(sum(NNPlambdanow/ngdp));
disp('new');
disp(NNPlambda([1 3 4],:)/ngdp);
disp('sums to');
disp(sum(NNPlambda/ngdp));

clear mmmf bonds trust life short mutf pen stocks
clear SCF;
clear finstuff;

save SCFstuff89all;



%% holdings by position 

disp('=======================================================');
disp('holdings by position, 1989 SCF ');
disp('=======================================================');
disp('outstanding gov-related debt');
disp('(cols are treas muni agency shortgov total; rows are gov corp total)');
xx=[debtgovscf([2 3 7 10]), sum(debtgovscf([2 3 7 10]));...
    debtcorpscf([2 3 7 10]), sum(debtcorpscf([2 3 7 10]))];
disp([xx;sum(xx)]);

disp('holdings (treas muni agency shortgov total)'); 
disp('(rows are gov hhnobus, hhbus, row, corp, nonprof, total'); 
xx=[holdingsgovscf([2 3 7 10]), sum(holdingsgovscf([2 3 7 10]));...
    holdingsscf([2 3 7 10]),sum(holdingsscf([2 3 7 10]));...
        holdingsbusnow([2 3 7 10]),sum(holdingsbusnow([2 3 7 10]));...
        holdingsrownow([2 3 7 10]),sum(holdingsrownow([2 3 7 10]));...
        holdingscorpscf([2 3 7 10]),sum(holdingscorpscf([2 3 7 10]));...
        holdingsnonprnow([2 3 7 10]), sum(holdingsnonprnow([2 3 7 10]))];
disp([xx;sum(xx)]);
disp('=======================================================');
disp('other debt');
disp('total outstanding (short corp mortg life) where rows are corp, gov, row, bus, hh, total')
xx=[debtcorpscf([1 4 5 6]),sum(debtcorpscf([1 4 5 6]));...
        debtgovscf([1 4 5 6]),sum(debtgovscf([1 4 5 6]));...
        debtrownow([1 4 5 6]),sum(debtrownow([1 4 5 6]));...
        debtbusnow(2) 0 debtbusnow(1) 0 debtbusnow(1)+debtbusnow(2);...
        debtscf(2) 0 debtscf(1) 0 debtscf(1)+debtscf(2)];
disp([xx;sum(xx)]);

disp('holdings (short corp mortg life) where rows are hhnobus, corp, gov, row, bus, nonprof, total') 
xx=[holdingsscf([1 4 5 6]),sum(holdingsscf([1 4 5 6]));...
        holdingscorpscf([1 4 5 6]),sum(holdingscorpscf([1 4 5 6]));...
        holdingsgovscf([1 4 5 6]),sum(holdingsgovscf([1 4 5 6]));...
        holdingsrownow([1 4 5 6]),sum(holdingsrownow([1 4 5 6]));...
        holdingsbusnow([1 4 5 6]),sum(holdingsbusnow([1 4 5 6]));...
    holdingsnonprnow([1 4 5 6]), sum(holdingsnonprnow([1 4 5 6]))];
disp([xx;sum(xx)]);


disp('equity');
disp('outstanding total');
disp(allequity);
disp('holdings, where cols are hhnobus, hhbus, row, gov, total'); 
xx=[holdingsscf(8)+holdingsscf(9);...
        holdingsbusnow(8);...
        holdingsrownow(8);...
        holdingsgovscf(8)];
disp([xx',sum(xx)]);



