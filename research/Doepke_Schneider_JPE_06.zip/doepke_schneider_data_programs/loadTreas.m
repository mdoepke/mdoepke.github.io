%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program: loadTreas.m
% Purpose: reads all the raw treasuries data from ascii text
%          files, and turns all the variables into matlab format
% By:      Matthias Doepke, Martin Schneider, David Lagakos
% Date:    Nov 9, 2005
% Input:   None
% Uses:    Ascii text data available from CRSP containing daily
%          treasury quote data.
% Output:  .mat files containing the tables in matlab format.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clean up workspace
close all;
clear all;

% here put name of main directory that should contain the file monthlyTreasuries19502031_2.txt
%rawDataDirectory = 'C:\Projects\doepke\jpefinal\'; 
monthlyTreasFile = 'monthlyTreasuries19502031_2.txt';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Read MONTHLY treasuries file into Matlab matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load the desired ascii file
fid = fopen(monthlyTreasFile,'r'); %open file for read
if isequal(fid,-1) %halt if file input error
    error('Text file cannot be input properly')
end 

%initialize treasury data matrix, cuspid vector, and quarters vector 
treasData = [];
quartersMonthly = [];

while 1 %while not end of file
    % get the next line in the raw data
    newLine = fgetl(fid);
    if ~isstr(newLine) 
        %%% end if the end of the file has been reached %%% 
        break
    elseif or(isequal(newLine,' '),isequal(newLine,'')) 
        %%% end of file not reached yet, 'missing lines' found %%%
    elseif or(isequal(newLine(1,1),'2'),isequal(newLine(1,1),'1'))
        %%% end of file not reached yet, data found %%%
        
        % turn data to strings
        newLine = sscanf(newLine,'%c');
        newLine = strread(newLine,'%s')'; 

        % record variables in this line
        CRSPID = char(newLine(1,1));
        qdateString = char(newLine(1,3));
        qdateYear = str2num(qdateString(1,1:4));
        qdateMonth = str2num(qdateString(1,5:6));
        qdateDay = str2num(qdateString(1,7:8));
        nmon = str2num(char(newLine(1,4)));
        bid = str2num(char(newLine(1,5)));
        ask = str2num(char(newLine(1,6)));
        iout1r = str2num(char(newLine(1,7)));
        iout2r = str2num(char(newLine(1,8)));

        % pull relevant info from CRSPID
        [maturityYear,maturityMonth,maturityDay,...
                issueType,couponRate,unique] = getCrspInfo(CRSPID);
        CRSPID = str2num(CRSPID);
        
        % determine whether the issue is short or not
        short = (isequal(issueType,3)+isequal(issueType,4)+isequal(issueType,7)+...
            isequal(issueType,8))>0;

        % record the data only if it's one of the last 4 days in the end
        % the quarter. In fact only one end-of-quarter data exists in the raw
        % data but the actual end-of-quarter date varies from year to year 
        % because of weekends falling on the 30th, etc
        if (isequal(qdateMonth,3)*(qdateDay>=28)... 
                + isequal(qdateMonth,6)*(qdateDay>=27)...
                + isequal(qdateMonth,9)*(qdateDay>=27)...
                + isequal(qdateMonth,12)*(qdateDay>=28))>0;
        
            % replace the quote date with a quarterly date
            if isequal(qdateMonth,3);
                qdate=qdateYear*100+01;
            elseif isequal(qdateMonth,6);
                qdate=qdateYear*100+02;
            elseif isequal(qdateMonth,9);
                qdate=qdateYear*100+03;
            else
                qdate=qdateYear*100+04;
            end
            
            % record the current quarter if its the first time it appears
            if size(quartersMonthly,1)>0
                if sum(quartersMonthly==qdate)==0 %check whether qdate appears already
                    quartersMonthly = [quartersMonthly; qdate];
                end
            else %%% quarters is empty %%%
                quartersMonthly = [quartersMonthly; qdate];
            end
            
            % record the data
            treasData = [treasData;...
                    qdate,qdateYear,qdateMonth,qdateDay,...
                    maturityYear,maturityMonth,maturityDay,...
                    couponRate,nmon, bid, ask, iout1r, iout2r,...
                    short, CRSPID];            
        end %end of quarter date
        
    end %if eof not reached 
end %while not end of file

% close the file for reading
fclose(fid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: Go issue by issue; clean up missing data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% pull all the data for a given issue (using CRSPID as issue indicator)
treasCleaned = [];
rowCount = 1;
CRSPID_current = treasData(rowCount,15);
issueMat = [treasData(rowCount,:)];

while rowCount < size(treasData,1)
    rowCount = rowCount + 1;
    if isequal(CRSPID_current,treasData(rowCount,15));
        %%% another date for this issue %%%
        issueMat = [issueMat; treasData(rowCount,:)];
    else
        %%% no more dates for this issue %%%
        
        % set the correct data names
        qdate = issueMat(:,1);
        qdateYear = issueMat(:,2);
        qdateMonth = issueMat(:,3);
        qdateDay = issueMat(:,4);
        maturityYear = issueMat(:,5);
        maturityMonth = issueMat(:,6);
        maturityDay = issueMat(:,7);
        couponRate = issueMat(:,8);
        nmon = issueMat(:,9);
        bid = abs(issueMat(:,10));
        ask = abs(issueMat(:,11));
        totout = issueMat(:,12); %same as iout1r
        pubout = issueMat(:,13); %same as iout2r
        short = issueMat(:,14);
        CRSPID = issueMat(:,15);
        
        % replace missing values by extrapolating
        bid = extrapMissing(bid);
        ask = extrapMissing(ask);
        totout = extrapMissing(totout);
        pubout = extrapMissing(pubout);
        
        % record the cleaned data in treasCleaned
        issueMatCleaned = [qdate qdateYear qdateMonth qdateDay...
                maturityYear maturityMonth maturityDay...
                couponRate nmon bid ask totout pubout...
                short];         
        treasCleaned = [treasCleaned; issueMatCleaned];

        % move on to a new issue
        CRSPID_current = treasData(rowCount,15);
        issueMat = [treasData(rowCount,:)];
    end
end

%sort by quote date
[y,i] = sortrows(treasCleaned,1);
treasData = y;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Go quote date by quote date, create payments and values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize results
values = []; %market values of non-short debt
svalues = []; %market value of short debt
pubvalues = []; %market values of publicly held non-short debt
spubvalues = []; %market value of publicly held short debt
parvalues = []; %face values of non-short debt
sparvalues = []; %face value of short debt
pubparvalues = []; %face values of publicly held non-short debt
spubparvalues = []; %face value of publicly held short debt

% record the payments for 40*12+1 possible months
% and the short payments for 40*12+1 possible months
% which is the number of possible payout years x 12 + 1
% First column is maturity 'this month,' second col
% is maturity one month later, etc.
payments = zeros(size(quartersMonthly,1),40*12+1);
spayments = zeros(size(quartersMonthly,1),40*12+1); %short stuff.
pubpayments = zeros(size(quartersMonthly,1),40*12+1);
spubpayments = zeros(size(quartersMonthly,1),40*12+1); %short stuff.

% loop quarter by quarter
for iQuarter = 1:size(quartersMonthly,1);
    currentQuarter = quartersMonthly(iQuarter,1);
    
disp('current quarter is');
disp(currentQuarter);
    
    % get the relevant vars from treasData, name them
     treasTemp = treasData(treasData(:,1)==currentQuarter,:);
     qdate = treasTemp(:,1);
     qdateYear = treasTemp(:,2);
     qdateMonth = treasTemp(:,3);
     qdateDay = treasTemp(:,4);
     maturityYear = treasTemp(:,5);
     maturityMonth = treasTemp(:,6);
     maturityDay = treasTemp(:,7);
     couponRate = treasTemp(:,8);
     nmon = treasTemp(:,9);
     bid = treasTemp(:,10);
     ask = treasTemp(:,11);
     totout = treasTemp(:,12); %same as iout1r
     pubout = treasTemp(:,13); %same as iout2r
     short = treasTemp(:,14);
           
    % record the face values outstanding for this qdate
    % take the price to be the mean of the bid and ask
    % these values are in MILLIONS of dollars
    svalues = [svalues; (1/100)*sum(((bid+ask)/2).*totout.*short)];
    values = [values; (1/100)*sum(((bid+ask)/2).*totout.*(1-short))];

    spubvalues = [spubvalues; (1/100)*sum(((bid+ask)/2).*pubout.*short)];
    pubvalues = [pubvalues; (1/100)*sum(((bid+ask)/2).*pubout.*(1-short))];
    
    sparvalues = [sparvalues; sum(totout.*short)];
    parvalues = [parvalues; sum(totout.*(1-short))];
    
    spubparvalues = [spubparvalues; sum(pubout.*short)];
    pubparvalues = [pubparvalues; sum(pubout.*(1-short))];

 
    
    
    % loop over issues in this date
    for iIssue = 1:size(treasTemp,1)        
        % compute months until maturity
        monthsUntilMaturity = (maturityYear(iIssue,1)-qdateYear(iIssue,1))*12+...
            maturityMonth(iIssue,1)-qdateMonth(iIssue,1);
        
        % record the repayment of principle
        payments(iQuarter,monthsUntilMaturity+1) =...
            payments(iQuarter,monthsUntilMaturity+1) +...
            (1-short(iIssue,1))*totout(iIssue,1);
        spayments(iQuarter,monthsUntilMaturity+1) = spayments(iQuarter,monthsUntilMaturity+1)...
            +short(iIssue,1)*totout(iIssue,1);
        pubpayments(iQuarter,monthsUntilMaturity+1) =...
            pubpayments(iQuarter,monthsUntilMaturity+1) +...
            (1-short(iIssue,1))*pubout(iIssue,1);
        spubpayments(iQuarter,monthsUntilMaturity+1) = spubpayments(iQuarter,monthsUntilMaturity+1)...
            +short(iIssue,1)*pubout(iIssue,1);
        
        % record the coupon payments if any
        if couponRate(iIssue,1)>0
            monthsRemaining = monthsUntilMaturity;
            while 1 % while coupon payments potentially payable
                monthsRemaining = monthsRemaining - 6;
                if monthsRemaining >= 0
                    %%% more coupon payments %%%
                    payments(iQuarter,monthsRemaining+1) = ...
                        payments(iQuarter,monthsRemaining+1)+...
                        (1-short(iIssue,1))*totout(iIssue,1)*0.5*couponRate(iIssue,1)/100;
                    spayments(iQuarter,monthsRemaining+1) = ...
                        spayments(iQuarter,monthsRemaining+1)+...
                        short(iIssue,1)*totout(iIssue,1)*0.5*couponRate(iIssue,1)/100;
                    pubpayments(iQuarter,monthsRemaining+1) = ...
                        pubpayments(iQuarter,monthsRemaining+1)+...
                        (1-short(iIssue,1))*pubout(iIssue,1)*0.5*couponRate(iIssue,1)/100;
                    spubpayments(iQuarter,monthsRemaining+1) = ...
                        spubpayments(iQuarter,monthsRemaining+1)+...
                        short(iIssue,1)*pubout(iIssue,1)*0.5*couponRate(iIssue,1)/100;
                else
                    %%% no more coupon payments %%%
                    break
                end %if
            end %while
        end %if 
    end % iIssue loop
end % iQuarter loop

% save the data
quarters = quartersMonthly;
save treasCRSP quarters payments spayments values svalues parvalues sparvalues ...
              pubvalues  spubvalues  pubparvalues  spubparvalues pubpayments spubpayments; %rawDataDirectory;
