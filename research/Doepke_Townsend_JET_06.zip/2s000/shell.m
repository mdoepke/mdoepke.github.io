% shell.m    Unobserved Storage problem
% Shell     
% Version for two endowments 
% February 2, 1999
% Matthias Doepke

clear all;

% Initialize all variables
init;

% Do last period
step1;

% Counter starts at 2 because step1 is already one period
itercount=2;
save shell itercount;

while itercount<nitera;

	step2;			% Program 3
	
   % Count up. Needs to be saved because step2 clears workspace
   load shell;
	itercount=itercount+1;
	save shell itercount;
end;

% Finally, do initial period

step2;
step3;
