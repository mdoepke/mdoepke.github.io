% step1.m    Unobserved Storage problem
% Solving the value function for the last period
% Matlab routine
% September 1, 1999
% Matthias Doepke
%
clear all;

load init;   % load parameters
 
% This program determines the matrix V.
% V has for columns: low-state utility, high-state utility,
% and the values of the planner if the low or high state is realized

% i always corresponds to the low state, j to the high state

% Initializing V
V=zeros(1,2*nE);

% Defining the objective function for the LP
OBJ=-T2';

% The following line transfers into a minimization problem 
OBJ=-OBJ;

for i=1:nW;
	
	exitflag=0;
	j=1;
	while j<=nW;

		% First the low state
      % First the inequality constraint
      A=sparse(u(T2'+E(2)));
      b=W(j);
      
      % Now the equality constraints
      Aeq=sparse([ones(1,nT2); u(T2'+E(1))]);
      beq=[1; W(i)];
      
      [x,v1,flag1]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),...
	  	ones(size(OBJ)),zeros(size(OBJ)),OPTIONS);
      
      % Convert optimized value back
      v1=-v1;
      
      % Now the same program for the high state
      
      % First the inequality constraint
      A=sparse(u(T2'+E(1)));
      b=W(i);
      
      % Now the equality constraints
      Aeq=sparse([ones(1,nT2);u(T2'+E(2))]);
      beq=[1; W(j)];

      [x,v2,flag2]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),...
	  	ones(size(OBJ)),zeros(size(OBJ)),OPTIONS);
      
      % Convert optimized value back
      v2=-v2;

		if (flag1>0)&(flag2>0);
			V=[V;W(i),W(j),v1,v2];
		end;
		
		% Exit early if possible
		if (flag2>0)&(exitflag==0);
			exitflag=1;
		end;
		if (flag2<0)&(exitflag==1);
			j=nW;
		end;
		
		j=j+1;

		['Step 1, ' num2str(i) ' out of ' num2str(nW)]
	
	end;
	
	i=i+1;
end;

% Cutting off the first row
V=V(2:size(V,1),:);

% Saving parameters and V
save values V;
