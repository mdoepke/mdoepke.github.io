% step3fi.m    Unobserved Storage problem
% Planning period
% Version for two endowments 
% Version for interior point algorithm 
% September 1999
% Matthias Doepke


% This program determines the matrix Vfinal

% Organisation of V by column:
% 1 Utility of agent
% 2 Low-state utility of planner
% 3 High-state utility of planner
% 4 Expected transfer at low state
% 5 Expected transfer at high state
% 6 Expected storage at low state
% 7 Expected storage at high state
% 8 Expected promised utility at low state
% 9 Expected promised utility at high state

load init;	     % load parameters
load fivalues;   % load V

% Initializing Vfinal
Vfinal=zeros(1,8);

% Define the grids for utilities
Wbmn=u(E(2)+Tmn)+BETA*V(1,1);
Wbmx=u(E(1)+Tmx)+BETA*V(size(V,1),1);

% The grid
Wb=linspace(Wbmn,Wbmx,nWb);

% Actual number of utility assignments
nWa=size(V,1);

% Organization: 
% Utilities count up fast, storage slow
OBJ2=Q*reshape(V(:,nE:2*nE-1)*P,1,nWa*nS);

% Same thing for utility
U2=BETA*kron(ones(1,nS),V(:,1)');

% Order: T, S, W
CE=kron(E',ones(1,nT*nS*nWa));
CT=kron(kron(ones(1,nE),T'),ones(1,nS*nWa));
CS=kron(kron(ones(1,nE*nT),S'),ones(1,nWa));
CPK=u(CE+CT-CS)+kron(ones(1,nE*nT),U2);
   
OBJ=-kron(kron(ones(1,nE),T'),ones(1,nS*nWa))+kron(ones(1,nE*nT),OBJ2);
% The following line transfers into a minimization problem 
OBJ=-OBJ;
   
% Probability constraints
CP1=[ones(1,nT*nS*nWa) zeros(1,nT*nS*nWa)];
CP2=[zeros(1,nT*nS*nWa) ones(1,nT*nS*nWa)];

% There is no inequality constraint
A=[];
b=[];

% Now the equality constraints:
Aeq=sparse([CP1;CP2;CPK]);

% Initialize output counter
counter=1;

% loop for promised utilites
for i=1:nW0;

	beq=[P1(1); P1(2); W0(i)];

	[x,v,flag]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

	% Convert optimized value back
	v=-v;

	['Value  : ',num2str(v)]
	['Utility: ',num2str(W0(i))]

	% Save results if there is a solution
	if flag>0;
		
		Utility(counter,1)=W0(i);		
		Value(counter,1)=v;

		if Value(counter,1)<0&Value(counter-1,1)>0;
			Ulo=Utility(counter-1,1);
			Uhi=Utility(counter,1);
		end;

		% Policies: 
		% Transfer:
		etl=kron(kron([1 0],T'),ones(1,nS*nWa))*x/P1(1);			
        eth=kron(kron([0 1],T'),ones(1,nS*nWa))*x/P1(2);
         
		% Storage:
        esl=kron(kron([ones(1,nT) zeros(1,nT)],S'),ones(1,nWa))*x/P1(1);
        esh=kron(kron([zeros(1,nT) ones(1,nT)],S'),ones(1,nWa))*x/P1(2);

		% Promised utilities:
		pul=kron([ones(1,nT*nS) zeros(1,nT*nS)],V(:,1)')*x/P1(1);
		puh=kron([zeros(1,nT*nS) ones(1,nT*nS)],V(:,1)')*x/P1(2);
		

		Petl(counter,1)=etl;
		Peth(counter,1)=eth;
		Pesl(counter,1)=esl;
		Pesh(counter,1)=esh;
		Ppul(counter,1)=pul;
		Ppuh(counter,1)=puh;
        
        % Update Vfinal
        Vfinal=[Vfinal;W0(i),v,etl,eth,esl,esh,pul,puh];         
            
		counter=counter+1;
	end;

end;

% Cutting off the first row
Vfinal=Vfinal(2:size(Vfinal,1),:);


% Finding the zero point
Uzero=.5*Ulo+.5*Uhi;

for i=1:12;

	beq=[P1(1); P1(2); Uzero];

	[x,v,flag]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

	v=-v;

	['Value  : ',num2str(v)]
	['Utility: ',num2str(Uzero)]

	if v>0;
	% Utility is too low
		Ulo=Uzero;
		Uzero=.5*Uzero+.5*Uhi;
	else;
	% Utility is too high
		Uhi=Uzero;
		Uzero=.5*Uzero+.5*Ulo;
	end;

end;

uzerofi=Uzero;

save fiutil uzerofi;

% Plotting the value function
subplot(1,1,1);
x=Utility;
plot(x,Value,'-');
hold on;
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) min(Value) max(Value)]);
title('Value Function of the Planner');
ylabel('Expected Discounted Receipts');
xlabel('Promised Utility');
hold off;

print -deps2 graphs/valuefi.eps;


% Plotting the transfer policy
subplot(3,2,1);
plot(x,Petl,'-',x,Peth,'--');
hold on;
plot([Uzero Uzero],[Tmn Tmx],':');
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) Tmn Tmx]);
title('Transfer, Depending on Endowment');
ylabel('Expected Transfer');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting expected storage
subplot(3,2,2);
plot(x,Pesl,'-',x,Pesh,'--');
hold on;
plot([Uzero Uzero],[-.2 1],':');
axis([min(x) max(x) -.2 1 ]);
title('Expected Storage');
ylabel('Storage');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting the promised utility function for low state
subplot(3,2,3);
plot(x,Ppul,'-');
hold on;
plot([Uzero Uzero],[min(Ppul) max(Ppuh)],':');
axis([min(x) max(x) min(Ppul) max(Ppuh)]);
title('Promised Utilities at Low State');
ylabel('Promised Utility');
xlabel('');
hold off;

% Plotting the promised utility function for high state
subplot(3,2,4);
plot(x,Ppuh,'-');
hold on;
plot([Uzero Uzero],[min(Ppul) max(Ppuh)],':');
axis([min(x) max(x) min(Ppul) max(Ppuh)]);
title('Promised Utilities at High State');
ylabel('Promised Utility');
xlabel('');
hold off;

% Plotting consumption
subplot(3,2,5);
plot(x,E(1)+Petl-Pesl,'-',x,E(2)+Peth-Pesh,'--');
hold on;
plot([Uzero Uzero],[min(E(1)+Petl-Pesl) max(E(2)+Peth-Pesh)],':');
axis([min(x) max(x) min(E(1)+Petl-Pesl) max(E(2)+Peth-Pesh)]);
title('Consumption, Depending on Endowment');
ylabel('Expected Consumption');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting planner's consumption
subplot(3,2,6);
plot(x,P1(1)*Petl+P1(2)*Peth,'-');
hold on;
plot([Uzero Uzero],[Tmn Tmx],':');
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) Tmn Tmx]);
title('Transfer');
ylabel('Net Transfer to both Agents');
xlabel('');
hold off;

print -deps2 graphs/polfi.eps;

% Saving V
save fires Vfinal;
