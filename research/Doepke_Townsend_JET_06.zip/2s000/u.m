function res = u(x);
%u.m        The utility of consumption
%11 January 1997 Matthias Doepke
%

   res = log(x)+5;

   return

