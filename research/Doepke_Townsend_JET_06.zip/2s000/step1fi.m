% step1fi.m    Unobserved Storage problem
% Solving the value function for the last period
% Full information version, no incentive constraints, but with grids
% Matlab routine
% September 1, 1999
% Matthias Doepke
%
clear all;

load init;   % load parameters
 
% This program determines the matrix V.
% V has three columns:
% The agents utility and the value of the planner 
% if the low or high state is realized

% i always corresponds to the low state, j to the high state

% Initializing V
V=zeros(1,1+nE);

% Defining the objective function for the LP
OBJ=-T2';

% The following line transfers into a minimization problem 
OBJ=-OBJ;

for i=1:nW;

% First the low state
% There is no inequality constraint
A=[];
b=[];

% Now the equality constraints:
Aeq=sparse([ones(1,nT2); u(T2'+E(1))]);
beq=[1; W(i)];

[x,v1,flag1]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

% Convert optimized value back
v1=-v1;

% Now the same program for the high state
% The equality constraints
Aeq=sparse([ones(1,nT2);u(T2'+E(2))]);
beq=[1; W(i)];

[x,v2,flag2]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

% Convert optimized value back
v2=-v2;

if (flag1>0)&(flag2>0);
   V=[V;W(i),v1,v2];
end;

end;

% Cutting off the first row
V=V(2:size(V,1),:);

% Saving V
save fivalues V;
