% step3.m    Unobserved Storage problem
% Beginning of the first period      
% Interior point algorithm
% September 5, 1999
% Matthias Doepke
%

% This program determines the matrix Vfinal

% Organisation of Vfinal by column:
% 1 Utility of agent
% 2 Utility of planner
% 3 Expected transfer at low state
% 4 Expected transfer at high state
% 5 Expected storage at low state
% 6 Expected storage at high state
% 7 Expected promised utility for low state (tomorrow) at low state (today)
% 8 Expected promised utility for high state (tomorrow) at low state (today)
% 9 Expected promised utility for low state (tomorrow) at high state (today)
% 10 Expected promised utility for high state (tomorrow) at high
% state(today)


% Load workspace (mainly V)
clear all;
load init;
load values;    

% Organisation of V by column:
% 1 Low-state utility of agent
% 2 High-state utility of agent
% 3 Low-state utility of planner
% 4 High-state utility of planner
% 5 Expected transfer at low state
% 6 Expected transfer at high state
% 7 Expected storage at low state
% 8 Expected storage at high state
% 9 Expected promised utility for low state at low state
% 10 Expected promised utility for high state at low state
% 11 Expected promised utility for low state at high state
% 12 Expected promised utility for high state at high state

% Initializing Vfinal
Vfinal=zeros(1,2+4*nE);

% Defining the objective function
OBJ=(V(:,3:4)*P1)';

% Constraints:
CP=sparse(ones(1,size(V,1)));

% Promise keeping constraint
CPK=sparse((V(:,1:2)*P1)');

% Flip objective function
OBJ=-OBJ;

% Inequality constraint
A=[];
b=[];

% Equality constraints
Aeq=[CP;CPK];

% Counter for output
counter=1;

% loop for promised utilites
for i=1:nW0;

	beq=[1;W0(i)];

	[x,v,flag]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));
   
   v=-v;
   
	['Value  : ',num2str(v)]
	['Utility: ',num2str(W0(i))]

	% Save results if there is a solution
	if flag>0;

		Utility(counter,1)=W0(i);		
		Value(counter,1)=v;
		
		if Value(counter,1)<0&Value(counter-1,1)>0;
			Ulo=Utility(counter-1,1);
			Uhi=Utility(counter,1);
		end;

		% Policies: 
		% Transfer:
		etl=V(:,5)'*x;			
		eth=V(:,6)'*x;

		% Storage:
		esl=V(:,7)'*x;
		esh=V(:,8)'*x;

		% Promised utility for low state:
		pull=V(:,9)'*x;
		puhl=V(:,11)'*x;

		% Promised utility for high state:
		pulh=V(:,10)'*x;
		puhh=V(:,12)'*x;						

		Petl(counter,1)=etl;
		Peth(counter,1)=eth;
		Pesl(counter,1)=esl;
		Pesh(counter,1)=esh;
		Ppull(counter,1)=pull;
		Ppulh(counter,1)=pulh;
		Ppuhl(counter,1)=puhl;
		Ppuhh(counter,1)=puhh;

		% Update Vfinal
		Vfinal=[Vfinal;W0(i),v,etl,eth,esl,esh,pull,pulh,puhl,puhh];         
            
            
		counter=counter+1;
	end;

	['Step 3, ' num2str(i) ' out of ' num2str(nW0)]
end;

% Cutting off the first row
Vfinal=Vfinal(2:size(Vfinal,1),:);

% Finding the zero point
Uzero=.5*Ulo+.5*Uhi;

for i=1:12;

	beq=[1;Uzero];

	[x,v,flag]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));
   
   	v=-v;
   
	['Value  : ',num2str(v)]
	['Utility: ',num2str(Uzero)]
	
	if v>0;
	% Utility is too low
		Ulo=Uzero;
		Uzero=.5*Uzero+.5*Uhi;
	else;
	% Utility is too high
		Uhi=Uzero;
		Uzero=.5*Uzero+.5*Ulo;
	end;
	
end;


% Plotting the value function
subplot(1,1,1);
x=Utility;
plot(x,Value,'-');
hold on;
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) min(Value) max(Value)]);
title('Value Function of the Planner');
ylabel('Expected Discounted Receipts');
xlabel('');
hold off;

print -deps2 graphs/value.eps;

% Plotting the transfer policy
subplot(3,2,1);
plot(x,Petl,'-',x,Peth,'--');
hold on;
plot([Uzero Uzero],[Tmn Tmx],':');
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) Tmn Tmx]);
title('Transfer, Depending on Endowment');
ylabel('Expected Transfer');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting expected storage
subplot(3,2,2);
plot(x,Pesl,'-',x,Pesh,'--');
hold on;
plot([Uzero Uzero],[-.2 1],':');
axis([min(x) max(x) -.2 1 ]);
title('Expected Storage');
ylabel('Storage');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting the promised utility function for low state
subplot(3,2,3);
plot(x,Ppull,'-',x,Ppuhl,'--');
hold on;
plot([Uzero Uzero],[min(Ppull) max(Ppuhh)],':');
axis([min(x) max(x) min(Ppull) max(Ppuhh)]);
title('Promised Utilities for Low State');
ylabel('Promised Utility');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting the promised utility function for high state
subplot(3,2,4);
plot(x,Ppulh,'-',x,Ppuhh,'--');
hold on;
plot([Uzero Uzero],[min(Ppull) max(Ppuhh)],':');
axis([min(x) max(x) min(Ppull) max(Ppuhh)]);
title('Promised Utilities for High State');
ylabel('Promised Utility');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting consumption
subplot(3,2,5);
plot(x,E(1)+Petl-Pesl,'-',x,E(2)+Peth-Pesh,'--');
hold on;
plot([Uzero Uzero],[min(E(1)+Petl-Pesl) max(E(2)+Peth-Pesh)],':');
axis([min(x) max(x) min(E(1)+Petl-Pesl) max(E(2)+Peth-Pesh)]);
title('Consumption, Depending on Endowment');
ylabel('Expected Consumption');
xlabel('');
hold off;
legend('Low','High',2);

% Plotting planner's consumption
subplot(3,2,6);
plot(x,P1(1)*Petl+P1(2)*Peth,'-');
hold on;
plot([Uzero Uzero],[Tmn Tmx],':');
plot([min(x) max(x)],[0 0],'-');
axis([min(x) max(x) Tmn Tmx]);
title('Transfer');
ylabel('Net Transfer to both Agents');
xlabel('');
hold off;

print -deps2 graphs/pol.eps;

% Saving parameters and Vfinal
save icres Vfinal;
