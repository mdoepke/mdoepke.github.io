% shellfi.m    Unobserved Storage problem
% Shell     
% Version for two endowments 
% Full information
% February 2, 1999
% Matthias Doepke

clear all;

% Initialize all variables
init;

% Do last period
step1fi;

% Counter starts at 2 because step1 is already one period
itercount=2;
save shellfi itercount;

while itercount<nitera;

	step2fi;		

	% Count up. Needs to be saved because step2fi clears workspace
   load shellfi;
   
	itercount=itercount+1;
   
   save shellfi itercount;
   
end;

% Finally, do initial period

step3fi;
