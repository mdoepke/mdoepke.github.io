% step2fi.m    Unobserved Storage problem
% Beginning of the period      
% Version for two endowments 
% Version for interior point algorithm September 1999
% Matthias Doepke


% This program determines the matrix V

% Organisation of V by column:
% 1 Utility of agent
% 2 Low-state utility of planner
% 3 High-state utility of planner
% 4 Expected transfer at low state
% 5 Expected transfer at high state
% 6 Expected storage at low state
% 7 Expected storage at high state
% 8 Expected promised utility at low state
% 9 Expected promised utility at high state

load init;	     % load parameters
load fivalues;   % load V

% Initializing Vnew
Vnew=zeros(1,1+nE);

% Define the grids for utilities
Wbmn=u(E(2)+Tmn)+BETA*V(1,1);
Wbmx=u(E(1)+Tmx)+BETA*V(size(V,1),1);

% The grid
Wb=linspace(Wbmn,Wbmx,nWb);

% Actual number of utility assignments
nWa=size(V,1);

% Organization: 
% Utilities count up fast, storage slow
OBJ2=Q*reshape(V(:,nE:2*nE-1)*P,1,nWa*nS);

% Same thing for utility
U2=BETA*kron(ones(1,nS),V(:,1)');

for i=1:nWb;

	% Order: T, S, W
	CE=E(1)*ones(1,nT*nS*nWa);
   CT=kron(T',ones(1,nS*nWa));
   CS=kron(kron(ones(1,nT),S'),ones(1,nWa));
   CPK=u(CE+CT-CS)+kron(ones(1,nT),U2);
   
   OBJ=kron(-T',ones(1,nS*nWa))+kron(ones(1,nT),OBJ2);
	% The following line transfers into a minimization problem 
	OBJ=-OBJ;
   
   % Probability constraint
	CP=ones(1,nT*nS*nWa);

	% There is no inequality constraint
	A=[];
	b=[];

	% Now the equality constraints:
	Aeq=sparse([CP;CPK]);
	beq=[1; Wb(i)];

	[x,v1,flag1]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

	% Convert optimized value back
	v1=-v1;

	% Now the same program for the high state
	% The equality constraints
	% Order: T, S, W
	CE=E(2)*ones(1,nT*nS*nWa);
   CT=kron(T',ones(1,nS*nWa));
   CS=kron(kron(ones(1,nT),S'),ones(1,nWa));
   CPK=u(CE+CT-CS)+kron(ones(1,nT),U2);
      
	% There is no inequality constraint
	A=[];
	b=[];

	% Now the equality constraints:
	Aeq=sparse([CP;CPK]);
	beq=[1; Wb(i)];

	[x,v2,flag2]=linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

	% Convert optimized value back
	v2=-v2;

	if (flag1>0)&(flag2>0);
   	Vnew=[Vnew;Wb(i),v1,v2];
	end;

end;

% Cutting off the first row
Vnew=Vnew(2:size(Vnew,1),:);

% Updating Vnew
V=Vnew;

% Saving V
save fivalues V;
