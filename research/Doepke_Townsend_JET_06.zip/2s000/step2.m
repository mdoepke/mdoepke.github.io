% step2.m    Unobserved Storage problem      
% Using Program 3
% Version for two endowments 
% Interior point algorithm
% May 1, 2000
% Matthias Doepke

% Load workspace
clear all;
load init;
load values;

% This loads the value function V and parameters
% Number of actual possibilities for utility assignment:
nWa=size(V,1);

% The workspace variables contain the value function for the 
% next period.

% This program determines the matrix V

% Organisation of V by column:
% 1 Low-state utility of agent
% 2 High-state utility of agent
% 3 Low-state utility of planner
% 4 High-state utility of planner
% 5 Expected transfer at low state
% 6 Expected transfer at high state
% 7 Expected storage at low state
% 8 Expected storage at high state
% 9 Expected promised utility for low state at low state
% 10 Expected promised utility for high state at low state
% 11 Expected promised utility for low state at high state
% 12 Expected promised utility for high state at high state


% Initializing Vnew
Vnew=zeros(1,6*nE);

% I will first define the part of the objective function that is 
% constant across transfers and endowments.

% Organization: 
% Utilities count up fast, storage slow
OBJ2=Q*reshape(V(:,nE+1:2*nE)*P,1,nWa*nS);

% Same thing for utility
U2=BETA*reshape(V(:,1:nE)*P,1,nWa*nS);

for i=1:(nS-1);
	Palt(:,(nS*(i-1)+1):nS*i)=[P(:,(i+1):nS),P(:,1:i)];
	Salt(i,:)=[S((i+1):nS,1)',S(1:i,1)'];
end;

% What should U2alt look like? (nS-1) x nS*nW2
% Each row is a different deviation.
U2alt=BETA*reshape(V(:,1:nE)*Palt,nWa*nS,(nS-1))';

% To complete objective function, add transfer
OBJ=-kron(T',ones(1,nS*nWa))+kron(ones(1,nT),OBJ2);

% Finally, add zeros for utility bounds
OBJ=[OBJ,zeros(1,nT*nS)];

% Now do the Utility functions
CT=kron(T',ones(1,nS*nWa));
CS=kron(ones(1,nT),kron(S',ones(1,nWa)));
CSalt=kron(ones(1,nT),kron(Salt,ones(1,nWa)));

Ul=u(E(1)+CT-CS)+kron(ones(1,nT),U2);
Uh=u(E(2)+CT-CS)+kron(ones(1,nT),U2);

Ualtl=u(ones(nS-1,1)*(E(1)+CT)-CSalt)+kron(ones(1,nT),U2alt);
Ualth=u(ones(nS-1,1)*(E(2)+CT)-CSalt)+kron(ones(1,nT),U2alt);

% This completes the utility functions. Start building constraints
% Probability constraint is first
CP=sparse([ones(1,nT*nS*nWa),zeros(1,nT*nS)]);

% Promise keeping
CPKl=sparse([Ul,zeros(1,nT*nS)]);
CPKh=sparse([Uh,zeros(1,nT*nS)]);

% Take the right action, assuming report is correct
% Initializing constraints
CI1l=zeros(1,nT*nS*nWa+(nE-1)*nT*nS);
CI1h=zeros(1,nT*nS*nWa+(nE-1)*nT*nS);

for i=1:nT*nS;

	lorow=(i-1)*(nS-1)+1;
	hirow=i*(nS-1);

	CI1l(lorow:hirow,:)=sparse([...
		kron(ones(nS-1,1),kron(sparse(1,i,1,1,nT*nS),ones(1,nWa)))...
		.*(Ualtl-kron(ones(nS-1,1),Ul)),zeros(nS-1,nT*nS)]);

	CI1h(lorow:hirow,:)=sparse([...
		kron(ones(nS-1,1),kron(sparse(1,i,1,1,nT*nS),ones(1,nWa)))...
		.*(Ualth-kron(ones(nS-1,1),Uh)),zeros(nS-1,nT*nS)]);

end;

% Defining the utility bounds
% Initializing constraints
CI2l=zeros(1,nT*nS*nWa+nT*nS);
CI2h=zeros(1,nT*nS*nWa+nT*nS);

for i=1:nT*nS;

	lorow=(i-1)*nS+1;
	hirow=i*nS;

	CI2l(lorow:hirow,:)=sparse([...
		kron(ones(nS,1),kron(sparse(1,i,1,1,nT*nS),ones(1,nWa)))...
		.*[Uh;Ualth],kron(ones(nS,1),sparse(1,i,-1,1,nT*nS))]);

	CI2h(lorow:hirow,:)=sparse([...
		kron(ones(nS,1),kron(sparse(1,i,1,1,nT*nS),ones(1,nWa)))...
		.*[Ul;Ualtl],kron(ones(nS,1),sparse(1,i,-1,1,nT*nS))]);

end;

% Enforcing the utility bounds
CI3=sparse([zeros(1,nT*nS*nWa),ones(1,nT*nS)]);
      
% Now we have to built the constraints. 
% Equality constraints:
Aeql=[CP;CPKl];
Aeqh=[CP;CPKh];
   
% Inequality constraints: Have to be written as less-than-or-equal-to
Al=[CI1l;CI2l;CI3];
Ah=[CI1h;CI2h;CI3];

% Inverse objective, since
% linprog minimizes
OBJ=-OBJ;

% Define the grids for utilities
Wlmn=u(E(1)+Tmn)+BETA*V(1,1:2)*P(:,1);
Wlmx=max(Ul);
Whmn=u(E(2)+Tmn)+BETA*V(1,1:2)*P(:,1);
Whmx=max(Uh);

% The grids
Wl=linspace(Wlmn,Wlmx,nWb);
Wh=linspace(Whmn,Whmx,nWb);

% i always corresponds to the low state, j to the high state

jstart=1;

i=1;
while i<=nWb;

iflag=0;

j=jstart;
while j<=nWb;
   
	bl=[zeros(nT*(nS-1)*nS+nT*nS^2,1);Wh(j)];
	bh=[zeros(nT*(nS-1)*nS+nT*nS^2,1);Wl(i)];

	beql=[1;Wl(i)];
	beqh=[1;Wh(j)];

	[xl,vl,flagl]=linprog(OBJ,Al,bl,Aeql,beql,zeros(size(OBJ)),...
		Whmx*ones(size(OBJ)),[],OPTIONS);
	[xh,vh,flagh]=linprog(OBJ,Ah,bh,Aeqh,beqh,zeros(size(OBJ)),...
		Whmx*ones(size(OBJ)),[],OPTIONS);


	if (flagl>0)&(flagh>0);

		% Switch it back to positive
		vl=-vl;
		vh=-vh;

		% Extract policies
		etl=[CT,zeros(1,nT*nS)]*xl;			
		eth=[CT,zeros(1,nT*nS)]*xh;	
		esl=[CS,zeros(1,nT*nS)]*xl;
		esh=[CS,zeros(1,nT*nS)]*xh;	
		pull=[kron(ones(1,nT*nS),V(:,1)'),zeros(1,nT*nS)]*xl;
		pulh=[kron(ones(1,nT*nS),V(:,2)'),zeros(1,nT*nS)]*xl;
		puhl=[kron(ones(1,nT*nS),V(:,1)'),zeros(1,nT*nS)]*xh;	
		puhh=[kron(ones(1,nT*nS),V(:,2)'),zeros(1,nT*nS)]*xh;		

		% If this is the first solution, start higher 
		% next time
		if iflag==0;
			iflag=1;
			jstart=j;
		end;

		% Update V			
		Vnew=[Vnew;Wl(i),Wh(j),vl,vh,etl,eth,esl,esh,pull,pulh,puhl,puhh];

	else;

		% If there was a solution for this i before, but
		% there is none now, exit
		if iflag==1;
			j=nWb;
		end;

	end;

	['Step 2, ' num2str(i) ' out of ' num2str(nWb)]

	j=j+1;		

end;

i=i+1;
end;

% Cutting off the first row
Vnew=Vnew(2:size(Vnew,1),:);

V=Vnew;

% Saving  V
save values V;
