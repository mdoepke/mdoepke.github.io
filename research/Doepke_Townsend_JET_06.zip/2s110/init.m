% init.m 		Definition of all the variables   
% January 11, 1998
% Matthias Doepke 

clear all;

% Set linprog options
OPTIONS=optimset('Display','off','TolFun',1.00e-04);


nitera=3;							% Number of periods
nitera2=3;							% Number of full-grid
									% iterations

BETA =20/21;						% discount factor of agent
Q=20/21;							% discount factor of principal
									% This 5% interest for planner

Emn=2.1;
Emx=3.1;
nE=2;
E=linspace(Emn,Emx,nE)';			% Possible states

Smn=0;
Smx=.8;
nS=5;
S=linspace(Smn,Smx,nS)';			% storage possibilities

% return on storage
ret=1.1;								% Can be up to 1.1
maximp=ret*(Smx-Smn)/(Emx-Emn);

% Probability to get the high state. Starts at .025 by default
phigh=linspace(.025,.025+maximp,nS);
plow=1-phigh;

P=[plow; phigh];	    	 	% probabilites over E;
								% colums correspond to storage 
								
P1=[.5;.5];						% probabilities over E in first period

Tmn=-1.2;
Tmx= 1;
nT=12;	
T=linspace(Tmn,Tmx,nT)';			% possible transfers 

T2mn=-1.2;
T2mx= 1;
nT2=12;
T2=linspace(T2mn,T2mx,nT2)';	% possible transfers in the last period 

W0mn=(1-BETA^nitera)*u(Emn+Tmn)/(1-BETA);
W0mx=(1-BETA^nitera)*u(Emx+Tmx)/(1-BETA);
W0mn=16;
W0mx=17;

nW0=50;
W0=linspace(W0mn,W0mx,nW0)';	% utility possibilities in planning period

Wmn=u(Emn+Tmn);
Wmx=u(Emx+Tmx);
nW=30;
W=linspace(Wmn,Wmx,nW)';			% utility possibilities in last period

nWb=30;									% Gridsize for utility a
            		                    % at beginning of period
										
% Clean up
clear ret maximp plow phigh;

save init;								% Save all variables
