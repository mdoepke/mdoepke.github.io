% util.m    Unobserved Storage problem
% Computing utilities for full information, ic constrained, and autarky
% September 5, 1999
% Matthias Doepke
%

clear all;

for k=1:10;

	if k==1;
		load 2s000/init; 
		load 2s000/values;
		load 2s000/fiutil;   
		sreturn=0;
	end;
	if k==2;
		load 2s050/init;
		load 2s050/values;
		load 2s050/fiutil;    
		sreturn=.50;
	end;
	if k==3;
		load 2s070/init; 
		load 2s070/values;   
		load 2s070/fiutil; 
		sreturn=.7;
	end;
	if k==4;
		load 2s095/init;
		load 2s095/values;   
		load 2s095/fiutil; 
		sreturn=.95;
	end;
	if k==5;
		load 2s100/init;
		load 2s100/values;   
		load 2s100/fiutil; 
		sreturn=1;
	end;
	if k==6;
		load 2s104/init;
		load 2s104/values;   
		load 2s104/fiutil; 
		sreturn=1.04;
	end;
	if k==7;
		load 2s105/init;
		load 2s105/values;   
		load 2s105/fiutil; 
		sreturn=1.05;
	end;
	if k==8;
		load 2s106/init;
		load 2s106/values;   
		load 2s106/fiutil; 
		sreturn=1.06;
	end;
	if k==9;
		load 2s107/init;
		load 2s107/values;   
		load 2s107/fiutil; 
		sreturn=1.07;
	end;
	if k==10;
		load 2s110/init;
		load 2s110/values;  
		load 2s110/fiutil; 
		sreturn=1.1;
	end;
	
	% Initializing Vfinal
	Vfinal=zeros(1,2+4*nE);

	% Defining the objective function
	OBJ=(V(:,3:4)*P1)';

	% Constraints:
	CP=sparse(ones(1,size(V,1)));

	% Promise keeping constraint
	CPK=sparse((V(:,1:2)*P1)');

	% Flip objective function
	OBJ=-OBJ;

	% Inequality constraint
	A=[];
	b=[];

	% Equality constraints
	Aeq=[CP;CPK];

	% Counter for output
	counter=1;

	% loop for promised utilites
	for i=1:nW0;

		beq=[1;W0(i)];

		[x,v,flag]=...
		linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

	   v=-v;

		['Value  : ',num2str(v)]
		['Utility: ',num2str(W0(i))]

		% Save results if there is a solution
		if flag>0;

			Utility(counter,1)=W0(i);		
			Value(counter,1)=v;

			if Value(counter,1)<0&Value(counter-1,1)>0;
				Ulo=Utility(counter-1,1);
				Uhi=Utility(counter,1);
			end;

			counter=counter+1;
		end;

		['Step 3, ' num2str(i) ' out of ' num2str(nW0)]
	end;

	% Cutting off the first row
	Vfinal=Vfinal(2:size(Vfinal,1),:);

	% Finding the zero point
	Uzero=.5*Ulo+.5*Uhi;

	for i=1:12;

		beq=[1;Uzero];

		[x,v,flag]=...
		linprog(OBJ,A,b,Aeq,beq,zeros(size(OBJ)),ones(size(OBJ)));

		v=-v;

		['Value  : ',num2str(v)]
		['Utility: ',num2str(Uzero)]

		if v>0;
		% Utility is too low
			Ulo=Uzero;
			Uzero=.5*Uzero+.5*Uhi;
		else;
		% Utility is too high
			Uhi=Uzero;
			Uzero=.5*Uzero+.5*Ulo;
		end;

	end;

	SRETURN(k)=sreturn;
	UZERO(k)=Uzero;


	% Next: Determine utility in autarky
	% Utilities in the last period
	Vaut=u(E');

	% Start cycling
	itercount=2;

	while itercount<=nitera;

		[Vautnew(1,1) s1]=max(u(E(1)-S')+BETA*Vaut*P);
		[Vautnew(1,2) s2]=max(u(E(2)-S')+BETA*Vaut*P);

		Vaut=Vautnew;

		itercount=itercount+1;

	end;

	['Utility at low state : ' num2str(Vaut(1))]

	['Utility at high state : ' num2str(Vaut(2))]

	['Expected Utility : ' num2str(Vaut*P1)]

	['Storage at low state : ' num2str(S(s1))]

	['Storage at high state : ' num2str(S(s2))]

	UZEROAUT(k)=Vaut*P1;
	UZEROFI(k)=uzerofi;
	

end;

% NOW I ADD THE CREDIT MARKET RETURN
UZEROCREDIT=ones(1,size(SRETURN,2))*16.6526;
 
% Plotting
subplot(1,1,1);
x=SRETURN;
gr=plot(x,UZEROFI,'--',x,UZERO,'-',x,UZEROCREDIT,':',x,UZEROAUT,'-.');
hold on;
axis([min(x) max(x) 16.63 16.67]);
tl=title('Utility of Agent at Zero Surplus');
yl=ylabel('Utility');
xl=xlabel('R (Return on Storage)');
set(gr,'LineWidth',1.5);
set(yl,'Fontname','Times');
set(yl,'Fontsize',16);
set(xl,'Fontname','Times');
set(xl,'Fontsize',16);
set(tl,'Fontname','Times');
set(tl,'Fontsize',16);
hold off;
legend('First Best','Second Best','Credit Market','Autarky',2);

print -deps2 util4.eps;