This folder contains replication material for:


"Clans, Guilds, and Markets: Apprenticeship Institutions and Growth in the Pre-Industrial Economy"
David de la Croix
Matthias Doepke
Joel Mokyr

There are two files:

* numerical-steady-state.nb (Mathematica) contains steady-state computations for Tables I and II
* TFP_CALCULATION_TABLE.xlsx (EXcel) contains growth accounting calculations for Table II