% transition.m -- computes dynamic simulations in
% "Occupational Choice and the Spirit of Capitalism"

% Dynamics in both leisure appreciation and patience

% Notice: The naming of capital is DIFFERENT in the paper
% K is what the parent invested to simplify notation here.
% (1-delta) appears in the first period return as opposed to 
% in tomorrow's value function

close all;
clear all;
clear all;

% Parameter values
z=0.5;          % Altruism

nu= .5;        % Depreciation of patience 
xi=.5;           % Elasticity of patience
phi  = .655;       % Level parameter for producing patience
Bbar=0.4;        % No-investment level of patience

nu_leis= .5;        % Depreciation of leisure preference
xi_leis=.5;       % Elasticity of leisure preference
phi_leis=1.5;      % Level parameter for producing leisure preference
Abar=1.0;        % No-investment level of leisure preference

% The function for accumulating patience is given by:
% B'= nu Bbar+(1-nu) B + phi l^xi 

% Return on capital
R_min=.2;
R_max=.8;

R_min=.4;
R_max=.5;

R_min=.35;
R_max=.42;

% Depreciation of capital
delta=0.2;

% Elasticity of return increase
eta=0.5;

% Income profile
y11=1;
y12=2;

y21=1.4142;
y22=1.4142;

% Technical parameters
incrB=0.005;                % Increment in the Bgrid
incrB=0.1;
incrB=0.05;
incrB=0.025;

minB=.4;                     % Minimum value for B
maxB=.8;                    % Maximum value for B

% Setting up the B grid
Bgrid=[minB:incrB:maxB];
nB=length(Bgrid);

incrA=0.1;                  % Increment in the Agrid
incrA=0.05;

minA=1.4;                     % Minimum value for A
maxA=2;                     % Maximum value for A

% Setting up the A grid
Agrid=[minA:incrA:maxA];
nA=length(Agrid);

% Increment in the K grid
incrK=1.1;                   % Relative grid

minK=0.3;
floorK=10^-4;       % Bigger than zero to avoid log(zero)
maxK=8*y12;

% Needed gridpoints
nK=round(log(maxK/minK)/log(incrK)+2);

% Setting up the K grid; also add a value close to zero
Kgrid=[floorK, minK*incrK.^[0:1:nK-2]];
nK=length(Kgrid);

% Size of ngrid
nsize=21;
incrn=1/(nsize-1);

% Setting up the ngrid
ngrid=linspace(0,1,nsize);

maxcrit=10^(-3);             % Converge criterion

% Initializing the value function
% Indexing is such that nA counts up slowly, i.e. 
%(A1,B1) (A1,B2) ... (A1, BN) (A2,B1) (A2,B2) ... and so on
v=zeros(nK,nA*nB);
vnew=zeros(nK,nA*nB);      % The new value function
ABpol=zeros(nK,nA*nB);
Apol=zeros(nK,nA*nB);
Bpol=zeros(nK,nA*nB);
Kpol=zeros(nK,nA*nB);

ABpol_int=zeros(nK,nA*nB);

% The required time investment for patience; avoid negative numbers
l_B=((max(Bgrid'*ones(1,nB)-nu*Bbar-(1-nu)*ones(nB,1)*Bgrid,zeros(nB,nB)))/phi).^(1/xi);

% Convert the infeasible ones to negative numbers, to be dealt with later
l_B=l_B+sign(Bgrid'*ones(1,nB)-nu*Bbar-(1-nu)*ones(nB,1)*Bgrid)-1;

% Bound it between zero and one
l_B=max(min(l_B,ones(nB,nB)),zeros(nB,nB));

% Make a matrix that indexes infeasible values (l_B is zero or one)
l_B_infeas=floor(l_B)+floor(1-l_B);

% However, allow staying at the lowest level
l_B_infeas(1,1)=0;

% The required time investment for leisure appreciation; avoid negative numbers
l_A=((max(Agrid'*ones(1,nA)-nu_leis*Abar-(1-nu_leis)*ones(nA,1)*Agrid,zeros(nA,nA)))/phi_leis).^(1/xi_leis);

% Convert the infeasible ones to negative numbers, to be dealt with later
l_A=l_A+sign(Agrid'*ones(1,nA)-nu_leis*Abar-(1-nu_leis)*ones(nA,1)*Agrid)-1;

% Bound it between zero and one
l_A=max(min(l_A,ones(nA,nA)),zeros(nA,nA));

% Make a matrix that indexes infeasible values (l_A is zero or one)
l_A_infeas=floor(l_A)+floor(1-l_A);

% However, allow staying at the lowest level
l_A_infeas(1,1)=0;

% Loop over K
i=1;
while i<=nK;

    % Loop over K'
    j=1;
    while j<=nK;


        % Compute the labor decision for each A today (should be row
        % vectors)
        % This includes the choice of artisan vs. worker

        % The fixed component
        b1=(1-delta)*(1-delta+R_min)*Kgrid(1,i)-Kgrid(1,j);
        b2=R_min*Kgrid(1,j);

        % The wage-like component
        w1=(1-delta)*(R_max-R_min)*Kgrid(1,i);
        w2=(R_max-R_min)*Kgrid(1,j);
        
        % The following is first done for artisans, then for workers

        % The solution for n from the fixed grid; have to avoid negative
        % investment
        [junk n1]=max(log(max((1-delta+R_min+(R_max-R_min)*(ngrid').^eta)*(1-delta)*Kgrid(1,i)...
            +y11*ngrid'-Kgrid(1,j),10^-6*ones(nsize,1)))*ones(1,nA)+(1-ngrid')*Agrid);
        [junk n2]=max(log((R_min+(R_max-R_min)*(ngrid').^eta)*Kgrid(1,j)+y12*ngrid')*ones(1,nA)+(1-ngrid')*Agrid);
        
        % Converting to 0 1 scale
        n1=incrn*(n1-1);
        n2=incrn*(n2-1);
        
        % Now check whether physical investment is feasible (1 means
        % infeasible); consumption has to be positive, and
        % irreversibility has to be met
        feas_ind=1-((b1+w1*n1.^eta+y11*n1>0)&((1-delta)^2*Kgrid(1,i)<=Kgrid(1,j)));

        util_art=ones(nA*nB,1)*(kron(ones(1,nA),1-Bgrid).*kron(log(b1+w1*n1.^eta+y11*n1)+Agrid.*(1-n1),ones(1,nB))...
            +kron(ones(1,nA),Bgrid).*kron(log(b2+w2*n2.^eta+y12*n2)+Agrid.*(1-n2),ones(1,nB)))...
            -kron(ones(nA,nA),l_B)-kron(l_A,ones(nB,nB));

        % May have complex numbers because of log
        util_art=real(util_art);

        % Now assign large negative numbers to everything infeasible;
        % first is for investment feasibility, second for leisure
        % investment
        util_art=min(util_art,-200*(ones(nA*nB,1)*kron(feas_ind,ones(1,nB))...
            +kron(ones(nA,nA),l_B_infeas)+kron(l_A_infeas,ones(nB,nB)))+100);


        % Now the same operation for workers
        
        % The solution for n from the fixed grid; have to avoid negative
        % investment
        [junk n1]=max(log(max((1-delta+R_min+(R_max-R_min)*(ngrid').^eta)*(1-delta)*Kgrid(1,i)...
            +y21*ngrid'-Kgrid(1,j),10^-6*ones(nsize,1)))*ones(1,nA)+(1-ngrid')*Agrid);
        [junk n2]=max(log((R_min+(R_max-R_min)*(ngrid').^eta)*Kgrid(1,j)+y22*ngrid')*ones(1,nA)+(1-ngrid')*Agrid);
        
        % Converting to 0 1 scale
        n1=incrn*(n1-1);
        n2=incrn*(n2-1);
        
        % Now check whether physical investment is feasible (1 means
        % infeasible); consumption has to be positive, and
        % irreversibility has to be met
        feas_ind=1-((b1+w1*n1.^eta+y21*n1>0)&((1-delta)^2*Kgrid(1,i)<=Kgrid(1,j)));

        util_wor=ones(nA*nB,1)*(kron(ones(1,nA),1-Bgrid).*kron(log(b1+w1*n1.^eta+y21*n1)+Agrid.*(1-n1),ones(1,nB))...
            +kron(ones(1,nA),Bgrid).*kron(log(b2+w2*n2.^eta+y22*n2)+Agrid.*(1-n2),ones(1,nB)))...
            -kron(ones(nA,nA),l_B)-kron(l_A,ones(nB,nB));

        % May have complex numbers because of log
        util_wor=real(util_wor);

        % Now assign large negative numbers to everything infeasible;
        % first is for investment feasibility, second for leisure
        % investment
        util_wor=min(util_wor,-200*(ones(nA*nB,1)*kron(feas_ind,ones(1,nB))...
            +kron(ones(nA,nA),l_B_infeas)+kron(l_A_infeas,ones(nB,nB)))+100);    
            
            
        % Maximize the occupational choice
        util=max(util_art,util_wor);    
            
        % Now replace the infeasible values with zeros
        util=util.*(util>-100);
        
        % Store this in sparse format
        eval(['util' num2str(i) '_' num2str(j) '=sparse(util);']);
        
        j=j+1;
    end;

    disp([i 0]);

    i=i+1;
end;


% crit is the test function
crit=1;

while crit>maxcrit;
    
    % Loop over K
    i=1;
    while i<=nK;
        
        tic;
        
        % Loop over K'
        j=1;
        while j<=nK;
           
            eval(['util=util' num2str(i) '_' num2str(j) ';']);
            
            % Insert large negative numbers for zeros
            util=util-100*(util==0);
            
            % The optimal choice of patience and leisure preference given the K, K' combination
            [vnew_int(j,:) ABpol_int(j,:)]=max(util+z*v(j,:)'*ones(1,nA*nB));   

            j=j+1;
        end;
        
        % Now the optimal choice of tomorrow's capital
        [vnew(i,:) Kpol(i,:)]=max(vnew_int);
        ABpol(i,:)=ABpol_int(sub2ind(size(ABpol_int),Kpol(i,:),[1:1:nA*nB]));  
        
        disp([i crit]);
        toc;
        
        i=i+1;
    end;
    
    
    
    crit=max(max(abs(v-vnew)))
    
    v=vnew;
    
end;

% Here is a series of capital pictures, one for each level of leisure
% taste.

Apol=ceil(ABpol/nB);
Bpol=ABpol-(Apol-1)*nB;

% count=1;
% while count<=nA;
%     
%     % Below, the sign statement selects between the floor (first element)
%     % and the higher scaled elements
%     figure;
%     surf(Kgrid'*ones(1,nB),ones(nK,1)*Bgrid,floorK*(1-sign(Kpol(:,(count-1)*nB+1:count*nB)-1))+...
%     minK*incrK.^(Kpol(:,(count-1)*nB+1:count*nB)-2).*sign(Kpol(:,(count-1)*nB+1:count*nB)-1));
%     hold on;
%     axis([min(Kgrid) max(Kgrid) min(Bgrid) max(Bgrid) min(Kgrid) max(Kgrid)]);
%     caxis([1 42]);
%     xx=xlabel('Capital');
%     yy=ylabel('Patience');
%     zz=zlabel('Capital');
%     set(zz,'Fontsize',12);
%     set(xx,'Fontsize',12);
%     set(yy,'Fontsize',12);
%     hold off;
%     
% 
% 
%     figure;
%     surf(Kgrid'*ones(1,nB),ones(nK,1)*Bgrid,(Apol(:,(count-1)*nB+1:count*nB)-1)*incrA+minA);
%     hold on;
%     axis([min(Kgrid) max(Kgrid) min(Bgrid) max(Bgrid) min(Agrid) max(Agrid)]);
%     caxis([1 42]);
%     xx=xlabel('Capital');
%     yy=ylabel('Patience');
%     zz=zlabel('Leisure Taste');
%     set(zz,'Fontsize',12);
%     set(xx,'Fontsize',12);
%     set(yy,'Fontsize',12);
%     hold off;
%     
% 
%     
%     figure;
%     surf(Kgrid'*ones(1,nB),ones(nK,1)*Bgrid,(Bpol(:,(count-1)*nB+1:count*nB)-1)*incrB+minB);
%     hold on;
%     axis([min(Kgrid) max(Kgrid) min(Bgrid) max(Bgrid) min(Bgrid) max(Bgrid)]);
%     caxis([1 42]);
%     xx=xlabel('Capital');
%     yy=ylabel('Patience');
%     zz=zlabel('Patience');
%     set(zz,'Fontsize',12);
%     set(xx,'Fontsize',12);
%     set(yy,'Fontsize',12);
%     hold off;
%     
% 
%     
%     count=count+1;
% end;




% Getting the right index for initial B
beta_ss_lo= 0.4005;
beta_ss_hi= 0.5980;

[dummy ind_B_lo]=min(abs(Bgrid-beta_ss_lo));
[dummy ind_B_hi]=min(abs(Bgrid-beta_ss_hi));


A_ss=1.5;

[dummy ind_A]=min(abs(Agrid-A_ss));


% Time horizon for simulation
time=8;

% Initializing the path
path_lo_ind=zeros(3,time);
path_hi_ind=zeros(3,time);

path_lo=zeros(3,time);
path_hi=zeros(3,time);

path_lo_ind(:,1)=[1,ind_B_lo,ind_A];
path_hi_ind(:,1)=[1,ind_B_hi,ind_A];

path_lo(:,1)=[Kgrid(1,path_lo_ind(1,1)),Bgrid(1,path_lo_ind(2,1)),Agrid(1,path_lo_ind(3,1))];
path_hi(:,1)=[Kgrid(1,path_hi_ind(1,1)),Bgrid(1,path_hi_ind(2,1)),Agrid(1,path_lo_ind(3,1))];

i=1;
while i<time;
    
    path_lo_ind(:,i+1)=[Kpol(path_lo_ind(1,i),path_lo_ind(2,i)+(path_lo_ind(3,i)-1)*nB);...
        Bpol(path_lo_ind(1,i),path_lo_ind(2,i)+(path_lo_ind(3,i)-1)*nB);...
        Apol(path_lo_ind(1,i),path_lo_ind(2,i)+(path_lo_ind(3,i)-1)*nB)];
    
    path_hi_ind(:,i+1)=[Kpol(path_hi_ind(1,i),path_hi_ind(2,i)+(path_hi_ind(3,i)-1)*nB);...
        Bpol(path_hi_ind(1,i),path_hi_ind(2,i)+(path_hi_ind(3,i)-1)*nB);...
        Apol(path_hi_ind(1,i),path_hi_ind(2,i)+(path_hi_ind(3,i)-1)*nB)];
    
    path_lo(:,i+1)=[Kgrid(1,path_lo_ind(1,i+1));Bgrid(1,path_lo_ind(2,i+1));Agrid(1,path_lo_ind(3,i+1))];
    path_hi(:,i+1)=[Kgrid(1,path_hi_ind(1,i+1));Bgrid(1,path_hi_ind(2,i+1));Agrid(1,path_hi_ind(3,i+1))];

    i=i+1;
end;

path_lo

path_hi

% Plotting Figures
figure;
subplot(3,1,1);
gr=plot([1:1:time],path_lo(1,:),'b-',[1:1:time],path_hi(1,:),'r-');
hold on;
set(gr,'LineWidth',2);
axis([1 time -1 max(path_hi(1,:))+1]);
ll=legend('Worker','Artisan','Location','NorthWest');
yy=ylabel('Capital');
set(ll,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;

subplot(3,1,2);
gr=plot([1:1:time],path_lo(2,:),'b-',[1:1:time],path_hi(2,:),'r-');
hold on;
set(gr,'LineWidth',2);
axis([1 time .3 .9]);
xx=xlabel('Time');
yy=ylabel('Patience');
set(xx,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;

subplot(3,1,3);
gr=plot([1:1:time],path_lo(3,:),'b-',[1:1:time],path_hi(3,:),'r-');
hold on;
set(gr,'LineWidth',2);
axis([1 time 1 2.2]);
xx=xlabel('Time');
yy=ylabel('Leisure Taste');
set(xx,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;

% Plotting Figures for paper (b/w)
figure;
subplot(3,1,1);
gr=plot([1:1:time],path_lo(1,:),'k--',[1:1:time],path_hi(1,:),'k-');
hold on;
set(gr,'LineWidth',2);
axis([1 time -1 max(path_hi(1,:))+1]);
ll=legend('Worker/Landowner','Artisan','Location','East');
xx=xlabel('Time');
yy=ylabel('K');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;

subplot(3,1,2);
gr=plot([1:1:time],path_lo(2,:),'k--',[1:1:time],path_hi(2,:),'k-');
hold on;
set(gr,'LineWidth',2);
axis([1 time .3 .9]);
ll=legend('Worker/Landowner','Artisan','Location','East');
xx=xlabel('Time');
yy=ylabel('B');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;

subplot(3,1,3);
gr=plot([1:1:time],path_lo(3,:),'k--',[1:1:time],path_hi(3,:),'k-',[1:1:time],2*ones(1,time),'k:');
hold on;
set(gr,'LineWidth',2);
axis([1 time 1.4 2.2]);
ll=legend('Worker','Artisan','Landowner','Location','East');
xx=xlabel('Time');
yy=ylabel('A');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;

% Plotting Figures for paper (b/w)
figure;
subplot(2,1,1);
gr=plot([0:1:time],[path_hi(1,1) path_hi(1,:)],'k-',[0:1:time],[path_lo(1,1) path_lo(1,:)],'k--');
hold on;
set(gr,'LineWidth',2);
axis([0 time -1 max(path_hi(1,:))+1]);
ll=legend('Artisan','Worker/Landowner','Location','NorthWest');
xx=xlabel('Time');
yy=ylabel('K');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;

subplot(2,1,2);
gr=plot([0:1:time],[path_hi(2,1) path_hi(2,:)],'k-',[0:1:time],[path_lo(2,1) path_lo(2,:)],'k--');
hold on;
set(gr,'LineWidth',2);
axis([0 time .3 .9]);
ll=legend('Artisan','Worker/Landowner','Location','East');
xx=xlabel('Time');
yy=ylabel('B');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;

figure;
gr=plot([0:1:time],2*ones(1,time+1),'k:',[0:1:time],[path_hi(3,1) path_hi(3,:)],'k-',[0:1:time],[path_lo(3,1) path_lo(3,:)],'k--');
hold on;
set(gr,'LineWidth',2);
axis([0 time 1 2.1]);
ll=legend('Landowner','Artisan','Worker','Location','SouthEast');
xx=xlabel('Time');
yy=ylabel('A');
set(ll,'Fontsize',12);
set(ll,'Fontsize',12);
set(yy,'Fontsize',12);
hold off;


% Plotting Figures for presentations (color)
figure;
subplot(2,1,1);
gr=plot([0:1:time],[path_hi(1,1) path_hi(1,:)],'r-',[0:1:time],[path_lo(1,1) path_lo(1,:)],'b-');
hold on;
set(gr,'LineWidth',2);
axis([0 time -1 max(path_hi(1,:))+1]);
ll=legend('Artisan','Worker/Landowner','Location','NorthWest');
xx=xlabel('Time');
yy=ylabel('K');
set(ll,'Fontsize',16);
set(xx,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;

subplot(2,1,2);
gr=plot([0:1:time],[path_hi(2,1) path_hi(2,:)],'r-',[0:1:time],[path_lo(2,1) path_lo(2,:)],'b-');
hold on;
set(gr,'LineWidth',2);
axis([0 time .3 .9]);
ll=legend('Artisan','Worker/Landowner','Location','East');
xx=xlabel('Time');
yy=ylabel('B');
set(ll,'Fontsize',16);
set(xx,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;

figure;
gr=plot([0:1:time],2*ones(1,time+1),'g-',[0:1:time],[path_hi(3,1) path_hi(3,:)],'r-',[0:1:time],[path_lo(3,1) path_lo(3,:)],'b-');
hold on;
set(gr,'LineWidth',2);
axis([0 time 1 2.1]);
ll=legend('Landowner','Artisan','Worker','Location','SouthEast');
xx=xlabel('Time');
yy=ylabel('A');
set(ll,'Fontsize',16);
set(xx,'Fontsize',16);
set(yy,'Fontsize',16);
hold off;
