% expanded_model_rev1.m
% Computes transition path for expanded version of JEEA 2008 model

% Version includes extensions for revision 1 of paper at Journal of
% Economic Growth
%
% This particular file performs welfare calculations
% In particular, task is to compute the expected utility of the children of
% the unskilled under each policy and in each period
%
% September 2009

clear all;
clear all;

close all;

% TECHNICAL PARAMETERS **********************
%********************************************

crit_max=10^(-7);

crit_max_mu_path=10^(-4);

horizon=15;
stop_growth=horizon-3;

plot_horizon=10;

% MODEL PARAMETERS **********************
%****************************************

% Technology
alph=0.75;
gam_l=0.05;
gam_h=0.75;

% Growth in productivity of export sector 
growth=0.0075;

% Preferences
z=0.3;

% Education technology
pi_1=0.7;
pi_0=0.0;

% Difference in education cost between skilled and unskilled
p_gap=0.05;

% Efficiency of child labor 
lam=0.1;

% INITIAL CONDITIONS ********************
%****************************************

% Fraction of unskilled educating 
mu_init=0.45;

% Fraction of unskilled workers in export sector
frac_E_init=0.6;

% INITIAL EQUILIBRIUM *******************
%****************************************

N_U_init=(1-pi_1)/(1-(1-mu_init)*(pi_1-pi_0));
N_S_init=(pi_1-(1-mu_init)*(pi_1-pi_0))/(1-(1-mu_init)*(pi_1-pi_0));


% Also assume that initially, fraction frac_E of unskilled labor supply is
% provided to the export sector. Have to solve for the productivity A that
% equates returns to unskilled labor in both sectors.

S_E=N_S_init;
U_E_l=frac_E_init*(1+(1-mu_init)*lam)*N_U_init;
U_D_h=(1-frac_E_init)*(gam_h/(gam_h+gam_l))*(1+(1-mu_init)*lam)*N_U_init;
U_D_l=(1-frac_E_init)*(gam_l/(gam_h+gam_l))*(1+(1-mu_init)*lam)*N_U_init;

% Check that this indeed equates marginal products across light and heavy
test_cond=gam_l*U_D_h^gam_h*U_D_l^(gam_l-1)-gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;
disp(['Difference in wages is: ' num2str(test_cond)]);

w_U_init=gam_l*U_D_h^gam_h*U_D_l^(gam_l-1);
w_C_init=lam*w_U_init;

% Now find the export productivity that equates the returns to unskilled
% labor across sectors
A_E=w_U_init/((1-alph)*S_E^alph*U_E_l^(-alph));

% Resulting skilled wage
w_S_init=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);

disp(' ');
disp(['The skilled wage is: ' num2str(w_S_init)]);
disp(['The unskilled wage is: ' num2str(w_U_init)]);
disp(['The child wage is: ' num2str(w_C_init)]);

% Compute the cost of education that justifies this skill premium
p=z*(pi_1-pi_0)*(w_S_init-w_U_init+p_gap)-w_C_init;

disp(' ');
disp(['The cost of education for unskilled is: ' num2str(p)]);


% STATIC WAGE EFFECTS OF IMPOSING IS *******************
%*******************************************************

% The wage effect of imposing IS.
% Have to determine allocation of unskilled labor that equalizes returns
% between E and D sector

% Skilled labor supply
S_E=N_S_init;

% Only children in light domestic labor
U_D_l=lam*(1-mu_init)*N_U_init;

% The fraction of adult unskilled labor in export sector
frac_E=0.6;
frac_E_lo=0;
frac_E_hi=1;

crit=1;
while crit>crit_max;
    
    % Labor supply
    U_E_l=frac_E*N_U_init;
    U_D_h=(1-frac_E)*N_U_init;
    
    % Implied wages
    w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
    w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;
   
    % Move more people to E if wage is higher
    if w_U_E>w_U_D;
        
        frac_E_lo=frac_E;
        frac_E=0.5*frac_E+0.5*frac_E_hi;
        
    else
        
        frac_E_hi=frac_E;
        frac_E=0.5*frac_E+0.5*frac_E_lo;
               
    end;
    
    crit=abs(w_U_E-w_U_D);
    
end;

% Resulting wages
w_S_IS=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
w_U_IS=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
w_C_IS=lam*gam_l*U_D_h^gam_h*U_D_l^(gam_l-1);

disp(' ');
disp(['The skilled wage is: ' num2str(w_S_IS)]);
disp(['The unskilled wage is: ' num2str(w_U_IS)]);
disp(['The child wage is: ' num2str(w_C_IS)]);

disp(' ');
disp(['The change in skilled wage LF to IS is: ' num2str(w_S_IS-w_S_init)]);
disp(['The change in unskilled wage LF to IS is: ' num2str(w_U_IS-w_U_init)]);
disp(['The change in child wage LF to IS is: ' num2str(w_C_IS-w_C_init)]);


% STATIC WAGE EFFECTS OF IMPOSING B *******************
%******************************************************

% The wage effect of imposing B.
% Have to determine allocation of unskilled labor that equalizes returns
% between E and D sector

% Skilled labor supply
S_E=N_S_init;

% The fraction of adult unskilled labor in export sector
frac_E=0.6;
frac_E_lo=0;
frac_E_hi=1;

crit=1;
while crit>crit_max;
    
    % Labor supply
    U_E_l=frac_E*N_U_init;
    U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_init;
    U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_init;
        
    % Implied wages
    w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
    w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;
   
    % Move more people to E if wage is higher
    if w_U_E>w_U_D;
        
        frac_E_lo=frac_E;
        frac_E=0.5*frac_E+0.5*frac_E_hi;
        
    else
        
        frac_E_hi=frac_E;
        frac_E=0.5*frac_E+0.5*frac_E_lo;
               
    end;
    
    crit=abs(w_U_E-w_U_D);
    
end;

% Resulting wages
w_S_B=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
w_U_B=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
w_C_B=0;

disp(' ');
disp(['The skilled wage is: ' num2str(w_S_B)]);
disp(['The unskilled wage is: ' num2str(w_U_B)]);
disp(['The child wage is: ' num2str(w_C_B)]);

disp(' ');
disp(['The change in skilled wage LF to B is: ' num2str(w_S_B-w_S_init)]);
disp(['The change in unskilled wage LF to B is: ' num2str(w_U_B-w_U_init)]);
disp(['The change in child wage LF to B is: ' num2str(w_C_B-w_C_init)]);

disp(' ');
disp(['The change in skilled wage IS to B is: ' num2str(w_S_B-w_S_IS)]);
disp(['The change in unskilled wage IS to B is: ' num2str(w_U_B-w_U_IS)]);
disp(['The change in child wage IS to B is: ' num2str(w_C_B-w_C_IS)]);


% TRANSITION PRODUCTIVITY *********************************
%**********************************************************

% Construct the time path for productivity
A_E_init=A_E;

A_E_path=zeros(1,horizon+1);

time=1;
while time<=horizon+1;
    
        if time <= stop_growth;
            A_E_path(1,time)=(1+growth)^(time-1)*A_E_init;
        else
            A_E_path(1,time)=A_E_path(1,time-1);
        end;
        
        time=time+1;
end;


% TRANSITION PATH: LF *************************************
%**********************************************************

% Initialize outcomes
w_S_path_LF=zeros(1,horizon);
w_U_path_LF=zeros(1,horizon);
w_C_path_LF=zeros(1,horizon);

N_S_path_LF=zeros(1,horizon);
N_U_path_LF=zeros(1,horizon);

mu_path_LF=ones(1,horizon)*mu_init;

mu_path_LF_new=zeros(1,horizon);

frac_E_path_LF=zeros(1,horizon);
coalition_path_LF=zeros(1,horizon);

% Now iterate to find the corect mu_path
crit_mu_path=1;

while crit_mu_path>crit_max_mu_path;
    
    time=1;

    % Initialize the population size
    N_U=N_U_init;
    N_S=N_S_init;


    while time<=horizon+1;

        % Productivity of the export sector        
        A_E=A_E_path(time);
          

        % Find the correct mu (in the previous period)
        mu=0.5;
        mu_lo=0;
        mu_hi=1;

        crit_mu=1;
        while crit_mu>crit_max;

            N_U_new=(1-pi_0)*(1-mu)*N_U+(1-pi_1)*(mu*N_U+N_S);
            N_S_new=pi_0*(1-mu)*N_U+pi_1*(mu*N_U+N_S);

            % Skilled labor supply
            S_E=N_S_new;


            % Now compute labor supply allocated to export sector
            % The fraction of adult unskilled labor in export sector
            frac_E=0.5;
            frac_E_lo=0;
            frac_E_hi=1;

            crit=1;
            while crit>crit_max;

                % Labor supply.
                % Assume that mu is the same in last two periods.
                % Will be the case because there is no further
                % technological change
                U_E_l=frac_E*(1+(1-mu_path_LF(1,min(time,horizon)))*lam)*N_U_new;
                U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*(1+(1-mu_path_LF(1,min(time,horizon)))*lam)*N_U_new;
                U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*(1+(1-mu_path_LF(1,min(time,horizon)))*lam)*N_U_new;

                % Implied wages
                w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                % Move more people to E if wage is higher
                if w_U_E>w_U_D;

                    frac_E_lo=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_hi;

                else

                    frac_E_hi=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_lo;

                end;

                crit=abs(w_U_E-w_U_D);

            end;

            % Resulting wages
            w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
            w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_C=lam*w_U;

            % Check the indifference condition for education

            cond=z*(pi_1-pi_0)*(w_S-w_U+p_gap)-(p+w_C);

            % If cond is positive, skill premium is too high; increase mu
            if cond>0;

                mu_lo=mu;
                mu=0.5*mu+0.5*mu_hi;

            else

                mu_hi=mu;
                mu=0.5*mu+0.5*mu_lo;

            end;

            % Exit of criterion is met or if everybody is educating
            crit_mu=min(abs(cond),1-mu);

        end;

        if time<=horizon;

            w_S_path_LF(1,time)=w_S;
            w_U_path_LF(1,time)=w_U;
            w_C_path_LF(1,time)=w_C;
            N_S_path_LF(1,time)=N_S_new;
            N_U_path_LF(1,time)=N_U_new;
            frac_E_path_LF(1,time)=frac_E;

        end;

        if time>1;

            mu_path_LF_new(1,time-1)=mu;
            coalition_path_LF(1,time-1)=mu*N_U;

        end;
        
        % Update population
        N_U=N_U_new;
        N_S=N_S_new;

        time=time+1;

    end;
   
    crit_mu_path=sum(abs(mu_path_LF-mu_path_LF_new));
 
    mu_path_LF=0.1*mu_path_LF_new+0.9*mu_path_LF;
    
end;


% TRANSITION PATH: IS *************************************
%**********************************************************

% In period 2, IS is unexpectedly introduced

% Initialize outcomes
w_S_path_IS=w_S_path_LF;
w_U_path_IS=w_U_path_LF;
w_C_path_IS=w_C_path_LF;
N_S_path_IS=N_S_path_LF;
N_U_path_IS=N_U_path_LF;

mu_path_IS=mu_path_LF;

mu_path_IS_new=mu_path_LF;

frac_E_path_IS=frac_E_path_LF;
coalition_path_IS=coalition_path_LF;

% Now iterate to find the corect mu_path
crit_mu_path=1;

while crit_mu_path>crit_max_mu_path;
    
    % Start in period 2; in period 1, there is no shock yet
    time=2;

    % Set the previous population size
    N_U=N_U_path_IS(1,1);
    N_S=N_S_path_IS(1,1);


    while time<=horizon+1;

        % Productivity of the export sector        
        A_E=A_E_path(time);
        
        if time <=3;

            % mu is already set (B was introduced unexpectedly)
            N_U_new=(1-pi_0)*(1-mu_path_IS(1,time-1))*N_U+(1-pi_1)*(mu_path_IS(1,time-1)*N_U+N_S);
            N_S_new=pi_0*(1-mu_path_IS(1,time-1))*N_U+pi_1*(mu_path_IS(1,time-1)*N_U+N_S);

        
            % Skilled labor supply
            S_E=N_S_new;

            % Now compute labor supply allocated to export sector
            % The fraction of adult unskilled labor in export sector
            frac_E=0.5;
            frac_E_lo=0;
            frac_E_hi=1;

            crit=1;
            while crit>crit_max;

                % Labor supply.
                % Assume that mu is the same in last two periods.
                % Will be the case because there is no further
                % technological change
                U_E_l=frac_E*N_U_new;
                U_D_h=(1-frac_E)*N_U_new;
                U_D_l=(1-mu_path_IS(1,min(time,horizon)))*lam*N_U_new;

                % Implied wages
                w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                % Move more people to E if wage is higher
                if w_U_E>w_U_D;

                    frac_E_lo=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_hi;

                else

                    frac_E_hi=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_lo;

                end;

                crit=abs(w_U_E-w_U_D);

            end;

            % Resulting wages
            w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
            w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_C=lam*gam_l*U_D_h^gam_h*U_D_l^(gam_l-1);
        
        else
        
            % Find the correct mu (in the previous period)
            mu=0.5;
            mu_lo=0;
            mu_hi=1;

            crit_mu=1;
            while crit_mu>crit_max;

                N_U_new=(1-pi_0)*(1-mu)*N_U+(1-pi_1)*(mu*N_U+N_S);
                N_S_new=pi_0*(1-mu)*N_U+pi_1*(mu*N_U+N_S);

                % Skilled labor supply
                S_E=N_S_new;


                % Now compute labor supply allocated to export sector
                % The fraction of adult unskilled labor in export sector
                frac_E=0.5;
                frac_E_lo=0;
                frac_E_hi=1;

                crit=1;
                while crit>crit_max;

                    % Labor supply.
                    % Assume that mu is the same in last two periods.
                    % Will be the case because there is no further
                    % technological change
                    U_E_l=frac_E*N_U_new;
                    U_D_h=(1-frac_E)*N_U_new;
                    U_D_l=(1-mu_path_IS(1,min(time,horizon)))*lam*N_U_new;

                    % Implied wages
                    w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                    w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                    % Move more people to E if wage is higher
                    if w_U_E>w_U_D;

                        frac_E_lo=frac_E;
                        frac_E=0.5*frac_E+0.5*frac_E_hi;

                    else

                        frac_E_hi=frac_E;
                        frac_E=0.5*frac_E+0.5*frac_E_lo;

                    end;

                    crit=abs(w_U_E-w_U_D);
                    
                end;
                
                % Resulting wages
                w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
                w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_C=lam*gam_l*U_D_h^gam_h*U_D_l^(gam_l-1);

                % Check the indifference condition for education

                cond=z*(pi_1-pi_0)*(w_S-w_U+p_gap)-(p+w_C);

                % If cond is positive, skill premium is too high; increase mu
                if cond>0;

                    mu_lo=mu;
                    mu=0.5*mu+0.5*mu_hi;

                else

                    mu_hi=mu;
                    mu=0.5*mu+0.5*mu_lo;

                end;
                

                % Exit of criterion is met or if everybody is educating
                crit_mu=min(abs(cond),1-mu);

            end;
        
        end;

        if time<=horizon;

            w_S_path_IS(1,time)=w_S;
            w_U_path_IS(1,time)=w_U;
            w_C_path_IS(1,time)=w_C;
            N_S_path_IS(1,time)=N_S_new;
            N_U_path_IS(1,time)=N_U_new;
            frac_E_path_IS(1,time)=frac_E;

        end;

        if time>3;

            mu_path_IS_new(1,time-1)=mu;
            coalition_path_IS(1,time-1)=mu*N_U;

        end;
        
        % Update population
        N_U=N_U_new;
        N_S=N_S_new;

        time=time+1;

    end;
    
%     disp(' ');
%     
%     mu_path_IS_new
%     
%     disp(' ');
            
    crit_mu_path=sum(abs(mu_path_IS-mu_path_IS_new));
 
    mu_path_IS=0.05*mu_path_IS_new+0.95*mu_path_IS;
    
end;


% TRANSITION PATH: B **************************************
%**********************************************************

% In period 2, B is surprisingly introduced

% Initialize outcomes
w_S_path_B=w_S_path_LF;
w_U_path_B=w_U_path_LF;
w_C_path_B=w_C_path_LF;
N_S_path_B=N_S_path_LF;
N_U_path_B=N_U_path_LF;

mu_path_B=mu_path_LF;

frac_E_path_B=frac_E_path_LF;
coalition_path_B=coalition_path_LF;

    
% Start in period 2; in period 1, there is no shock yet
time=2;

% Set the previous population size
N_U=N_U_path_B(1,1);
N_S=N_S_path_B(1,1);


while time<=horizon+1;

    % Productivity of the export sector        
    A_E=A_E_path(time);          

    if time <=3;

        % mu is already set (B was introduced unexpectedly)
        N_U_new=(1-pi_0)*(1-mu_path_B(1,time-1))*N_U+(1-pi_1)*(mu_path_B(1,time-1)*N_U+N_S);
        N_S_new=pi_0*(1-mu_path_B(1,time-1))*N_U+pi_1*(mu_path_B(1,time-1)*N_U+N_S);

        % Skilled labor supply
        S_E=N_S_new;


        % Now compute labor supply allocated to export sector
        % The fraction of adult unskilled labor in export sector
        frac_E=0.5;
        frac_E_lo=0;
        frac_E_hi=1;

        crit=1;
        while crit>crit_max;

            % Labor supply. 
            U_E_l=frac_E*N_U_new;
            U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
            U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

            % Implied wages
            w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

            % Move more people to E if wage is higher
            if w_U_E>w_U_D;

                frac_E_lo=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_hi;

            else

                frac_E_hi=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_lo;

            end;

            crit=abs(w_U_E-w_U_D);

        end;

        % Resulting wages
        w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
        w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
        w_C=0;

    else

        % Find the correct mu (in the previous period)
        mu=0.5;
        mu_lo=0;
        mu_hi=1;

        crit_mu=1;
        while crit_mu>crit_max;

            N_U_new=(1-pi_0)*(1-mu)*N_U+(1-pi_1)*(mu*N_U+N_S);
            N_S_new=pi_0*(1-mu)*N_U+pi_1*(mu*N_U+N_S);

            % Skilled labor supply
            S_E=N_S_new;


            % Now compute labor supply allocated to export sector
            % The fraction of adult unskilled labor in export sector
            frac_E=0.5;
            frac_E_lo=0;
            frac_E_hi=1;

            crit=1;
            while crit>crit_max;

                % Labor supply. 
                % Assume that mu is the same in last two periods.
                % Will be the case because there is no further
                % technological change
                U_E_l=frac_E*N_U_new;
                U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
                U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

                % Implied wages
                w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                % Move more people to E if wage is higher
                if w_U_E>w_U_D;

                    frac_E_lo=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_hi;

                else

                    frac_E_hi=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_lo;

                end;

                crit=abs(w_U_E-w_U_D);

            end;

            % Resulting wages
            w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
            w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_C=0;

            % Check the indifference condition for education

            cond=z*(pi_1-pi_0)*(w_S-w_U+p_gap)-(p+w_C);

            % If cond is positive, skill premium is too high; increase mu
            if cond>0;

                mu_lo=mu;
                mu=0.5*mu+0.5*mu_hi;

            else

                mu_hi=mu;
                mu=0.5*mu+0.5*mu_lo;

            end;

            % Exit of criterion is met or if everybody is educating
            crit_mu=min(abs(cond),1-mu);

        end;

    end;

    if time<=horizon;

        w_S_path_B(1,time)=w_S;
        w_U_path_B(1,time)=w_U;
        w_C_path_B(1,time)=w_C;
        N_S_path_B(1,time)=N_S_new;
        N_U_path_B(1,time)=N_U_new;
        frac_E_path_B(1,time)=frac_E;

    end;

    if time>3;

        mu_path_B(1,time-1)=mu;
        coalition_path_B(1,time-1)=mu*N_U;

    end;

    % Update population
    N_U=N_U_new;
    N_S=N_S_new;

    time=time+1;

end;


% TRANSITION PATH: LF to B ********************************
%**********************************************************

% Compute when the coalition under LF reaches 50 percent
[dummy critical_time]=max((mu_path_LF(2:horizon)>0.5)...
    -(mu_path_LF(1:horizon-1)>0.5));

% Add one because we start at two above
critical_time=critical_time+1;


% In period critical_time, B is surprisingly introduced

% Initialize outcomes
w_S_path_LF_B=w_S_path_LF;
w_U_path_LF_B=w_U_path_LF;
w_C_path_LF_B=w_C_path_LF;
N_S_path_LF_B=N_S_path_LF;
N_U_path_LF_B=N_U_path_LF;

mu_path_LF_B=mu_path_LF;

frac_E_path_LF_B=frac_E_path_LF;
coalition_path_LF_B=coalition_path_LF;

    
% Start in period critical_time; 
time=critical_time;

% Set the previous population size
N_U=N_U_path_LF_B(1,critical_time-1);
N_S=N_S_path_LF_B(1,critical_time-1);


while time<=horizon+1;

    % Productivity of the export sector        
    A_E=A_E_path(time);          

    if time <=critical_time+1;

        % mu is already set (B was introduced unexpectedly)
        N_U_new=(1-pi_0)*(1-mu_path_LF_B(1,time-1))*N_U+(1-pi_1)*(mu_path_LF_B(1,time-1)*N_U+N_S);
        N_S_new=pi_0*(1-mu_path_LF_B(1,time-1))*N_U+pi_1*(mu_path_LF_B(1,time-1)*N_U+N_S);

        % Skilled labor supply
        S_E=N_S_new;


        % Now compute labor supply allocated to export sector
        % The fraction of adult unskilled labor in export sector
        frac_E=0.5;
        frac_E_lo=0;
        frac_E_hi=1;

        crit=1;
        while crit>crit_max;

            % Labor supply. 
            U_E_l=frac_E*N_U_new;
            U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
            U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

            % Implied wages
            w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

            % Move more people to E if wage is higher
            if w_U_E>w_U_D;

                frac_E_lo=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_hi;

            else

                frac_E_hi=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_lo;

            end;

            crit=abs(w_U_E-w_U_D);

        end;

        % Resulting wages
        w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
        w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
        w_C=0;

    else

        % Find the correct mu (in the previous period)
        mu=0.5;
        mu_lo=0;
        mu_hi=1;

        crit_mu=1;
        while crit_mu>crit_max;

            N_U_new=(1-pi_0)*(1-mu)*N_U+(1-pi_1)*(mu*N_U+N_S);
            N_S_new=pi_0*(1-mu)*N_U+pi_1*(mu*N_U+N_S);

            % Skilled labor supply
            S_E=N_S_new;


            % Now compute labor supply allocated to export sector
            % The fraction of adult unskilled labor in export sector
            frac_E=0.5;
            frac_E_lo=0;
            frac_E_hi=1;

            crit=1;
            while crit>crit_max;

                % Labor supply. 
                % Assume that mu is the same in last two periods.
                % Will be the case because there is no further
                % technological change
                U_E_l=frac_E*N_U_new;
                U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
                U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

                % Implied wages
                w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                % Move more people to E if wage is higher
                if w_U_E>w_U_D;

                    frac_E_lo=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_hi;

                else

                    frac_E_hi=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_lo;

                end;

                crit=abs(w_U_E-w_U_D);

            end;

            % Resulting wages
            w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
            w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_C=0;

            % Check the indifference condition for education

            cond=z*(pi_1-pi_0)*(w_S-w_U+p_gap)-(p+w_C);

            % If cond is positive, skill premium is too high; increase mu
            if cond>0;

                mu_lo=mu;
                mu=0.5*mu+0.5*mu_hi;

            else

                mu_hi=mu;
                mu=0.5*mu+0.5*mu_lo;

            end;

            % Exit of criterion is met or if everybody is educating
            crit_mu=min(abs(cond),1-mu);

        end;

    end;

    if time<=horizon;

        w_S_path_LF_B(1,time)=w_S;
        w_U_path_LF_B(1,time)=w_U;
        w_C_path_LF_B(1,time)=w_C;
        N_S_path_LF_B(1,time)=N_S_new;
        N_U_path_LF_B(1,time)=N_U_new;
        frac_E_path_LF_B(1,time)=frac_E;

    end;

    if time>critical_time+1;

        mu_path_LF_B(1,time-1)=mu;
        coalition_path_LF_B(1,time-1)=mu*N_U;

    end;

    % Update population
    N_U=N_U_new;
    N_S=N_S_new;

    time=time+1;

end;


% TRANSITION PATH: IS to B ********************************
%**********************************************************

% In period critical_time, B is surprisingly introduced

% Initialize outcomes
w_S_path_IS_B=w_S_path_IS;
w_U_path_IS_B=w_U_path_IS;
w_C_path_IS_B=w_C_path_IS;
N_S_path_IS_B=N_S_path_IS;
N_U_path_IS_B=N_U_path_IS;

mu_path_IS_B=mu_path_IS;

frac_E_path_IS_B=frac_E_path_IS;
coalition_path_IS_B=coalition_path_IS;

    
% Start in period critical_time; 
time=critical_time;

% Set the previous population size
N_U=N_U_path_IS_B(1,critical_time-1);
N_S=N_S_path_IS_B(1,critical_time-1);


while time<=horizon+1;

    % Productivity of the export sector        
    A_E=A_E_path(time);          

    if time <=critical_time+1;

        % mu is already set (B was introduced unexpectedly)
        N_U_new=(1-pi_0)*(1-mu_path_IS_B(1,time-1))*N_U+(1-pi_1)*(mu_path_IS_B(1,time-1)*N_U+N_S);
        N_S_new=pi_0*(1-mu_path_IS_B(1,time-1))*N_U+pi_1*(mu_path_IS_B(1,time-1)*N_U+N_S);

        % Skilled labor supply
        S_E=N_S_new;


        % Now compute labor supply allocated to export sector
        % The fraction of adult unskilled labor in export sector
        frac_E=0.5;
        frac_E_lo=0;
        frac_E_hi=1;

        crit=1;
        while crit>crit_max;

            % Labor supply. 
            U_E_l=frac_E*N_U_new;
            U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
            U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

            % Implied wages
            w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

            % Move more people to E if wage is higher
            if w_U_E>w_U_D;

                frac_E_lo=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_hi;

            else

                frac_E_hi=frac_E;
                frac_E=0.5*frac_E+0.5*frac_E_lo;

            end;

            crit=abs(w_U_E-w_U_D);

        end;

        % Resulting wages
        w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
        w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
        w_C=0;

    else

        % Find the correct mu (in the previous period)
        mu=0.5;
        mu_lo=0;
        mu_hi=1;

        crit_mu=1;
        while crit_mu>crit_max;

            N_U_new=(1-pi_0)*(1-mu)*N_U+(1-pi_1)*(mu*N_U+N_S);
            N_S_new=pi_0*(1-mu)*N_U+pi_1*(mu*N_U+N_S);

            % Skilled labor supply
            S_E=N_S_new;


            % Now compute labor supply allocated to export sector
            % The fraction of adult unskilled labor in export sector
            frac_E=0.5;
            frac_E_lo=0;
            frac_E_hi=1;

            crit=1;
            while crit>crit_max;

                % Labor supply. 
                % Assume that mu is the same in last two periods.
                % Will be the case because there is no further
                % technological change
                U_E_l=frac_E*N_U_new;
                U_D_h=(1-frac_E)*(gam_h/(gam_h+gam_l))*N_U_new;
                U_D_l=(1-frac_E)*(gam_l/(gam_h+gam_l))*N_U_new;

                % Implied wages
                w_U_E=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
                w_U_D=gam_h*U_D_h^(gam_h-1)*U_D_l^gam_l;

                % Move more people to E if wage is higher
                if w_U_E>w_U_D;

                    frac_E_lo=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_hi;

                else

                    frac_E_hi=frac_E;
                    frac_E=0.5*frac_E+0.5*frac_E_lo;

                end;

                crit=abs(w_U_E-w_U_D);

            end;

            % Resulting wages
            w_S=A_E*alph*S_E^(alph-1)*U_E_l^(1-alph);
            w_U=A_E*(1-alph)*S_E^alph*U_E_l^(-alph);
            w_C=0;

            % Check the indifference condition for education

            cond=z*(pi_1-pi_0)*(w_S-w_U+p_gap)-(p+w_C);

            % If cond is positive, skill premium is too high; increase mu
            if cond>0;

                mu_lo=mu;
                mu=0.5*mu+0.5*mu_hi;

            else

                mu_hi=mu;
                mu=0.5*mu+0.5*mu_lo;

            end;

            % Exit of criterion is met or if everybody is educating
            crit_mu=min(abs(cond),1-mu);

        end;

    end;

    if time<=horizon;

        w_S_path_IS_B(1,time)=w_S;
        w_U_path_IS_B(1,time)=w_U;
        w_C_path_IS_B(1,time)=w_C;
        N_S_path_IS_B(1,time)=N_S_new;
        N_U_path_IS_B(1,time)=N_U_new;
        frac_E_path_IS_B(1,time)=frac_E;

    end;

    if time>critical_time+1;

        mu_path_IS_B(1,time-1)=mu;
        coalition_path_IS_B(1,time-1)=mu*N_U;

    end;

    % Update population
    N_U=N_U_new;
    N_S=N_S_new;

    time=time+1;

end;


% UTILITY COMPUTATION ********************************
%*****************************************************

% Compute utilities under LF, IS, and B for each type at time 2 and time
% critical_time
% Today's choice is given
% From tomorrow on, can assume everybody educates for simplicity (they are
% at least indifferent)

time_eval=2;

while time_eval<=critical_time+2;

    % Common utility from two periods forward onwards
    Util_common_LF=sum(z.^[0:1:horizon-(time_eval+3)].*...
        (pi_1*w_S_path_LF(1,time_eval+2:horizon-1)...
        +(1-pi_1)*w_U_path_LF(1,time_eval+2:horizon-1)-p+p_gap))...
        +(z^(horizon-(time_eval+2))/(1-z))*(pi_1*w_S_path_LF(1,horizon)...
        +(1-pi_1)*w_U_path_LF(1,horizon)-p+p_gap);

    Util_common_LF_B=sum(z.^[0:1:horizon-(time_eval+3)].*...
        (pi_1*w_S_path_LF_B(1,time_eval+2:horizon-1)...
        +(1-pi_1)*w_U_path_LF_B(1,time_eval+2:horizon-1)-p+p_gap))...
        +(z^(horizon-(time_eval+2))/(1-z))*(pi_1*w_S_path_LF_B(1,horizon)...
        +(1-pi_1)*w_U_path_LF_B(1,horizon)-p+p_gap);

    Util_common_IS=sum(z.^[0:1:horizon-(time_eval+3)].*...
        (pi_1*w_S_path_IS(1,time_eval+2:horizon-1)...
        +(1-pi_1)*w_U_path_IS(1,time_eval+2:horizon-1)-p+p_gap))...
        +(z^(horizon-(time_eval+2))/(1-z))*(pi_1*w_S_path_IS(1,horizon)...
        +(1-pi_1)*w_U_path_IS(1,horizon)-p+p_gap);

    Util_common_IS_B=sum(z.^[0:1:horizon-(time_eval+3)].*...
        (pi_1*w_S_path_IS_B(1,time_eval+2:horizon-1)...
        +(1-pi_1)*w_U_path_IS_B(1,time_eval+2:horizon-1)-p+p_gap))...
        +(z^(horizon-(time_eval+2))/(1-z))*(pi_1*w_S_path_IS_B(1,horizon)...
        +(1-pi_1)*w_U_path_IS_B(1,horizon)-p+p_gap);

    % Indidivial utilities
    Util_S_LF(1,time_eval-1)=w_S_path_LF(1,time_eval)-p+p_gap...
        +z*(pi_1*w_S_path_LF(1,time_eval+1)+(1-pi_1)*w_U_path_LF(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF;

    Util_U_no_ed_LF(1,time_eval-1)=w_U_path_LF(1,time_eval)+w_C_path_LF(1,time_eval)...
        +z*(pi_0*w_S_path_LF(1,time_eval+1)+(1-pi_0)*w_U_path_LF(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF;

    Util_U_ed_LF(1,time_eval-1)=w_U_path_LF(1,time_eval)-p...
        +z*(pi_1*w_S_path_LF(1,time_eval+1)+(1-pi_1)*w_U_path_LF(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF;

    Util_S_IS(1,time_eval-1)=w_S_path_IS(1,time_eval)-p+p_gap...
        +z*(pi_1*w_S_path_IS(1,time_eval+1)+(1-pi_1)*w_U_path_IS(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS;

    Util_U_no_ed_IS(1,time_eval-1)=w_U_path_IS(1,time_eval)+w_C_path_IS(1,time_eval)...
        +z*(pi_0*w_S_path_IS(1,time_eval+1)+(1-pi_0)*w_U_path_IS(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS;

    Util_U_ed_IS(1,time_eval-1)=w_U_path_IS(1,time_eval)-p...
        +z*(pi_1*w_S_path_IS(1,time_eval+1)+(1-pi_1)*w_U_path_IS(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS;

    Util_S_LF_B(1,time_eval-1)=w_S_path_LF_B(1,time_eval)-p+p_gap...
        +z*(pi_1*w_S_path_LF_B(1,time_eval+1)+(1-pi_1)*w_U_path_LF_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF_B;

    Util_U_no_ed_LF_B(1,time_eval-1)=w_U_path_LF_B(1,time_eval)+w_C_path_LF_B(1,time_eval)...
        +z*(pi_0*w_S_path_LF_B(1,time_eval+1)+(1-pi_0)*w_U_path_LF_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF_B;

    Util_U_ed_LF_B(1,time_eval-1)=w_U_path_LF_B(1,time_eval)-p...
        +z*(pi_1*w_S_path_LF_B(1,time_eval+1)+(1-pi_1)*w_U_path_LF_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF_B;

    Util_S_IS_B(1,time_eval-1)=w_S_path_IS_B(1,time_eval)-p+p_gap...
        +z*(pi_1*w_S_path_IS_B(1,time_eval+1)+(1-pi_1)*w_U_path_IS_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS_B;

    Util_U_no_ed_IS_B(1,time_eval-1)=w_U_path_IS_B(1,time_eval)+w_C_path_IS_B(1,time_eval)...
        +z*(pi_0*w_S_path_IS_B(1,time_eval+1)+(1-pi_0)*w_U_path_IS_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS_B;

    Util_U_ed_IS_B(1,time_eval-1)=w_U_path_IS_B(1,time_eval)-p...
        +z*(pi_1*w_S_path_IS_B(1,time_eval+1)+(1-pi_1)*w_U_path_IS_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS_B;

    % Those were the adults; the relevant children's utilities are the
    % future components of this.
    Util_CU_no_ed_LF(1,time_eval-1)=...
        +z*(pi_0*w_S_path_LF(1,time_eval+1)+(1-pi_0)*w_U_path_LF(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF;

    Util_CU_ed_LF(1,time_eval-1)=...
        +z*(pi_1*w_S_path_LF(1,time_eval+1)+(1-pi_1)*w_U_path_LF(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF;

    Util_CU_no_ed_IS(1,time_eval-1)=...
        +z*(pi_0*w_S_path_IS(1,time_eval+1)+(1-pi_0)*w_U_path_IS(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS;

    Util_CU_ed_IS(1,time_eval-1)=...
        +z*(pi_1*w_S_path_IS(1,time_eval+1)+(1-pi_1)*w_U_path_IS(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_IS;
    
    Util_CU_no_ed_LF_B(1,time_eval-1)=...
        +z*(pi_0*w_S_path_LF_B(1,time_eval+1)+(1-pi_0)*w_U_path_LF_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF_B;

    Util_CU_ed_LF_B(1,time_eval-1)=...
        +z*(pi_1*w_S_path_LF_B(1,time_eval+1)+(1-pi_1)*w_U_path_LF_B(1,time_eval+1)-p+p_gap)...
        +z^2*Util_common_LF_B;

    % Now do expected utilities for children of the unskilled
    Util_CU_LF(1,time_eval-1)=(1-mu_path_LF(1,time_eval))*Util_CU_no_ed_LF(1,time_eval-1)+mu_path_LF(1,time_eval)*Util_CU_ed_LF(1,time_eval-1);
    Util_CU_IS(1,time_eval-1)=(1-mu_path_IS(1,time_eval))*Util_CU_no_ed_IS(1,time_eval-1)+mu_path_IS(1,time_eval)*Util_CU_ed_IS(1,time_eval-1);
    Util_CU_LF_B(1,time_eval-1)=(1-mu_path_LF_B(1,time_eval))*Util_CU_no_ed_LF_B(1,time_eval-1)+mu_path_LF_B(1,time_eval)*Util_CU_ed_LF_B(1,time_eval-1);


        
    time_eval=time_eval+1;
    
end;

% GRAPHS ********************************
%****************************************

time_axis=[1:1:plot_horizon];

% LF IS LF_B

figure;
subplot(1,1,1);
gr=plot(time_axis,(1-mu_path_LF(1,1:plot_horizon)).*N_U_path_LF(1,1:plot_horizon)*100,'k:',...
    time_axis,(1-mu_path_IS(1,1:plot_horizon)).*N_U_path_IS(1,1:plot_horizon)*100,'k--',...
    time_axis,[(1-mu_path_LF_B(1,1:critical_time-1)).*N_U_path_LF_B(1,1:critical_time-1)*100,...
    zeros(1,plot_horizon-critical_time+1) ],'k-');
hold on;
set(gr,'LineWidth',2);
%axis([1 horizon .3 .8]);
xx=xlabel('Time');
ll=legend('LF','IS','LF to B','Location','SouthWest');
yy=ylabel('Child Labor Rate');
set(xx,'Fontsize',12);
set(yy,'Fontsize',12);
set(ll,'Fontsize',12);
hold off;


figure;
subplot(1,1,1);
gr=plot(time_axis,w_U_path_LF(1,1:plot_horizon),'k:',time_axis,w_U_path_IS(1,1:plot_horizon),'k--',...
    time_axis,w_U_path_LF_B(1,1:plot_horizon),'k-');
hold on;
set(gr,'LineWidth',2);
%axis([1 horizon .3 .8]);
xx=xlabel('Time');
ll=legend('LF','IS','LF to B','Location','NorthWest');
yy=ylabel('Unskilled Wage');
set(xx,'Fontsize',12);
set(yy,'Fontsize',12);
set(ll,'Fontsize',12);
hold off;


figure;
subplot(1,1,1);
gr=plot(time_axis,w_C_path_LF(1,1:plot_horizon),'k:',time_axis,w_C_path_IS(1,1:plot_horizon),'k--',...
    time_axis,w_C_path_LF_B(1,1:plot_horizon),'k-');
hold on;
set(gr,'LineWidth',2);
%axis([1 horizon .3 .8]);
xx=xlabel('Time');
yy=ylabel('Child Wage');
ll=legend('LF','IS','LF to B','Location','SouthWest');
set(xx,'Fontsize',12);
set(yy,'Fontsize',12);
set(ll,'Fontsize',12);
hold off;

